  // ============================= 06-motor-jogo.js =============================
  // Escalação, força da equipa e motor de simulação de partidas
  // Lineup selection
  // =================================================================
  // Correção (bug real reportado pelo utilizador, 2026-10-04: jogo "congela" num loop de "excede
  // os 45 segundos de posse" depois de uma lesão/substituição forçada): investigação exaustiva
  // (fuzzing de onRinkStrength contra todas as substituições possíveis em todos os clubes, em
  // plantéis frescos e evoluídos ao longo de várias épocas, incl. chamadas de emergência e jogo
  // sem guarda-redes) não isolou o jogador/trigger exato, mas confirmou o mecanismo: um único
  // atributo em falta ou NaN num jogador que entra em pista (titular ou suplente) propaga-se por
  // onRinkStrength/teamStrength até shotChance/foulChance/cardChance ficarem todos NaN — e como
  // `Math.random() < NaN` é sempre falso, a partida deixa de poder gerar remates, faltas OU
  // cartões, sobrando só o loop do relógio de posse de 45 segundos, exatamente como no relato.
  // Pior ainda: muitos acessos a atributos já "protegidos" no código (`attrs.x!=null?attrs.x:d`)
  // NÃO protegem contra NaN (NaN!=null é verdadeiro em JS) — só contra null/undefined — por isso
  // um NaN introduzido nalgum ponto da evolução/condição de um jogador (ex.: condicao/__fitness)
  // sobrevive indefinidamente. safeAttrVal/safeNum fecham esta porta nos pontos mais centrais do
  // motor (força em pista, fadiga, condição) com Number.isFinite, nunca apenas `!=null`.
  function safeAttrVal(p, key, fallback){
    const v = p && p.attrs ? p.attrs[key] : undefined;
    return Number.isFinite(v) ? v : fallback;
  }
  function safeNum(v, fallback){
    return Number.isFinite(v) ? v : fallback;
  }
  function bestGK(team){
    let gks = team.players.filter(p=>p.pos==="GR" && playerAvailableForMatch(p));
    if(gks.length===0) gks = team.players.filter(p=>p.pos==="GR");
    return gks.slice().sort((a,b)=>(overall(b)+b.moral*0.1)-(overall(a)+a.moral*0.1))[0];
  }
  function bestOutfield(team, n){
    let outs = team.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p));
    if(outs.length===0) outs = team.players.filter(p=>p.pos==="J");
    return outs.slice().sort((a,b)=>(overall(b)+b.moral*0.15)-(overall(a)+a.moral*0.15)).slice(0,n);
  }
  // Fase B: em vez de escalar sempre os 4 melhores OVR sem olhar à posição, os clubes
  // controlados pela IA passam a escalar respeitando a composição ideal do sistema escolhido
  // (3 DEF/MED+1 AVÇ no 3-1, 2+2 no 2-2) — só recorre aos melhores restantes se não houver
  // jogadores suficientes de um dos tipos.
  function bestOutfieldForSystem(team, sistema){
    let pool = team.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p));
    if(pool.length===0) pool = team.players.filter(p=>p.pos==="J");
    // Carga de trabalho (08l-carga.js): a IA roda o onze — quem está sobrecarregado perde até 4 pontos de OVR na escolha.
    const rank = p => overall(p)+p.moral*0.15-cargaRotacaoPenalty(p);
    const ideal = systemIdealCounts(sistema);
    const avcs = pool.filter(p=>p.linha==="Avancado").sort((a,b)=>rank(b)-rank(a));
    const defmeds = pool.filter(p=>p.linha!=="Avancado").sort((a,b)=>rank(b)-rank(a));
    let chosen = avcs.slice(0, ideal.avc).concat(defmeds.slice(0, ideal.defmed));
    if(chosen.length<4){
      const usedIds = new Set(chosen.map(p=>p.id));
      const rest = pool.filter(p=>!usedIds.has(p.id)).sort((a,b)=>rank(b)-rank(a));
      chosen = chosen.concat(rest.slice(0,4-chosen.length));
    }
    return chosen.sort((a,b)=>rank(b)-rank(a));
  }
  function getLineup(team){
    const isMine = team.id === state.userTeamId;
    let gr, outfield;
    if(isMine){
      const grPicks = team.players.filter(p=>p.pos==="GR" && p.titular);
      gr = grPicks[0] || bestGK(team);
      const outPicks = team.players.filter(p=>p.pos==="J" && p.titular);
      // Correção: só se recorria ao preenchimento automático (bestOutfield) quando NENHUM
      // jogador estava marcado como titular. Com 1-3 titulares marcados (ex.: titular
      // desmarcado sem substituto escolhido, lesão/suspensão de última hora) a equipa jogava
      // o jogo inteiro em inferioridade numérica. Agora completa-se sempre até 4.
      if(outPicks.length>=4){
        outfield = outPicks.slice(0,4);
      } else {
        const usedIds = new Set(outPicks.map(p=>p.id));
        const fill = bestOutfield(team,4).filter(p=>!usedIds.has(p.id));
        outfield = outPicks.concat(fill).slice(0,4);
      }
    } else {
      gr = bestGK(team);
      outfield = bestOutfieldForSystem(team, team.sistema||"3-1");
    }
    return { gr, outfield: outfield.filter(Boolean) };
  }

  // =================================================================
  // Team strength (attribute-based)
  // =================================================================
  // Fase 16: curva única de desgaste, partilhada pela condição persistente (entre jogos) e pela
  // fadiga viva (dentro do jogo) — mais percetível do que a anterior a partir dos 85-90%, para
  // que jogar cansado (ou mal recuperado) tenha um efeito real, não apenas cosmético.
  function fatigueCurve(v){
    v = clamp(v, 0, 100);
    if(v>=90) return 0.96 + (v-90)/10*0.04;
    if(v>=80) return 0.89 + (v-80)/10*0.07;
    if(v>=70) return 0.79 + (v-70)/10*0.10;
    if(v>=60) return 0.67 + (v-60)/10*0.12;
    if(v>=50) return 0.53 + (v-50)/10*0.14;
    if(v>=40) return 0.38 + (v-40)/10*0.15;
    if(v>=25) return 0.22 + (v-25)/15*0.16;
    return clamp(0.22*(v/25), 0.05, 0.22);
  }
  // Number.isFinite (não só !=null) — NaN!=null é verdadeiro em JS, por isso um p.condicao
  // corrompido para NaN (ver nota grande no topo do ficheiro) passava despercebido aqui e
  // envenenava fatigueCurve/onRinkStrength indefinidamente.
  function condicaoFactor(p){ const c = safeNum(p && p.condicao, 100); return fatigueCurve(c) * cargaPerfFactor(p); } // carga de trabalho (08l-carga.js): até −5% de rendimento

  // A fadiga não afeta todos os atributos da mesma forma: um jogador cansado perde explosão e
  // capacidade física muito antes de perder leitura de jogo, liderança ou criatividade. 1 = efeito
  // total da curva de desgaste; 0 = imune. Valores intermédios atenuam proporcionalmente.
  const FATIGUE_TIER = {
    velocidade:1, aceleracao:1, resistencia:1, forca:1, drible:1, desarme:1,
    reflexos:1, umParaUm:1, agilidade:1,
    finalizacao:0.55, habilidade:0.55, posicionamento:0.55, meiaDistancia:0.55, concentracao:0.55,
    lideranca:0.15, determinacao:0.15, criatividade:0.15, bolasParadas:0.15, agressividade:0.55,
  };
  function fatigueTierFactor(baseFactor, attrKey){
    const tier = FATIGUE_TIER[attrKey]!=null ? FATIGUE_TIER[attrKey] : 0.55;
    return 1 - (1-baseFactor)*tier;
  }

  function mentalScore(p){ return ((p.attrs.determinacao!=null?p.attrs.determinacao:10) + (p.attrs.lideranca!=null?p.attrs.lideranca:10)) / 2; }
  // Correção (sistema numérico de reputação): REPUTATION_RANK convertia a categoria antiga em 4
  // patamares (1-4) e usava a diferença de patamar — passa a usar diretamente a diferença de
  // reputação numérica (0-100), dividida por 15 (o espaçamento típico entre os antigos patamares
  // legados, ver REPUTATION_POINTS em 01-nucleo.js) para preservar a mesma ordem de grandeza do
  // efeito, mas agora contínuo em vez de aos saltos.
  function reputationFactor(p, ownTeam, oppTeam){
    if(!oppTeam || !ownTeam) return 1;
    const gap = (Number(oppTeam.reputacao)||0) - (Number(ownTeam.reputacao)||0);
    if(gap<=0) return 1;
    const gapSteps = gap/15;
    const mental = mentalScore(p);
    return clamp(1 - gapSteps*0.03*(1-mental/20), 0.80, 1);
  }

  // ============================= Fase A: Sistema tático (3-1 / 2-2) =============================
  // Ideal de composição por sistema: quantos AVÇ e quantos DEF/MED "deviam" estar em pista.
  function systemIdealCounts(sistema){
    return sistema==="2-2" ? {avc:2, defmed:2} : {avc:1, defmed:3};
  }
  // Penalização por composição inadequada (secção 8 do documento): não bloqueia o utilizador,
  // mas cada unidade de desvio face ao ideal do sistema custa organização coletiva — sem tocar
  // no OVR visível do jogador. Aplica-se aos titulares efetivamente escalados, não ao plantel.
  function lineupCompositionFactor(outfield, sistema){
    if(!outfield.length) return 1;
    const avc = outfield.filter(p=>p.linha==="Avancado").length;
    const defmed = outfield.length - avc;
    const ideal = systemIdealCounts(sistema);
    const mismatch = Math.abs(avc-ideal.avc) + Math.abs(defmed-ideal.defmed);
    return clamp(1 - mismatch*0.06, 0.75, 1);
  }
  // Interação leve entre sistemas diferentes (secção 11 do documento) — nunca uma matriz rígida
  // ("3-1 vence 2-2"): só um pequeno ajuste ao ataque (±5%, nunca mais), a partir de confrontos
  // de atributos concretos entre os dois sistemas, exatamente como o documento descreve. Contra
  // o mesmo sistema, não há qualquer ajuste (a diferença vem só dos jogadores em confronto).
  function attrAvg(players, keys){
    if(!players.length) return 10;
    return avg(players.map(p=>avg(keys.map(k=>p.attrs[k]!=null?p.attrs[k]:10))));
  }
  function systemMatchupModifier(team, oppTeam, oppOutfield, ownOutfield){
    const sistema = team.sistema||"3-1", oppSistema = oppTeam.sistema||"3-1";
    if(sistema===oppSistema) return 1;
    const opp = (oppOutfield&&oppOutfield.length) ? oppOutfield : oppTeam.players.filter(p=>p.pos==="J").slice(0,4);
    const oppDefMed = opp.filter(p=>p.linha!=="Avancado");
    const oppAvc = opp.filter(p=>p.linha==="Avancado");
    // Correção: usava sempre team.players na ordem de armazenamento (import/criação), não a
    // escalação real do próprio lado — o confronto deixava de ser "concreto" como o comentário
    // abaixo descreve. Os chamadores passam agora a escalação efetiva (ownOutfield); mantém-se
    // o fallback por ordem de armazenamento só para chamadas antigas/de teste que não a passem.
    const myOutfield = (ownOutfield&&ownOutfield.length) ? ownOutfield : team.players.filter(p=>p.pos==="J").slice(0,4);
    if(sistema==="3-1"){
      // a circulação do 3-1 (criatividade+habilidade dos DEF/MED) tenta furar a cobertura do
      // 2-2 adversário (posicionamento+desarme dos seus 2 DEF/MED, mais expostos por serem só dois)
      const minhaCirculacao = attrAvg(myOutfield.filter(p=>p.linha!=="Avancado"), ["criatividade","habilidade"]);
      const coberturaAdversaria = attrAvg(oppDefMed, ["posicionamento","desarme"]);
      return clamp(1 + (minhaCirculacao-coberturaAdversaria)/200, 0.95, 1.05);
    }
    // sistema==="2-2": a mobilidade e finalização dos meus AVÇ tentam explorar o espaço deixado
    // pelo AVÇ isolado do 3-1 adversário, cuja capacidade de aguentar a bola sozinho depende do
    // seu próprio posicionamento e finalização
    const minhaMobilidade = attrAvg(myOutfield.filter(p=>p.linha==="Avancado"), ["aceleracao","velocidade","finalizacao"]);
    const referenciaAdversaria = attrAvg(oppAvc, ["posicionamento","finalizacao"]);
    return clamp(1 + (minhaMobilidade-referenciaAdversaria)/200, 0.95, 1.05);
  }
  // Adequação do plantel disponível a cada sistema (secção 7): usada pela IA (Fase B) e exposta
  // no separador Táticas para o utilizador perceber se o plantel serve melhor o 3-1 ou o 2-2.
  // Não usa nenhum valor aleatório nem manual — só posições, atributos, condição e satisfação
  // dos jogadores realmente disponíveis (não suspensos, com condição mínima).
  function availablePlayersForSystemFit(team){
    return team.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p) && (p.condicao==null||p.condicao>=25));
  }
  function playerSystemValue(p){
    return overall(p) * condicaoFactor(p) * satisfactionFactor(p);
  }
  // Fase B (secção 6 do documento): perfis funcionais dentro de cada linha, calculados só a
  // partir de atributos já existentes — sem qualquer campo novo manual. Usados para a IA saber
  // que suplente "faz sentido" trocar por quem sai (não só o de maior OVR).
  function defMedProfileScores(p){
    return {
      construtor: (p.attrs.criatividade||10)*0.30 + (p.attrs.habilidade||10)*0.25 + (p.attrs.posicionamento||10)*0.25 + (p.attrs.meiaDistancia||10)*0.20,
      defensivo: (p.attrs.desarme||10)*0.35 + (p.attrs.posicionamento||10)*0.25 + (p.attrs.forca||10)*0.20 + (p.attrs.resistencia||10)*0.20,
      movel: (p.attrs.velocidade||10)*0.30 + (p.attrs.aceleracao||10)*0.30 + (p.attrs.resistencia||10)*0.20 + (p.attrs.desarme||10)*0.20,
    };
  }
  function avcProfileScores(p){
    return {
      finalizador: (p.attrs.finalizacao||10)*0.40 + (p.attrs.habilidade||10)*0.20 + (p.attrs.meiaDistancia||10)*0.20 + (p.attrs.posicionamento||10)*0.20,
      movel: (p.attrs.aceleracao||10)*0.30 + (p.attrs.velocidade||10)*0.30 + (p.attrs.drible||10)*0.25 + (p.attrs.resistencia||10)*0.15,
    };
  }
  function playerProfile(p){
    if(!p || p.pos!=="J") return null;
    const scores = p.linha==="Avancado" ? avcProfileScores(p) : defMedProfileScores(p);
    return Object.keys(scores).reduce((best,key)=>scores[key]>scores[best]?key:best);
  }
  function systemFitScore(team, sistema){
    const pool = availablePlayersForSystemFit(team);
    const avcs = pool.filter(p=>p.linha==="Avancado").sort((a,b)=>playerSystemValue(b)-playerSystemValue(a));
    const defmeds = pool.filter(p=>p.linha!=="Avancado").sort((a,b)=>playerSystemValue(b)-playerSystemValue(a));
    if(sistema==="2-2"){
      const topAvc = avcs.slice(0,2), topDef = defmeds.slice(0,2);
      const avcScore = topAvc.length ? avg(topAvc.map(playerSystemValue)) : 8;
      const defScore = topDef.length ? avg(topDef.map(playerSystemValue)) : 8;
      const mobility = pool.length ? avg(pool.map(p=>((p.attrs.velocidade||10)+(p.attrs.aceleracao||10)+(p.attrs.resistencia||10))/3)) : 10;
      const depthPenalty = clamp((2-avcs.length)*8 + (2-defmeds.length)*6, 0, 30);
      return clamp(avcScore*2.2 + defScore*1.4 + mobility*0.6 - depthPenalty, 0, 100);
    }
    const topAvc = avcs.slice(0,1), topDef = defmeds.slice(0,3);
    const avcScore = topAvc.length ? playerSystemValue(topAvc[0]) : 8;
    const defScore = topDef.length ? avg(topDef.map(playerSystemValue)) : 8;
    const creativity = defmeds.length ? avg(defmeds.slice(0,3).map(p=>((p.attrs.criatividade||10)+(p.attrs.posicionamento||10)+(p.attrs.meiaDistancia||10))/3)) : 10;
    const depthPenalty = clamp((1-avcs.length)*10 + (3-defmeds.length)*6, 0, 30);
    return clamp(avcScore*1.6 + defScore*2.0 + creativity*0.6 - depthPenalty, 0, 100);
  }

  function tacticFitBoost(outfield, tactic){
    if(!outfield.length) return 1;
    if(tactic==="ofensivo"){
      const avgPace = avg(outfield.map(p=>((p.attrs.velocidade||10)+(p.attrs.aceleracao||10)+(p.attrs.finalizacao||10))/3));
      return clamp(1.0 + (avgPace-14)*0.05, 0.5, 1.5);
    }
    if(tactic==="defensivo"){
      const avgDef = avg(outfield.map(p=>((p.attrs.posicionamento||10)+(p.attrs.forca||10)+(p.attrs.desarme||10))/3));
      return clamp(1.0 + (avgDef-14)*0.05, 0.5, 1.5);
    }
    return 1;
  }

  // A IA escolhe a tática consoante o plantel que tem: se o plantel é claramente mais talhado
  // para atacar (velocidade/aceleração/finalização) ou para defender (posicionamento/força),
  // opta por essa tática; caso contrário mantém-se equilibrado.
  function chooseAiMentalidade(team){
    const outfield = team.players.filter(p=>p.pos==="J");
    if(outfield.length < 4) return "equilibrado";
    const offFit = tacticFitBoost(outfield, "ofensivo");
    const defFit = tacticFitBoost(outfield, "defensivo");
    // Staff — Treinadores (Fase 2, 2026-09-22): a cultura do clube (08c-staff-treinadores.js,
    // desliza devagar rumo ao perfil de quem o comanda — nunca salta de um jogo para o outro)
    // inclina a escolha para além do que o plantel por si só sugeriria, sem a inverter sozinha —
    // continua a ser sempre a adequação real do plantel a decidir a maior parte da pontuação.
    const bias = (treinadorCulturaOrNeutral(team).ofensividade - 10) * 0.02;
    const offBiased = offFit + bias, defBiased = defFit - bias;
    if(offBiased > defBiased && offBiased > 1.04) return "ofensivo";
    if(defBiased > offBiased && defBiased > 1.04) return "defensivo";
    return "equilibrado";
  }

  // Fase 1 (Identidade + Familiaridade): a IA usa a identidade tática do clube (sistema
  // principal/secundário) como âncora estável, reforçada pela familiaridade — sistemas bem
  // treinados custam mais a abandonar. Só se desvia do sistema principal quando o secundário
  // pontua claramente melhor (diferença de pelo menos 10, já refletindo lesões, suspensões,
  // condição e adversário através de systemFitScore) — nunca muda de sistema todas as jornadas
  // sem motivo.
  function chooseAiSistema(team){
    const principal = team.identidadeSistemaPrincipal || team.sistema || "3-1";
    const secundario = team.identidadeSistemaSecundario || (principal==="3-1"?"2-2":"3-1");
    if(principal===secundario) return principal;
    const famPrincipal = principal==="2-2" ? (team.familiaridade22!=null?team.familiaridade22:50) : (team.familiaridade31!=null?team.familiaridade31:50);
    const famSecundario = secundario==="2-2" ? (team.familiaridade22!=null?team.familiaridade22:50) : (team.familiaridade31!=null?team.familiaridade31:50);
    const biasedPrincipal = systemFitScore(team, principal) + (famPrincipal-50)*0.15;
    const biasedSecundario = systemFitScore(team, secundario) + (famSecundario-50)*0.15;
    if(biasedSecundario - biasedPrincipal >= 10) return secundario;
    return principal;
  }

  // A IA decide também o quão agressiva quer ser: jogadores com bom Desarme (limpo) e
  // naturalmente agressivos rendem ao pressionar; sem essa combinação, mais vale jogar
  // cauteloso para não arriscar faltas e cartões em excesso.
  function chooseAiPressao(team){
    const outfield = team.players.filter(p=>p.pos==="J");
    if(outfield.length < 4) return "media";
    const avgDesarme = avg(outfield.map(p=>p.attrs.desarme!=null?p.attrs.desarme:12));
    const avgAggro = avg(outfield.map(p=>p.attrs.agressividade!=null?p.attrs.agressividade:12));
    let score = (avgDesarme-14)*0.6 + (avgAggro-14)*0.4;
    // Staff — Treinadores (Fase 2): mesma cultura de clube de chooseAiMentalidade empurra a
    // pressão para cima ou para baixo, sem ignorar o que o plantel realmente aguenta.
    score += (treinadorCulturaOrNeutral(team).agressividade - 10) * 0.18;
    if(score > 1.5) return "alta";
    if(score < -1.5) return "baixa";
    return "media";
  }

  function teamStrength(team, opponentTeam){
    const outfield = team.players.filter(p=>p.pos==="J");
    const gks = team.players.filter(p=>p.pos==="GR");
    const rf = p => reputationFactor(p, team, opponentTeam)*satisfactionFactor(p);
    const cf = p => condicaoFactor(p);
    const avgAtk = outfield.length ? avg(outfield.map(p=>{const b=cf(p),r=rf(p);return (safeAttrVal(p,'habilidade',12)*fatigueTierFactor(b,'habilidade')*0.4+safeAttrVal(p,'criatividade',12)*fatigueTierFactor(b,'criatividade')*0.3+safeAttrVal(p,'drible',12)*fatigueTierFactor(b,'drible')*0.3)*r;})) : 12;
    const avgPos = outfield.length ? avg(outfield.map(p=>safeAttrVal(p,'posicionamento',12)*fatigueTierFactor(cf(p),'posicionamento')*rf(p))) : 12;
    const avgDesarme = outfield.length ? avg(outfield.map(p=>safeAttrVal(p,'desarme',12)*fatigueTierFactor(cf(p),'desarme')*rf(p))) : 12;
    const avgForca = outfield.length ? avg(outfield.map(p=>safeAttrVal(p,'forca',12)*fatigueTierFactor(cf(p),'forca')*rf(p))) : 12;
    const avgGK = gks.length ? avg(gks.map(p=>{const b=cf(p),r=rf(p);return (safeAttrVal(p,'reflexos',12)*fatigueTierFactor(b,'reflexos')*0.45+safeAttrVal(p,'umParaUm',12)*fatigueTierFactor(b,'umParaUm')*0.25+safeAttrVal(p,'agilidade',12)*fatigueTierFactor(b,'agilidade')*0.20+safeAttrVal(p,'concentracao',12)*fatigueTierFactor(b,'concentracao')*0.10)*r;})) : 12;
    let attack = avgAtk*0.75 + avgPos*0.25;
    let defense = avgPos*0.25 + avgDesarme*0.20 + avgForca*0.15 + avgGK*0.40;
    // Staff — Treinadores (Fase 2, 2026-09-22, pedido do utilizador: "se dá espaço à
    // criatividade"): pequeno modificador limitado (±5%), derivado da cultura do clube
    // (08c-staff-treinadores.js) — deliberadamente pequeno para não desequilibrar a calibração
    // já existente do motor de jogo.
    attack *= creativeFreedomFactor(team);
    // Mercado de treinadores (2026-09-23): clube sem treinador (vaga em aberto) rende um pouco
    // menos, dos dois lados da bola — ver treinadorVacanciaPenaltyFactor (08c-staff-treinadores.js).
    const vacanciaFactor = treinadorVacanciaPenaltyFactor(team);
    attack *= vacanciaFactor; defense *= vacanciaFactor;
    if(team.mentalidade==="ofensivo"){ attack *= 1 + 0.15*tacticFitBoost(outfield,"ofensivo"); defense*=0.80; }
    if(team.mentalidade==="defensivo"){ defense *= 1 + 0.35*tacticFitBoost(outfield,"defensivo"); attack*=0.88; }
    const compFactor = lineupCompositionFactor(outfield, team.sistema||"3-1");
    attack *= (1 - (1-compFactor)*0.6); defense *= (1 - (1-compFactor)*0.4);
    // Fase 1: familiaridade tática — sistema bem treinado (80+) dá um pequeno bónus de
    // organização; pouco treinado (<50) penaliza. 50-79 é neutro.
    const famFactor = familiaridadeFactor(team, team.sistema||"3-1");
    attack *= famFactor; defense *= famFactor;
    attack *= systemMatchupModifier(team, opponentTeam, getLineup(opponentTeam).outfield, getLineup(team).outfield);
    const allPlayers = outfield.concat(gks);
    const avgLideranca = allPlayers.length ? avg(allPlayers.map(p=>safeAttrVal(p,'lideranca',12))) : 12;
    const leadershipMod = 1 + (avgLideranca-12)/141;
    attack *= leadershipMod; defense *= leadershipMod;
    // Balneário (08d-balneario.js): modificador pequeno (±3,5%) da química de equipa, oculta ao utilizador.
    const balnearioMod = balnearioFactor(team);
    attack *= balnearioMod; defense *= balnearioMod;
    return { attack: safeNum(attack,12), defense: safeNum(defense,12) };
  }

  function weightedPick(arr, weightFn){
    if(arr.length===0) return null;
    const weights = arr.map(p=>Math.max(0.05, weightFn(p)));
    const total = weights.reduce((a,b)=>a+b,0);
    let r = Math.random()*total;
    for(let i=0;i<arr.length;i++){ r -= weights[i]; if(r<=0) return arr[i]; }
    return arr[arr.length-1];
  }
  function bumpRating(player, delta){ if(!player) return; player.__matchRatingDelta = (player.__matchRatingDelta||0)+delta; }
  function matchRating(ctx, side, player){
    let eventDelta = player.__matchRatingDelta||0;
    // Os GR enfrentam muitos remates. As bonificações positivas têm retorno decrescente,
    // evitando que um grande volume de defesas normais produza automaticamente notas 8-10.
    if(player.pos==="GR" && eventDelta>0){
      eventDelta = eventDelta<=1.5 ? eventDelta : 1.5 + (eventDelta-1.5)*0.35;
    }
    let rating = 5.8 + eventDelta;
    const own = ctx.score[side], opp = ctx.score[side==="home"?"away":"home"];
    const margin = Math.abs(own-opp);
    if(own>opp) rating += margin>=3 ? 0.55 : margin===2 ? 0.35 : 0.15;
    else if(own<opp) rating -= margin>=3 ? 0.65 : margin===2 ? 0.4 : 0.15;
    return clamp(rating,1,10);
  }

  // ---- Fitness (forma física) ----
  // Fase 16: usa a mesma curva de desgaste da condição persistente (fatigueCurve), em vez de uma
  // curva própria mais suave — a fadiga viva do jogo (__fitness) e a condição entre jogos
  // (condicao) passam a pesar de forma coerente uma com a outra.
  function fitnessFactor(p){
    const f = safeNum(p && p.__fitness, 100);
    return fatigueCurve(f);
  }
  // Fadiga por tick: modelo distinto para jogadores de campo e guarda-redes (ver fitnessDecayPerTickGK).
  // Intensidade por divisão: um jogo da 2ª Divisão não tem o mesmo ritmo/pressão física de um
  // jogo do Placard — jogadores com stats mais baixos (típicos da 2ª Divisão) aguentam-se bem
  // ao seu próprio ritmo, mas sofreriam muito mais se jogassem de repente ao ritmo do Placard
  // (ex.: uma equipa promovida, ou um jogador emprestado a subir de nível).
  const DIVISION_INTENSITY = { placard: 1.0, "2div": 0.7, "3div": 0.55 };
  function matchIntensityFactor(homeTeam){
    return DIVISION_INTENSITY[homeTeam.divisaoAtual] != null ? DIVISION_INTENSITY[homeTeam.divisaoAtual] : 1.0;
  }
  function fitnessDecayPerTick(p, seconds, tacticMult, intensity){
    const res = safeAttrVal(p, 'resistencia', 10);
    // Calibração: a curva antiga (6 - res/3, entre 1 e 5/min) fazia um jogador de resistência
    // baixa (comum em plantéis fracos, sobretudo na 2ª Divisão) esgotar-se bem antes do fim de
    // um único jogo — o desgaste total já ultrapassava os 100% lá pelo minuto 30,
    // independentemente da intensidade da divisão. Nova curva: mesmo o pior caso plausível
    // (resistência muito baixa, mentalidade ofensiva, Placard) só se aproxima de 0% no limite,
    // sem o ultrapassar muito antes do apito final; resistência média termina uma partida
    // normal por volta dos 55-60%.
    const perMinute = clamp(1.7 - res*0.06, 0.5, 1.7) * (tacticMult||1) * (intensity!=null?intensity:1);
    return perMinute * (seconds/60);
  }
  // Guarda-redes têm um desgaste muito mais baixo: um titular deve aguentar os 50 minutos e
  // terminar por volta dos 70%, com a resistência a fazer variar o resultado em ±15% aprox.
  // O desgaste extra por defesa/penálti/livre direto é aplicado à parte, no momento do lance
  // (ver resolveShot / resolveSetPiece), refletindo a intensidade ofensiva do adversário.
  function fitnessDecayPerTickGK(p, seconds, intensity){
    const res = safeAttrVal(p, 'resistencia', 14);
    const perMinute = clamp(0.6 - (res-14)*0.035, 0.25, 1.0) * (intensity!=null?intensity:1);
    return perMinute * (seconds/60);
  }
  function fitnessColor(f){ return f>=60 ? "#3FA34D" : f>=30 ? "#F3C623" : "#D6402F"; }

  // Live, per-tick team strength based on who is actually on the rink right now and their fatigue.
  function onRinkStrength(ctx, side){
    const lu = ctx.lineups[side];
    const outfield = lu.outfield;
    const team = state.teams[side==="home"?ctx.homeId:ctx.awayId];
    const oppTeam = state.teams[side==="home"?ctx.awayId:ctx.homeId];
    const rf = p => reputationFactor(p, team, oppTeam)*satisfactionFactor(p);
    const bf = p => fitnessFactor(p)*condicaoFactor(p); // fadiga combinada (viva + persistente), 0-1
    const avgAtk = outfield.length ? avg(outfield.map(p=>{const b=bf(p),r=rf(p);return (safeAttrVal(p,'habilidade',12)*fatigueTierFactor(b,'habilidade')*0.4+safeAttrVal(p,'criatividade',12)*fatigueTierFactor(b,'criatividade')*0.3+safeAttrVal(p,'drible',12)*fatigueTierFactor(b,'drible')*0.3)*r;})) : 12;
    const avgPos = outfield.length ? avg(outfield.map(p=>safeAttrVal(p,'posicionamento',12)*fatigueTierFactor(bf(p),'posicionamento')*rf(p))) : 12;
    const avgDesarme = outfield.length ? avg(outfield.map(p=>safeAttrVal(p,'desarme',12)*fatigueTierFactor(bf(p),'desarme')*rf(p))) : 12;
    const avgForca = outfield.length ? avg(outfield.map(p=>safeAttrVal(p,'forca',12)*fatigueTierFactor(bf(p),'forca')*rf(p))) : 12;
    const gk = lu.gr;
    const avgGK = gk ? (()=>{const b=bf(gk),r=rf(gk);return (safeAttrVal(gk,'reflexos',12)*fatigueTierFactor(b,'reflexos')*0.45+safeAttrVal(gk,'umParaUm',12)*fatigueTierFactor(b,'umParaUm')*0.25+safeAttrVal(gk,'agilidade',12)*fatigueTierFactor(b,'agilidade')*0.20+safeAttrVal(gk,'concentracao',12)*fatigueTierFactor(b,'concentracao')*0.10)*r;})() : 12;
    let attack = avgAtk*0.75 + avgPos*0.25;
    let defense = avgPos*0.25 + avgDesarme*0.20 + avgForca*0.15 + avgGK*0.40;
    // Staff — Treinadores (Fase 2): mesmo modificador de creativeFreedomFactor aplicado em
    // teamStrength, para o jogo ao vivo se comportar de forma consistente com a simulação rápida.
    attack *= creativeFreedomFactor(team);
    // Mercado de treinadores (2026-09-23): mesma penalização de teamStrength, aplicada também ao
    // jogo ao vivo, para os dois motores se comportarem de forma consistente.
    const vacanciaFactorLive = treinadorVacanciaPenaltyFactor(team);
    attack *= vacanciaFactorLive; defense *= vacanciaFactorLive;
    if(team.mentalidade==="ofensivo"){ attack *= 1 + 0.15*tacticFitBoost(outfield,"ofensivo"); defense*=0.80; }
    if(team.mentalidade==="defensivo"){ defense *= 1 + 0.35*tacticFitBoost(outfield,"defensivo"); attack*=0.88; }
    const compFactorLive = lineupCompositionFactor(outfield, team.sistema||"3-1");
    attack *= (1 - (1-compFactorLive)*0.6); defense *= (1 - (1-compFactorLive)*0.4);
    const famFactorLive = familiaridadeFactor(team, team.sistema||"3-1");
    attack *= famFactorLive; defense *= famFactorLive;
    attack *= systemMatchupModifier(team, oppTeam, (ctx.lineups[side==="home"?"away":"home"]||{}).outfield, outfield);
    // liderança em pista organiza a equipa: um pequeno efeito coletivo, positivo ou negativo
    const onRinkAll = [gk].concat(outfield).filter(Boolean);
    const avgLideranca = onRinkAll.length ? avg(onRinkAll.map(p=>safeAttrVal(p,'lideranca',12))) : 12;
    const leadershipMod = 1 + (avgLideranca-12)/141;
    attack *= leadershipMod; defense *= leadershipMod;
    // Balneário (08d-balneario.js): modificador pequeno (±3,5%) da química de equipa, oculta ao utilizador.
    const balnearioMod = balnearioFactor(team);
    attack *= balnearioMod; defense *= balnearioMod;
    if(side==="home" && !ctx.neutralVenue){ const adpHome=adeptosHomeFactor(team); attack *= HOME_ADV_ATTACK*adpHome; defense *= HOME_ADV_DEFENSE*adpHome; }
    // Jogar sem guarda-redes: corpo extra em ataque + adversário tipicamente a recuar para
    // defender uma vantagem apertada — reforço temporário de ataque (a defesa já reflete a
    // ausência do GR através de avgGK, e o risco real de baliza vazia é tratado em resolveShot).
    if(ctx.semGuardaRedes && ctx.semGuardaRedes[side]) attack *= 1.18;
    // Efeito mental temporário da mensagem do último desconto de tempo pedido por esta equipa.
    const mentalBuff = ctx.timeoutMentalBuff && ctx.timeoutMentalBuff[side];
    if(mentalBuff && ctx.clock < mentalBuff.expiresClock){
      attack *= mentalBuff.attackMult; defense *= mentalBuff.defenseMult;
    }
    // Rede de segurança final: mesmo que algum fator acima (fora do controlo direto desta função,
    // ex. creativeFreedomFactor/familiaridadeFactor/systemMatchupModifier) produza um valor não
    // numérico por alguma via ainda não identificada, a partida nunca mais deve poder "congelar"
    // por causa disto — nunca devolve NaN/Infinity, sempre um valor finito e plausível.
    return { attack: safeNum(attack,12), defense: safeNum(defense,12) };
  }

  // ---- Substitutions ----
  function performSub(ctx, side, outPlayer, inPlayer, reason){
    recordMatchMetric(ctx,side,"substituicao",0.5);
    if(!outPlayer || !inPlayer) return;
    const lu = ctx.lineups[side];
    const bench = ctx.bench[side];
    if(lu.gr === outPlayer){
      lu.gr = inPlayer;
    } else {
      const idx = lu.outfield.indexOf(outPlayer);
      if(idx>=0) lu.outfield[idx] = inPlayer;
    }
    const bIdx = bench.indexOf(inPlayer);
    if(bIdx>=0) bench.splice(bIdx,1);
    bench.push(outPlayer);
    inPlayer.__fitness = inPlayer.__fitness!=null ? inPlayer.__fitness : 100;
    inPlayer.__matchRatingDelta = inPlayer.__matchRatingDelta || 0;
    inPlayer.__matchGoals = inPlayer.__matchGoals || 0;
    inPlayer.__matchGolosSofridos = inPlayer.__matchGolosSofridos || 0;
    inPlayer.__matchAssists = inPlayer.__matchAssists || 0;
    ctx.playedSet[side].add(inPlayer.id);
    addLog(ctx, ctx.clock||0, "sistema", `${reason==="lesao"?"🚑 Substituição forçada":"🔁 Substituição"} em ${teamName(ctx,side)}: sai ${outPlayer.name}, entra ${inPlayer.name}.`);
  }

  // 2026-10-16: lesionado sem suplente disponível. Antes ficava em pista (a "continuar em inferioridade"
  // era só uma mensagem) e jogava o resto do jogo. Sai sempre; se a pista ficar sem guarda-redes ou
  // abaixo de 3 jogadores de campo, entra um jogador de emergência (mesmo mecanismo dos cartões).
  function removeInjuredWithoutSub(ctx, side, outPlayer){
    removePlayerFromRink(ctx, side, outPlayer);
    const lu = ctx.lineups[side];
    if(outPlayer.pos==="GR" ? !lu.gr : lu.outfield.length < 3){
      callUpImmediateReplacement(ctx, side, outPlayer.pos==="GR" ? "GR" : "J");
    }
    if(!ctx.bench[side].includes(outPlayer)) ctx.bench[side].push(outPlayer);
  }
  function autoSubAI(ctx, side, outPlayer){
    const bench = ctx.bench[side].filter(jogadorDisponivelNestaPartida);
    const samePos = bench.filter(p=>p.pos===outPlayer.pos);
    const pool = samePos.length ? samePos : bench;
    if(pool.length===0){
      removeInjuredWithoutSub(ctx, side, outPlayer);
      addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} não tem suplentes disponíveis: ${outPlayer.name} sai lesionado e a equipa continua em inferioridade.`);
      return;
    }
    const inPlayer = pool.slice().sort((a,b)=>(overall(b)+b.moral*0.1)-(overall(a)+a.moral*0.1))[0];
    performSub(ctx, side, outPlayer, inPlayer, "lesao");
  }

  // Risco de lesão: condição física e resistência pesam mais; idade elevada e condição em jogo
  // abaixo de 50% disparam o risco várias vezes; a qualidade médica/fisioterapia do clube
  // (condicoesTreino) reduz ou agrava ligeiramente o resultado final.
  function injuryChance(p, ctx, side){
    const fit = p.__fitness!=null ? p.__fitness : 100;
    const cond = p.condicao!=null ? p.condicao : 100;
    const res = p.attrs.resistencia!=null ? p.attrs.resistencia : 10;
    const age = p.age || 24;
    let chance = 0.00005 + (1-fit/100)*0.00032 + (1-cond/100)*0.00028;
    chance *= clamp(1.25 - (res-14)*0.025, 0.75, 1.5);
    if(age>=31) chance *= 1 + (age-30)*0.05;
    if(fit<50) chance *= 1 + (50-fit)*0.06; // risco dispara (várias vezes superior) abaixo dos 50%
    const team = state.teams[side==="home"?ctx.homeId:ctx.awayId];
    // Departamento médico (04-financas.js, 2026-10-08): substitui o antigo proxy das condições de
    // treino — nível 0 (+25% de risco) a nível 4 (−22%).
    return chance * medicalInjuryMult(team) * cargaInjuryMult(p) * pavilhaoPisoMult(state.teams[ctx.homeId]) * lesReadaptMult(p); // readaptação após lesão grave (08w-lesoes.js) // piso do pavilhão (08o-pavilhao.js) // carga de trabalho (08l-carga.js): até ×1,6
  }
  // ============================= Lesões com gravidade + departamento médico =============================
  // Pedido do utilizador (2026-09-14): "quando um jogador sai de pista lesionado, ou é grave e não
  // pode voltar a jogar, ou pode mas perde imensa condição física, tipo 30% com desvio padrão 15.
  // Às lesões graves têm de ser analisadas pelo departamento médico que define tempos de paragem
  // (dias, semanas, meses). Quando há um lesionado tem de sair notícia." Confirmado (AskUserQuestion):
  // não existe departamento médico — criado do zero (reaproveitando condicoesTreino como proxy de
  // qualidade médica, já usado em injuryChance/medMult acima); a perda de condição da lesão ligeira
  // fica limitada a um mínimo/máximo razoável, não à distribuição normal em bruto.
  const INJURY_GRAVE_CHANCE = 0.32; // cerca de 1 em 3 lesões é grave — as restantes são ligeiras
  const INJURY_LIGEIRA_LOSS_MIN = 8, INJURY_LIGEIRA_LOSS_MAX = 65; // limites do randNormalApprox(30,15)
  const MEDICAL_EVAL_DELAY_MIN_DAYS = 1, MEDICAL_EVAL_DELAY_MAX_DAYS = 3; // "aguarda avaliação"
  // Duração da paragem de uma lesão grave: em vez de uma única distribuição normal (que dava
  // sempre a mesma forma de curva), um sorteio por categoria em três "baldes" realistas — a
  // maioria são paragens curtas, com uma cauda mais longa para lesões sérias — depois um valor
  // uniforme dentro da categoria escolhida. Dá diretamente a linguagem pedida ("dias, semanas,
  // meses") sem ter de adivinhar a partir de um número de dias solto.
  const GRAVE_INJURY_DURATION_BUCKETS = [
    { weight:0.50, minDays:10, maxDays:21 },   // curta: 10-21 dias
    { weight:0.35, minDays:22, maxDays:60 },   // média: ~3-9 semanas
    { weight:0.15, minDays:61, maxDays:180 },  // longa: ~2-6 meses
  ];
  function rollGraveInjuryDurationDays(){
    const r = Math.random();
    let acc = 0, bucket = GRAVE_INJURY_DURATION_BUCKETS[GRAVE_INJURY_DURATION_BUCKETS.length-1];
    for(const b of GRAVE_INJURY_DURATION_BUCKETS){ acc += b.weight; if(r <= acc){ bucket = b; break; } }
    return bucket.minDays + Math.floor(Math.random()*(bucket.maxDays-bucket.minDays+1));
  }
  function formatInjuryDuration(days){
    if(days>=60) return `${Math.round(days/30)} meses`;
    if(days>=14) return `${Math.round(days/7)} semanas`;
    return `${days} dia${days>1?'s':''}`;
  }
  // Decide gravidade e aplica os efeitos persistentes (para além da própria saída de pista, já
  // tratada em checkInjuries). Notícia sempre gerada, mas só para o clube do utilizador — mesmo
  // padrão de "só relevante para o teu clube" já usado em generatePostGameReport/scouting/etc.
  // (pushNews não filtra por clube; o filtro é sempre responsabilidade de quem chama). Para clubes
  // de IA, uma lesão grave é resolvida já com a duração final (sem a espera de diagnóstico) — o
  // utilizador nunca veria essa fase intermédia, e manter uma fila pendente para ~100 clubes de IA
  // só acrescentaria estado sem qualquer benefício percetível.
  function applyInjuryOutcome(p, team, ctx, side){
    // Tipologia de lesões (08w-lesoes.js, 2026-10-12): tipo e zona do corpo, duração por tipo,
    // recaída durante a readaptação, plano de recuperação e boletins do departamento médico.
    const recaida = !!p.readapt && Math.random() < LES_RECAIDA_PROB;
    const grave = recaida || Math.random() < INJURY_GRAVE_CHANCE;
    const origem = lesOrigemJogo(ctx, side);
    if(grave) lesAplicarGrave(p, team, { origem, recaida });
    else lesAplicarLigeira(p, team, { origem });
  }
  // Usado em todos os pontos que escolhem um jogador do banco para entrar em pista (substituições,
  // puxar/repor guarda-redes, reposição de urgência do mínimo em pista, fim de inferioridade
  // numérica, gestão de cansaço da IA, elegibilidade para grandes penalidades, escolha manual do
  // substituto noutra lesão) — um jogador com lesão grave NESTA partida nunca é candidato,
  // mesmo continuando fisicamente "no banco" (ver applyInjuryOutcome).
  function jogadorDisponivelNestaPartida(p){ return !p.__lesaoGraveNestaPartida; }
  // Resolve os diagnósticos do departamento médico assim que chega a data de resposta — mesmo
  // padrão de fila pendente já usado para relatórios de scouting/investimentos/carreira do
  // treinador, chamado a partir do mesmo ponto único de avanço de dia (dailyConditionRecovery,
  // 09-fluxo-epoca.js).
  function resolvePendingMedicalEvaluations(date){
    if(!Array.isArray(state.pendingMedicalEvaluations) || !state.pendingMedicalEvaluations.length) return;
    const today = new Date(date);
    const stillPending = [];
    state.pendingMedicalEvaluations.forEach(item=>{
      if(new Date(item.resolveDate) > today){ stillPending.push(item); return; }
      const team = state.teams[item.teamId];
      let player = team ? team.players.find(p=>p.id===item.playerId) : null;
      // 2026-10-16: se entretanto mudou de equipa (A↔B, empréstimo), procura-o onde estiver.
      let teamReal = team;
      if(!player){ for(const t of Object.values(state.teams)){ const f=(t.players||[]).find(p=>p.id===item.playerId); if(f){ player=f; teamReal=t; break; } } }
      if(!player || !player.lesaoInfo || !player.lesaoInfo.diagnosticoPendente) return; // já tratado (ex.: dispensado/vendido entretanto)
      lesResolverDiagnostico(player, teamReal, item);
      pushNews(today, lesRelatorioHtml(player, teamReal, "diagnostico"), "clinico", `Diagnóstico: ${player.name}`, {autoAdvanceStop:true, teamId:teamReal.id});
    });
    state.pendingMedicalEvaluations = stillPending;
  }
  function checkInjuries(ctx){
    if(ctx.paused) return;
    ["home","away"].forEach(side=>{
      if(ctx.paused) return;
      const lu = ctx.lineups[side];
      const onRink = [lu.gr].concat(lu.outfield).filter(Boolean);
      onRink.forEach(p=>{
        if(ctx.paused) return;
        if(Math.random() < injuryChance(p, ctx, side)){
          const team = state.teams[side==="home"?ctx.homeId:ctx.awayId];
          applyInjuryOutcome(p, team, ctx, side);
          addLog(ctx, ctx.clock, "sistema", `🚑 ${p.name} (${teamName(ctx,side)}) sofre uma lesão — a equipa médica entra em pista!`);
          ctx.injuriesThisMatch.push({ name:p.name, side, pos:p.pos });
          if(!isAiControlled(ctx, side)){
            ctx.paused = true;
            ctx.injury = { side, player: p };
          } else {
            autoSubAI(ctx, side, p);
          }
        }
      });
    });
  }

  // =================================================================
  // Match engine (ctx-based, shared by live and quick simulation)
  // =================================================================
  const CATEGORY_PERIOD_SECONDS = 25*60;
  const PACE_START = 0.10, PACE_END_FRAC = 0.97, PACE_BOOST = 1.05, PACE_CONV_COMP = 1.08;
  const HOME_ADV_ATTACK = 1.06;  // jogar em casa dá uma pequena vantagem ofensiva
  const HOME_ADV_DEFENSE = 1.03; // e defensiva (apoio da claque, conhecimento da pista)
  const ATTACK_LIMIT = 45;
  const TICK_GAME_SECONDS = 5;

  // ---- Desconto de tempo (Art.9 do Regulamento Técnico) ----
  // 2 descontos de 1 minuto por equipa, por parte do tempo regulamentar — nunca no prolongamento.
  // O jogo para por completo (as duas equipas recuperam um pouco de fadiga), e quem pede escolhe
  // uma mensagem ao grupo com um pequeno efeito tático/moral temporário na própria equipa, além de
  // "gelar" a próxima bola parada do adversário durante a janela seguinte.
  const TIMEOUTS_PER_PERIOD = 2;
  const TIMEOUT_FITNESS_RECOVERY = 4; // é só um minuto — recuperação ligeira, não como o intervalo
  const TIMEOUT_MENTAL_BUFF_SECONDS = 240; // 4 minutos de jogo com o efeito da mensagem ativo
  const TIMEOUT_ICING_WINDOW_SECONDS = 180; // janela em que a próxima bola parada do adversário sai gelada
  const TIMEOUT_ICING_SKILL_PENALTY = 2.5;
  const TIMEOUT_MESSAGES = {
    motivar: { label: "Motivar o grupo", attackMult: 1.06, defenseMult: 1.00, moralDelta: 3 },
    serenar: { label: "Serenar os ânimos", attackMult: 0.97, defenseMult: 1.06, moralDelta: 1 },
    focar:   { label: "Focar a concentração", attackMult: 1.03, defenseMult: 1.03, moralDelta: 2 },
  };

  function randNormalApprox(mean, stdev){
    // Aproximação de Irwin-Hall: soma de 12 uniformes tem média 6 e variância 1
    let sum = 0;
    for(let i=0;i<12;i++) sum += Math.random();
    return mean + (sum-6)*stdev;
  }

  function opponentPaceSkillLevel(team){
    const outfield = team.players.filter(p=>p.pos==="J");
    if(!outfield.length) return 10;
    return avg(outfield.map(p=>((p.attrs.velocidade||14)+(p.attrs.aceleracao||14)+(p.attrs.habilidade||14))/3));
  }

  // Remates por jogo: média 32 por equipa (desvio-padrão ~20%), a subir com melhores stats
  // ofensivos do plantel atacante e com a tática escolhida (ofensivo gera mais remates,
  // defensivo gera menos — a equipa abdica de volume de ataque em troca de solidez).
  function computeShotTarget(attackTeam){
    const outfield = attackTeam.players.filter(p=>p.pos==="J");
    const avgOff = outfield.length ? avg(outfield.map(p=>(p.attrs.habilidade+p.attrs.criatividade+p.attrs.drible+p.attrs.velocidade)/4)) : 14;
    const qualityMultiplier = clamp(1 + (avgOff-14)*0.025, 0.72, 1.30);
    const mean = 29 * qualityMultiplier;
    return clamp(Math.round(randNormalApprox(mean, mean*0.16)), 16, 44);
  }
  // Multiplicadores de tática avaliados EM DIRETO (não fixados no início do jogo) — para que
  // mudar de tática a meio da partida tenha efeito imediato nos remates e na conversão restantes.
  function liveShotTacticMult(team){
    const outfield = team.players.filter(p=>p.pos==="J");
    if(team.mentalidade==="ofensivo") return clamp(1 + 0.10*tacticFitBoost(outfield,"ofensivo"), 1.05, 1.15);
    if(team.mentalidade==="defensivo") return 0.86;
    return 1;
  }
  function liveConversionTacticMult(attackTeam, defenseTeam){
    const outfield = attackTeam.players.filter(p=>p.pos==="J");
    let mult = 1;
    if(attackTeam.mentalidade==="ofensivo") mult *= 1 + 0.08*tacticFitBoost(outfield,"ofensivo");
    if(attackTeam.mentalidade==="defensivo") mult *= 0.90;
    if(defenseTeam){
      const defOutfield = defenseTeam.players.filter(p=>p.pos==="J");
      if(defenseTeam.mentalidade==="defensivo") mult *= 1 - 0.14*tacticFitBoost(defOutfield,"defensivo");
      if(defenseTeam.mentalidade==="ofensivo"){
        // Correção (bug real, reportado pelo utilizador: "estão a acontecer demasiados golos nos
        // primeiros minutos de jogo" / marcador 5-5 aos 14' e 9-9 aos 37' da mesma partida): quando
        // AMBAS as equipas jogam em "ofensivo" (comum entre duas equipas de IA com perfil
        // semelhante), este bónus aplica-se nos dois sentidos ao mesmo tempo — cada equipa beneficia
        // da desorganização defensiva da outra. Com o bónus antigo (1.12 fixo + até +15% por
        // desencontro de ritmo) e o teto do multiplicador em 1.35, simulações em lote mostraram
        // caudas extremas plausíveis (até ~26 golos combinados numa partida inteira em cenários de
        // pior caso, quando as duas equipas mantêm "ofensivo" o jogo todo). Reduzido o bónus base
        // (1.12→1.08) e o máximo do desencontro de ritmo (0.25→0.15), e apertado o teto do
        // multiplicador (1.35→1.20) — a média em jogo normal (uma só equipa ofensiva, ou nenhuma)
        // quase não muda, só a cauda do cenário "ofensivo contra ofensivo" fica mais contida.
        mult *= 1.08;
        if(outfield.length && defOutfield.length){
          const attackPace = avg(outfield.map(p=>((p.attrs.velocidade||14)+(p.attrs.aceleracao||14))/2));
          const defSolidity = avg(defOutfield.map(p=>((p.attrs.posicionamento||14)+(p.attrs.forca||14)+(p.attrs.desarme||14))/3));
          const paceMismatch = clamp((attackPace-defSolidity)/14, 0, 0.6);
          mult *= 1 + paceMismatch*0.15;
        }
      }
    }
    return clamp(mult, 0.78, 1.20);
  }
  // Conversão média 11% (desvio-padrão ~5 pontos percentuais): sobe com a finalização/habilidade
  // do ataque, desce contra um guarda-redes de maior qualidade (base de qualidade, fixada no
  // início do jogo — a componente tática é aplicada em direto, ver liveConversionTacticMult).
  function computeConversionTarget(attackTeam, defenseTeam, defenseGK){
    const outfield = attackTeam.players.filter(p=>p.pos==="J");
    const avgFinish = outfield.length ? avg(outfield.map(p=>(p.attrs.finalizacao+p.attrs.habilidade)/2)) : 14;
    const gkQuality = defenseGK ? (defenseGK.attrs.reflexos+defenseGK.attrs.umParaUm)/2 : 14;
    const mean = clamp(0.072 + (avgFinish-14)*0.006 - (gkQuality-14)*0.006, 0.02, 0.18);
    return clamp(mean + randNormalApprox(0,0.020), 0.02, 0.40);
  }

  let ctxViagem = null;
  let ctxTv = null;
  function newMatchState(homeId, awayId, isPlayoff, neutralVenue, isEuropa, competitionId){
    const home = state.teams[homeId], away = state.teams[awayId];
    // Personalidade (2026-10-12): oscilação dos instáveis e bónus dos líderes nos jogos grandes.
    persPrepararJogo(home, away, !!isPlayoff || !!isEuropa || (typeof isDerby === "function" && isDerby(homeId, awayId)));
    // a IA escolhe a tática consoante o plantel — em jogos ao vivo do utilizador, a tática do
    // seu lado é restaurada logo a seguir em newLiveMatchState (nunca decidida pela IA).
    home.mentalidade = chooseAiMentalidade(home);
    away.mentalidade = chooseAiMentalidade(away);
    home.pressao = chooseAiPressao(home);
    away.pressao = chooseAiPressao(away);
    home.sistema = chooseAiSistema(home);
    away.sistema = chooseAiSistema(away);
    // Amigáveis (2026-10-12): o treinador de IA experimenta o outro sistema e roda o plantel.
    if(state.pendingAmigavel && typeof amigExperimentarIA === "function"){ amigExperimentarIA(home); amigExperimentarIA(away); }
    const lineups = { home:getLineup(home), away:getLineup(away) };
    if(state.pendingAmigavel && typeof amigRodarIA === "function"){ amigRodarIA(home, lineups.home); amigRodarIA(away, lineups.away); }
    const bench = { home:[], away:[] };
    ["home","away"].forEach(side=>{
      const team = side==="home"?home:away;
      const lu = lineups[side];
      const onRinkIds = new Set([lu.gr?lu.gr.id:null].concat(lu.outfield.map(p=>p.id)).filter(Boolean));
      // banco = resto da convocatória (máx. 2 GR + 8 JC no total, os melhores disponíveis) —
      // nunca o plantel inteiro. Aplica-se tanto a jogos ao vivo como simulados, para a IA
      // nunca poder usar mais de 10 convocados numa só partida.
      const availableGRs = team.players.filter(p=>p.pos==="GR" && playerAvailableForMatch(p) && !onRinkIds.has(p.id))
        .sort((a,b)=>overall(b)-overall(a)).slice(0, Math.max(0, CONVOCATORIA_MAX_GR - (lu.gr?1:0)));
      const availableJs = team.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p) && !onRinkIds.has(p.id))
        .sort((a,b)=>overall(b)-overall(a)).slice(0, Math.max(0, CONVOCATORIA_MAX_J - lu.outfield.length));
      bench[side] = availableGRs.concat(availableJs);
    });
    // Viagens (2026-10-12): o visitante chega cansado conforme a distância (zona geográfica) — a
    // condição persistente dos convocados desce antes do apito inicial. A equipa do utilizador
    // trata-se em newLiveMatchState (a convocatória dele é a que escolheu, não a automática).
    ctxViagem = null;
    if(viagemAplicavel(home, away, neutralVenue)) ctxViagem = viagemInfo(home, away, null);
    // Televisão (2026-10-12): o jogo escolhido pela Federação muda de horário; o descanso ajusta-se.
    ctxTv = (!isPlayoff && !isEuropa && !neutralVenue && !state.pendingAmigavel) ? tvInfoDoJogo(competitionId, homeId, awayId) : null;
    ["home","away"].forEach(side=>{
      const team = side==="home"?home:away;
      if(team.id === state.userTeamId) return;
      preJogoAplicarCondicao({ viagem: ctxViagem, tv: ctxTv }, side, [lineups[side].gr].concat(lineups[side].outfield, bench[side]));
    });
    ["home","away"].forEach(side=>{
      const lu = lineups[side];
      // a condição física inicial da partida é sempre a condição persistente do plantel —
      // nunca reinicia a 100% só porque um jogo está a começar.
      [lu.gr].concat(lu.outfield).forEach(p=>{ if(p){ p.__matchRatingDelta=0; p.__matchGoals=0; p.__matchAssists=0; p.__matchGolosSofridos=0; p.__cardsThisMatch=[]; p.__fitness = p.condicao!=null?p.condicao:100; p.__lesaoGraveNestaPartida=false; } });
      bench[side].forEach(p=>{ p.__fitness = p.condicao!=null?p.condicao:100; p.__cardsThisMatch=[]; p.__matchGoals=0; p.__matchAssists=0; p.__matchGolosSofridos=0; p.__matchRatingDelta=0; p.__lesaoGraveNestaPartida=false; });
    });
    // contra adversários mais rápidos/hábeis é normal cometer mais faltas para os travar
    const homeExtraFaltas = clamp((opponentPaceSkillLevel(away)-14)*0.28, -1.5, 2.5);
    const awayExtraFaltas = clamp((opponentPaceSkillLevel(home)-14)*0.28, -1.5, 2.5);
    const targetShots = { home: computeShotTarget(home), away: computeShotTarget(away) };
    const targetConversion = { home: computeConversionTarget(home, away, lineups.away.gr), away: computeConversionTarget(away, home, lineups.home.gr) };
    const initialPlayedSet = { home:new Set([lineups.home.gr?lineups.home.gr.id:null].concat(lineups.home.outfield.map(p=>p.id)).filter(Boolean)),
                                away:new Set([lineups.away.gr?lineups.away.gr.id:null].concat(lineups.away.outfield.map(p=>p.id)).filter(Boolean)) };
    const ctx = {
      homeId, awayId, lineups, isPlayoff: !!isPlayoff, neutralVenue: !!neutralVenue,
      isFriendly: !!state.pendingAmigavel, viagem: ctxViagem, tv: ctxTv,
      period:1, clock:0, periodLength: CATEGORY_PERIOD_SECONDS,
      finished:false, score:{home:0,away:0},
      faltas:{home:0,away:0}, cartoes:{home:[],away:[]}, inferioridade:{home:0,away:0},
      targetShots, targetConversion,
      // faltas/cartões de equipa: cada jogo sorteia um "alvo" por equipa (média 9,1 faltas,
      // desvio-padrão baixo de 0,5), ajustado para cima contra adversários rápidos/hábeis.
      targetFaltas: { home: Math.max(2, Math.round(randNormalApprox(9.1,2.6)+homeExtraFaltas)), away: Math.max(2, Math.round(randNormalApprox(9.1,2.6)+awayExtraFaltas)) },
      targetCards: { home: Math.max(0, Math.round(randNormalApprox(3.35,0.5))), away: Math.max(0, Math.round(randNormalApprox(3.35,0.5))) },
      cardsIssued: { home:0, away:0 },
      // Sistema de "fila" de cartões azuis: nunca menos de 3 jogadores de campo em pista.
      // penaltyQueue guarda quem ainda tem de cumprir tempo (ordem de chegada); penaltyClock é
      // o relógio único a decorrer para quem está à frente da fila — o seguinte só começa a
      // contar quando o da frente terminar (tal como no hóquei em gelo com penalizações empilhadas).
      penaltyQueue: { home: [], away: [] }, penaltyClock: { home: 0, away: 0 },
      pendingReturnPrompt: null, ejected: { home:[], away:[] }, simulating:false,
      shots: { home:0, away:0 }, goalsFromShots: { home:0, away:0 }, disallowedGoals: { home:0, away:0 }, possessionSeconds: { home:0, away:0 }, injuriesThisMatch: [],
      posse:{team:"home", clock:ATTACK_LIMIT},
      // Recinto neutro (Final Four da Taça de Portugal, Artigo 93.º/99.º do RGHP): sem vantagem
      // de jogar em casa — neutralVenue desliga o HOME_ADV_ATTACK/DEFENSE só aqui.
      homeStr: { attack: teamStrength(home, away).attack*(neutralVenue?1:HOME_ADV_ATTACK*adeptosHomeFactor(home)), defense: teamStrength(home, away).defense*(neutralVenue?1:HOME_ADV_DEFENSE*adeptosHomeFactor(home)) },
      awayStr: teamStrength(away, home),
      log: [], soHome:null, soAway:null, soWinner:null,
      live:false, userSide:null, paused:false, injury:null,
      bench,
      absoluteClock: 0,
      lastSubTick: { home:-999, away:-999 },
      intensity: matchIntensityFactor(home),
      lastTacticTick: { home:-999, away:-999 },
      // titulares reais desta partida (antes de qualquer substituição) — usado para distinguir,
      // nas estatísticas de época, quem começou no banco de quem foi titular.
      startingIds: { home: new Set(initialPlayedSet.home), away: new Set(initialPlayedSet.away) },
      playedSet: initialPlayedSet,
      eventMetrics: [], savesBySide:{home:0,away:0}, setPieces:{home:{penalti:0,livredireto:0},away:{penalti:0,livredireto:0}},
      semGuardaRedes:{home:false,away:false}, semGuardaRedesExtra:{home:null,away:null}, semGuardaRedesGK:{home:null,away:null},
      penaltiesAwarded:{home:0,away:0},
      reboundStats:{home:{looseBalls:0,attempts:0,goals:0},away:{looseBalls:0,attempts:0,goals:0}},
      // Descontos de tempo (Art.9): 2 por parte do tempo regulamentar, nenhum no prolongamento.
      timeoutsLeft: { home: TIMEOUTS_PER_PERIOD, away: TIMEOUTS_PER_PERIOD },
      lastTimeoutTick: { home:-999, away:-999 },
      timeoutMentalBuff: { home:null, away:null },
      icedUntil: { home:0, away:0 },
    };
    // Correção (pedido do utilizador, 2026-09-17: "a assistência está sempre a variar durante a
    // partida — tem de ser um número fixo, pq são os bilhetes vendidos"): matchAttendance tem um
    // fator aleatório (randomFactor) recalculado a cada chamada — antes, o ecrã ao vivo
    // (renderMatchDesk) e o fecho de contas (processMatchFinances) chamavam-na cada um por si,
    // dando números diferentes e a mudar tick a tick. Calcula-se agora uma única vez aqui, à
    // cabeça do jogo (antes de o público entrar, tal como bilhetes vendidos antecipadamente), e
    // reutiliza-se tanto no ecrã como no fecho de contas.
    ctx.isEuropa = !!isEuropa;
    // Prémios de fim de época (2026-09-21): antes desta correção, competitionId nunca era
    // preenchido em lado nenhum do motor — todos os jogos (taças, Europa, playoffs, divisões de
    // outros clubes) ficavam registados em participacaoCompeticoes como se fossem da competição
    // do próprio utilizador (fallback em finalizePlayerStats). Cada chamador de newMatchState/
    // newLiveMatchState/simulateMatchToCompletion passa agora o id real da competição.
    ctx.competitionId = competitionId || null;
    ctx.attendance = matchAttendance(home, away, { playoff: ctx.isPlayoff, europa: ctx.isEuropa });
    arbitroAplicar(ctx); // Árbitros com perfil (08q-arbitros.js): cartões, faltas, penáltis, viés caseiro e erros
    anaAplicar(ctx); // Análise do adversário (08r-analise.js): contramedidas do utilizador e preparação da IA
    return ctx;
  }

  // Builds a live match where the user's side lineup/bench come from the manager's own
  // convocatória + escalação choices, and the AI side is auto-picked as before.
  function newLiveMatchState(homeId, awayId, userGR, userOutfield, userBenchPlayers, isPlayoff, neutralVenue, isEuropa, competitionId){
    // Correção (pedido do utilizador, 2026-09-26: "quando carrego nestas setas, deixo de
    // conseguir voltar a por em tempo real") — matchEventCursor é uma variável de módulo, não
    // parte do ctx, por isso sobrevivia entre partidas: se o utilizador tivesse navegado pelo
    // relato (◀ ▶) numa partida anterior, a próxima partida ao vivo começava já "presa" nesse
    // índice antigo, mesmo com um relato novo e mais curto. Reinicia-se sempre no arranque de
    // cada partida ao vivo, para começar sempre a acompanhar em tempo real.
    matchEventCursor = null;
    const userTeamPreMentalidade = state.userTeamId && state.teams[state.userTeamId] ? state.teams[state.userTeamId].mentalidade : null;
    const userTeamPrePressao = state.userTeamId && state.teams[state.userTeamId] ? state.teams[state.userTeamId].pressao : null;
    const userTeamPreSistema = state.userTeamId && state.teams[state.userTeamId] ? state.teams[state.userTeamId].sistema : null;
    const ctx = newMatchState(homeId, awayId, isPlayoff, neutralVenue, isEuropa, competitionId);
    // a tática e a agressividade do utilizador nunca são escolhidas pela IA — newMatchState
    // pode tê-las alterado (decide sempre para ambos os lados, por ser também usada na
    // simulação rápida), por isso repõem-se aqui as que o utilizador tinha mesmo selecionado.
    if(userTeamPreMentalidade != null) state.teams[state.userTeamId].mentalidade = userTeamPreMentalidade;
    if(userTeamPrePressao != null) state.teams[state.userTeamId].pressao = userTeamPrePressao;
    if(userTeamPreSistema != null) state.teams[state.userTeamId].sistema = userTeamPreSistema;
    ctx.live = true;
    ctx.userSide = (homeId === state.userTeamId) ? "home" : "away";
    const aiSide = ctx.userSide === "home" ? "away" : "home";

    ctx.lineups[ctx.userSide] = { gr:userGR, outfield:userOutfield.slice() };
    // Viagens: se o utilizador joga fora, a fadiga aplica-se à convocatória que ele escolheu.
    preJogoAplicarCondicao(ctx, ctx.userSide, [userGR].concat(userOutfield, userBenchPlayers));
    [userGR].concat(userOutfield).forEach(p=>{ if(p){ p.__matchRatingDelta=0; p.__matchGoals=0; p.__matchAssists=0; p.__matchGolosSofridos=0; p.__cardsThisMatch=[]; p.__fitness = p.condicao!=null?p.condicao:100; p.__lesaoGraveNestaPartida=false; } });
    ctx.bench[ctx.userSide] = userBenchPlayers.slice();
    userBenchPlayers.forEach(p=>{ p.__fitness = p.condicao!=null?p.condicao:100; p.__cardsThisMatch=[]; p.__matchGoals=0; p.__matchAssists=0; p.__matchGolosSofridos=0; p.__matchRatingDelta=0; p.__lesaoGraveNestaPartida=false; });
    ctx.playedSet[ctx.userSide] = new Set([userGR?userGR.id:null].concat(userOutfield.map(p=>p.id)).filter(Boolean));
    ctx.startingIds[ctx.userSide] = new Set(ctx.playedSet[ctx.userSide]);

    const aiTeam = state.teams[aiSide==="home"?homeId:awayId];
    const aiOnRink = [ctx.lineups[aiSide].gr].concat(ctx.lineups[aiSide].outfield).filter(Boolean);
    const aiOnRinkIds = new Set(aiOnRink.map(p=>p.id));
    const aiOnRinkGRCount = ctx.lineups[aiSide].gr ? 1 : 0;
    const aiAvailableGRs = aiTeam.players.filter(p=>p.pos==="GR" && playerAvailableForMatch(p) && !aiOnRinkIds.has(p.id))
      .sort((a,b)=>overall(b)-overall(a)).slice(0, Math.max(0, CONVOCATORIA_MAX_GR - aiOnRinkGRCount));
    const aiAvailableJs = aiTeam.players.filter(p=>p.pos==="J" && playerAvailableForMatch(p) && !aiOnRinkIds.has(p.id))
      .sort((a,b)=>overall(b)-overall(a)).slice(0, Math.max(0, CONVOCATORIA_MAX_J - ctx.lineups[aiSide].outfield.length));
    ctx.bench[aiSide] = aiAvailableGRs.concat(aiAvailableJs);
    ctx.bench[aiSide].forEach(p=>{ p.__fitness = p.condicao!=null?p.condicao:100; p.__cardsThisMatch=[]; p.__matchGoals=0; p.__matchAssists=0; p.__matchGolosSofridos=0; p.__matchRatingDelta=0; p.__lesaoGraveNestaPartida=false; });

    return ctx;
  }


  function fmtClock(elapsed, total){
    const rem = Math.max(0, total-elapsed);
    return String(Math.floor(rem/60)).padStart(2,"0")+":"+String(Math.floor(rem%60)).padStart(2,"0");
  }
  // Relógio de tensão (pedido do utilizador, 2026-10-05: "quero mexer na contagem decrescente nos
  // ultimos 3 minutos, quando há uma diferença menor ou igual a 2 golos"): nos últimos 3 minutos
  // do tempo decisivo do jogo (2ª parte e prolongamentos — numa 1ª parte quase todos os jogos
  // teriam diferença <= 2 e o efeito perderia o sentido) o relógio pulsa e fica vermelho, com um
  // ritmo mais rápido no último minuto. Só aparece com o jogo ainda decidível (diferença de golos
  // <= 2) — um 7-1 já resolvido não tem tensão nenhuma.
  function clockTensionLevel(m){
    if(!m || !m.score || m.period==="SO" || m.period===1) return 0;
    if(Math.abs((m.score.home||0)-(m.score.away||0)) > 2) return 0;
    const restante = (m.periodLength||0) - (m.clock||0);
    if(restante <= 0 || restante > 180) return 0;
    return restante <= 60 ? 2 : 1;
  }
  function applyClockTension(m){
    const el = document.getElementById("clockDisplay");
    if(!el) return;
    const lvl = clockTensionLevel(m);
    el.classList.toggle("clock-tense", lvl===1);
    el.classList.toggle("clock-critical", lvl===2);
  }
  function periodLabel(p){
    return p===1?"1ª PARTE":p===2?"2ª PARTE":p==="OT1"?"PROLONG. 1":p==="OT2"?"PROLONG. 2":p==="SO"?"GRANDES PENALIDADES":"";
  }
  function teamName(ctx, side){ return side==="home" ? state.teams[ctx.homeId].name : state.teams[ctx.awayId].name; }
  // player/side (opcionais): nome do jogador e lado (home/away) do evento, usados pela lista
  // compacta de golos/cartões no meio da mesa (renderKeyEvents) — evita ter de extrair o nome
  // por regex a partir do texto de relato, que tem dezenas de variantes de frase diferentes.
  function addLog(ctx, m, type, text, player, side){
    const label = (typeof m==="number") ? String(Math.floor(m/60)).padStart(2,"0")+"'" : m;
    ctx.log.push({label, type: type||"normal", text, player: player||null, side: side||null});
    if(type==="golo" && ctx===state.match){
      ctx.goalCelebrationUntil=Date.now()+2700;
      ctx.goalCelebrationKey=ctx.log.length;
    }
    if(ctx===state.match) renderFeed();
  }
  function renderFeed(){
    const feed = document.getElementById("feed");
    if(!state.match || state.match.log.length===0){
      feed.innerHTML = '<div class="feed-empty">O relato do teu jogo aparece aqui assim que simulares a jornada.</div>';
      return;
    }
    feed.innerHTML = state.match.log.map(l=>{
      const cls = l.type==="golo"?"golo":l.type==="amarelo"?"cartao-amarelo":l.type==="azul"?"cartao-azul":l.type==="vermelho"?"cartao-vermelho":l.type==="sistema"?"sistema":"";
      const cat=matchEventCategory(l),hidden=matchReportFilter!=="all"&&matchReportFilter!==cat;
      return `<div class="feed-line ${cls}${hidden?' hidden-by-filter':''}" data-category="${cat}"><span class="tm">${l.label}</span><span>${l.text}</span></div>`;
    }).join("");
    feed.scrollTop = feed.scrollHeight;
  }
  // Pedido do utilizador: golos e cartões (azul/amarelo/vermelho) só eram visíveis na íntegra no
  // separador "Relato" (feed completo, com filtros) ou navegando evento a evento com ◀ ▶ — na
  // página principal da partida ("Jogo", o separador ativo por omissão) só se via o placar e o
  // último evento, sem um resumo persistente de quem marcou/foi mostrado o cartão. Nova lista
  // compacta e sempre visível no meio da mesa (entre o bloco de posse e o relato principal — ver
  // .match-key-events em cm3-theme.css): só o nome do jogador e o minuto (não a frase de relato
  // inteira), cor do nome de acordo com o tipo de evento, coluna da esquerda para a equipa da
  // casa e da direita para a equipa de fora — tal como aparecem no placar por cima. Usa
  // player/side gravados em addLog (ver acima) em vez de tentar extrair o nome do texto de
  // relato, que tem dezenas de variantes de frase diferentes consoante o evento.
  function renderKeyEvents(ctx){
    const box = document.getElementById("matchKeyEvents");
    if(!box) return;
    const events = (ctx && ctx.log ? ctx.log : []).filter(l=>["golo","amarelo","azul","vermelho"].includes(l.type) && l.player && l.side);
    if(!events.length){
      box.innerHTML = '<div class="feed-empty">Os golos e cartões aparecem aqui.</div>';
      return;
    }
    const lineHtml = l => {
      const cls = l.type==="golo"?"ke-golo":l.type==="amarelo"?"ke-amarelo":l.type==="azul"?"ke-azul":"ke-vermelho";
      return `<div class="ke-line"><span class="${cls}">${escapeHtml(l.player)}</span><span class="ke-min">${l.label}</span></div>`;
    };
    const homeHtml = events.filter(l=>l.side==="home").map(lineHtml).join("");
    const awayHtml = events.filter(l=>l.side==="away").map(lineHtml).join("");
    box.innerHTML = `<div class="ke-col ke-col-home">${homeHtml}</div><div class="ke-col ke-col-away">${awayHtml}</div>`;
    box.scrollTop = box.scrollHeight;
  }

  // Correção: o cabeçalho do jogo ao vivo mostrava sempre "Época X · Jornada Y de Z" da liga do
  // utilizador, mesmo quando o jogo em curso era da Taça de Portugal, do playoff, ou de uma
  // liguilha/final de apuramento — nesses casos a informação estava errada ou sem sentido
  // nenhum. Passa a identificar corretamente a competição e a fase/jornada certa em cada caso.
  function currentMatchContextLabel(){
    if(state.pendingAmigavel) return "Jogo de preparação";
    if(state.pendingSupertaca){
      return "Supertaça António Livramento";
    }
    if(state.pendingTacaPortugalFase!=null){
      return TACA_FASE_LABEL[state.pendingTacaPortugalFase];
    }
    if(state.pendingEliteCupFase!=null){
      return ELITE_CUP_FASE_LABEL[state.pendingEliteCupFase];
    }
    if(state.pendingPromotionTieGameIndex!=null){
      return `CN 2.ª Divisão Apuramento Promoção — Jogo ${state.pendingPromotionTieGameIndex+1}`;
    }
    if(state.pendingSecondDivisionFinalGameIndex!=null){
      return `CN 2.ª Divisão Apuramento Campeão — Jogo ${state.pendingSecondDivisionFinalGameIndex+1}`;
    }
    if(state.pendingPlayoffSeries){
      return `${competitionLabel(state.userCompetitionId)} — ${state.pendingPlayoffSeries.label}`;
    }
    if(state.pendingCopaDelReyFase!=null){
      return `Copa del Rey — ${NATIONAL_CUP_FASE_LABEL[state.pendingCopaDelReyFase]}`;
    }
    if(state.pendingCoppaItaliaFase!=null){
      return `Coppa Italia — ${NATIONAL_CUP_FASE_LABEL[state.pendingCoppaItaliaFase]}`;
    }
    if(state.pendingSupercopaEspanaFase!=null){
      return `Supercopa de España — ${state.pendingSupercopaEspanaFase==="final"?"Final":"Meia-Final"}`;
    }
    if(state.pendingSupercoppaItalianaLeg){
      return `Supercoppa Italiana — ${state.pendingSupercoppaItalianaLeg==="leg1"?"1ª mão":"2ª mão"}`;
    }
    if(state.pendingEuropaSlot){
      const slot = state.pendingEuropaSlot;
      if(slot.tipo==="grupo"){ const g = europaGroupById(slot.grupoId); return g ? g.nome : "Europa"; }
      const bracket = europaBracketById(slot.bracketId);
      return bracket ? `${bracket.label} — ${EUROPA_FASE_LABEL[slot.fase]||slot.fase}` : "Europa";
    }
    const total = state.fixtures.length;
    return `${competitionLabel(state.userCompetitionId)} — Jornada ${Math.min(state.currentRound+1,total)} de ${total}`;
  }
  // Id da competição da partida em curso, ou null se for uma competição "à parte" (Taça, Elite
  // Cup, Supertaça, playoffs de acesso/final da 2ª Divisão, taças/supertaças de Espanha/Itália,
  // Europa) — usado para decidir quando mostrar o logótipo de uma competição no cabeçalho da
  // partida (pedido do utilizador, 2026-09-25: o logo do Campeonato Placard "tem de aparecer...
  // nas partidas que forem placard", não nas restantes competições mesmo que o utilizador jogue
  // no Placard). Espelha exactamente os mesmos "pendingX" verificados em
  // currentMatchContextLabel() acima — quando nenhum está activo, a partida é sempre da liga
  // regular do utilizador (ou do seu playoff, servido pela mesma branch de competitionLabel).
  function currentMatchCompetitionId(){
    if(state.pendingAmigavel || state.pendingSupertaca || state.pendingTacaPortugalFase!=null || state.pendingEliteCupFase!=null ||
       state.pendingPromotionTieGameIndex!=null || state.pendingSecondDivisionFinalGameIndex!=null ||
       state.pendingCopaDelReyFase!=null || state.pendingCoppaItaliaFase!=null ||
       state.pendingSupercopaEspanaFase!=null || state.pendingSupercoppaItalianaLeg || state.pendingEuropaSlot){
      return null;
    }
    return state.userCompetitionId;
  }
  // Escudo/badge de clube na mesa de jogo (pedido do utilizador, 2026-09-25: "os logotipos dos
  // clubes também têm de aparecer nas partidas") — mesmo padrão já usado em #myClubDot
  // (renderAll, 10-estatisticas.js): escudo real (clubCrestUrl) quando existe para o clube, senão
  // um círculo com a cor do clube (clubDisplayColor) e as suas iniciais (clubBadgeInitials),
  // sempre legível via contrastText. Chamado a cada renderScoreboard() — o mesmo padrão do resto
  // desta função, que já reescreve vários elementos sem condições a cada chamada.
  function setTeamCrestDot(el, team){
    if(!el) return;
    if(!team){
      el.classList.remove("has-crest"); el.innerHTML = ""; el.style.background = "transparent"; el.style.color = "";
      return;
    }
    const crestUrl = clubCrestUrl(team.id);
    if(crestUrl){
      el.classList.add("has-crest");
      el.style.background = ""; el.style.color = "";
      el.innerHTML = `<img src="${crestUrl}" alt="" class="crest-img">`;
    } else {
      el.classList.remove("has-crest");
      const bg = clubDisplayColor(team);
      el.style.background = bg; el.style.color = clubTextColor(team, bg);
      el.textContent = clubBadgeInitials(team.name);
    }
  }
  function renderScoreboard(){
    const m = state.match;
    document.getElementById("jornadaLabel").textContent = currentMatchContextLabel();
    // Logótipo da competição no cabeçalho da partida (pedido do utilizador, 2026-09-25: o logo
    // real do Campeonato Placard "tem de aparecer... nas partidas que forem placard") — só
    // aparece quando currentMatchCompetitionId() tem logo definido (ver competitionLogoUrl,
    // 01-nucleo.js); escondido nas restantes competições (Taça, Elite Cup, Supertaça, etc.).
    const jornadaLogoEl = document.getElementById("jornadaLogo");
    if(jornadaLogoEl){
      const logoUrl = competitionLogoUrl(currentMatchCompetitionId());
      if(logoUrl){ jornadaLogoEl.src = logoUrl; jornadaLogoEl.classList.remove("hidden"); }
      else { jornadaLogoEl.removeAttribute("src"); jornadaLogoEl.classList.add("hidden"); }
    }
    if(!m){
      document.getElementById("homeNameSb").textContent = state.userTeamId ? myTeam().name.toUpperCase() : "—";
      document.getElementById("awayNameSb").textContent = "—";
      setTeamCrestDot(document.getElementById("homeCrestDot"), state.userTeamId ? myTeam() : null);
      setTeamCrestDot(document.getElementById("awayCrestDot"), null);
      document.getElementById("homeScore").textContent = "0"; document.getElementById("awayScore").textContent = "0";
      document.getElementById("clockDisplay").textContent = "00:00"; document.getElementById("periodTag").textContent = "1ª PARTE";
      applyClockTension(null);
      document.getElementById("homeFaltas").textContent = "0"; document.getElementById("awayFaltas").textContent = "0";
      document.getElementById("homeCartoes").innerHTML = ""; document.getElementById("awayCartoes").innerHTML = "";
      document.getElementById("homeInferioridade").innerHTML = ""; document.getElementById("awayInferioridade").innerHTML = "";
      renderKeyEvents(null);
      document.getElementById("posseBar").style.width = "100%"; document.getElementById("posseSecs").textContent = "45s";
      document.getElementById("posseTeamLabel").textContent = "Posse de bola";
      return;
    }
    document.getElementById("homeNameSb").textContent = state.teams[m.homeId].name.toUpperCase();
    document.getElementById("awayNameSb").textContent = state.teams[m.awayId].name.toUpperCase();
    setTeamCrestDot(document.getElementById("homeCrestDot"), state.teams[m.homeId]);
    setTeamCrestDot(document.getElementById("awayCrestDot"), state.teams[m.awayId]);
    document.getElementById("homeScore").textContent = m.score.home;
    document.getElementById("awayScore").textContent = m.score.away;
    document.getElementById("periodTag").textContent = periodLabel(m.period);
    document.getElementById("clockDisplay").textContent = m.period==="SO" ? (m.shootout ? `${m.shootout.goals.home} - ${m.shootout.goals.away}` : "—") : fmtClock(m.clock, m.periodLength);
    applyClockTension(m);
    document.getElementById("homeFaltas").textContent = m.faltas.home;
    document.getElementById("awayFaltas").textContent = m.faltas.away;
    document.getElementById("homeCartoes").innerHTML = m.cartoes.home.map(c=>`<span class="cartao ${c}"></span>`).join("");
    document.getElementById("awayCartoes").innerHTML = m.cartoes.away.map(c=>`<span class="cartao ${c}"></span>`).join("");
    document.getElementById("homeInferioridade").innerHTML = m.inferioridade.home>0?`<span class="inferioridade-tag">INFERIORIDADE ${m.inferioridade.home}s</span>`:"";
    document.getElementById("awayInferioridade").innerHTML = m.inferioridade.away>0?`<span class="inferioridade-tag">INFERIORIDADE ${m.inferioridade.away}s</span>`:"";
    const pct = Math.max(0, Math.min(100,(m.posse.clock/ATTACK_LIMIT)*100));
    document.getElementById("posseBar").style.width = pct+"%";
    document.getElementById("posseSecs").textContent = Math.ceil(m.posse.clock)+"s";
    document.getElementById("posseTeamLabel").textContent = "POSSE " + (m.posse.team==="home" ? state.teams[m.homeId].name : state.teams[m.awayId].name).toUpperCase();
    document.getElementById("posseSecs").textContent = Math.ceil(m.posse.clock)+"\" / 45\"";
    renderMatchDesk(m);
  }

  function turnPossession(ctx, side){ ctx.posse.team = side; ctx.posse.clock = ATTACK_LIMIT; }

  // Golpe-duplo (Art.13): reinício neutro usado quando o jogo pára sem falta assinalada e não é
  // claro qual das equipas tinha a posse — ex.: remate desenquadrado que sai de forma pouco clara,
  // recarga disputada que ninguém finaliza, ou um golo anulado (a bola já entrou, não há falta de
  // ninguém, só uma questão técnica). Em vez de entregar a posse automaticamente à defesa, decide-
  // -se por um pequeno "duelo" entre as duas equipas, quase 50/50, com ligeira vantagem a quem tem
  // jogadores mais rápidos/fortes em pista.
  // Calibração (pedido do utilizador, que segue de perto os jogos reais): 6 a 10 golpe-duplos por
  // jogo, não os ~2-3 da primeira estimativa — por isso as taxas abaixo são bem mais altas do que
  // pareceria "razoável" à primeira vista.
  const GOLPE_DUPLO_MISS_CHANCE = 0.58;
  const GOLPE_DUPLO_POST_MISS_CHANCE = 0.85;
  const GOLPE_DUPLO_REBOUND_FAIL_CHANCE = 0.68;
  function resolveGolpeDuplo(ctx, sideA, sideB, clock, motivo){
    const duelScore = p => (p.attrs.velocidade!=null?p.attrs.velocidade:12)*0.30 + (p.attrs.aceleracao!=null?p.attrs.aceleracao:12)*0.30 + (p.attrs.forca!=null?p.attrs.forca:12)*0.25 + (p.attrs.desarme!=null?p.attrs.desarme:12)*0.15;
    const luA = ctx.lineups[sideA].outfield, luB = ctx.lineups[sideB].outfield;
    const avgA = luA.length ? avg(luA.map(duelScore)) : 12;
    const avgB = luB.length ? avg(luB.map(duelScore)) : 12;
    const probA = clamp(0.5 + (avgA-avgB)/80, 0.38, 0.62);
    const winner = Math.random() < probA ? sideA : sideB;
    addLog(ctx, clock, "normal", `⚪ Golpe-duplo${motivo?` — ${motivo}`:""}: ${teamName(ctx,winner)} fica com a posse.`);
    turnPossession(ctx, winner);
    return winner;
  }

  const GOAL_PHRASES = [
    (s,t) => `⚽ GOLO! ${s} arranca isolado e não perdoa`,
    (s,t) => `⚽ GOLO! ${s} bate colocado, sem hipótese para o guarda-redes`,
    (s,t) => `⚽ GOLO! ${s} aproveita o espaço e finaliza com categoria`,
    (s,t) => `⚽ GOLO! Jogada rápida e ${s} não desperdiça`,    (s,t) => `⚽ GOLO! ${s} faz um pequeno compasso de espera e resolve`,
    (s,t) => `⚽ GOLO! Remate seco de ${s}, sem hipótese de resposta`,
  ];
  // Escalonamento de cartão (2º amarelo no jogo = azul; 3º azul no jogo = vermelho) — extraído
  // para aqui porque é usado em três sítios agora (faltas normais, contestação, simulação).
  function escalateCardType(player, baseType){
    const already = player.__cardsThisMatch||[];
    let type = baseType;
    if(type==="amarelo" && already.includes("amarelo")) type="azul";
    const azuisAnteriores = already.filter(c=>c==="azul").length;
    if(type==="azul" && azuisAnteriores>=2) type="vermelho";
    return type;
  }
  const SAVE_PHRASES = [
    (g) => `grande defesa de ${g}!`,
    (g) => `${g} está atento e trava o remate!`,
    (g) => `${g} nega o golo com uma intervenção segura!`,
    (g) => `bola para as mãos de ${g}, sem perigo!`,
    (g) => `${g} impede o golo com reflexos!`,
    (g) => `${g} não tem tempo para as mãos e trava com o corpo!`,
    (g) => `defesa feia mas eficaz de ${g}, com o patim!`,
    (g) => `${g} estica-se todo e desvia com a perna!`,
  ];
  // Remates que não vão enquadrados à baliza — sobretudo remates de meia-distância, mais
  // difíceis de calibrar com precisão a essa distância.
  const MISS_PHRASES = [
    () => `remate que sai ao lado do poste, sem perigo`,
    () => `remate por cima da barra`,
    () => `bola desviada para a linha de fundo, sem ameaça`,
    () => `remate mal enquadrado, longe do alvo`,
    () => `falta de pontaria e a bola sai bem afastada da baliza`,
  ];
  // Remate ao poste/à barra: quase-golo mais dramático do que um simples desenquadrado — a
  // bola foi mesmo lá perto, mas não entra.
  const POST_MISS_PHRASES = [
    () => `remate no poste! Por muito pouco não é golo`,
    () => `bola bate na barra e sai! Que quase-golo`,
    () => `no poste! A bola ainda ressalta para dentro da área antes de ser afastada`,
  ];
  // Golo na recarga: o remate inicial é defendido, mas a bola sobra e alguém aproveita o
  // ressalto antes de o guarda-redes se recompor. Menciona sempre o nome da equipa (não só o
  // do marcador), para o cartão de relato conseguir detetar e colorir corretamente a equipa —
  // sem isto, o cartão fica cinzento/neutro em vez de usar a cor da equipa que marcou.
  const REBOUND_GOAL_PHRASES = [
    (s,t) => `⚽ GOLO! ${s} não perdoa com a bola a sobrar após a primeira defesa, e ${t} marca`,
    (s,t) => `⚽ GOLO! O guarda-redes ainda tenta reagir, mas ${s} está mais rápido na recarga, e ${t} marca`,
    (s,t) => `⚽ GOLO! Defesa incompleta e ${s} aproveita a recarga, e ${t} marca`,
  ];
  function pickPhrase(arr){ return arr[rnd(0, arr.length-1)]; }
  // Golos de picadinha: finalização mais técnica/subtil, usada ocasionalmente para jogadores
  // com mais habilidade/drible — variante de golo, não muda a probabilidade de conversão.
  const CHIP_GOAL_PHRASES = [
    (s,t) => `⚽ GOLO! Picadinha de ${s}, por cima do guarda-redes, com categoria`,
    (s,t) => `⚽ GOLO! ${s} levanta a bola com classe e faz a picadinha certeira`,
    (s,t) => `⚽ GOLO! Que subtileza de ${s} — bola por cima do guarda-redes, sem hipótese de resposta`,
  ];
  // Golos anulados: as três razões mais comuns no regulamento (falta anterior; golo marcado com
  // o patim ou outra parte do corpo que não o stick; bola que não ultrapassa completamente a
  // linha de golo) — raro, mas confere realismo, sobretudo em lances mais disputados.
  const DISALLOWED_GOAL_PHRASES = [
    (s) => `O árbitro assinala falta anterior de ${s} e anula o golo!`,
    (s) => `O árbitro anula o golo de ${s} — a bola entrou depois de tocar no patim, não é validado!`,
    (s) => `O árbitro consulta o auxiliar e anula o golo de ${s} — a bola não ultrapassou completamente a linha!`,
  ];
  // Amarelos por contestação: um jogador mais intenso reage mal a uma decisão da equipa de
  // arbitragem — distinto de um cartão por falta física, aplicado através do mesmo mecanismo.
  const DISSENT_YELLOW_PHRASES = [
    (p) => `${p} não gosta da decisão e reclama alto — cartão amarelo por contestação.`,
    (p) => `${p} atira-se aos árbitros a protestar — amarelo mostrado por contestação.`,
    (p) => `Reação exaltada de ${p} à decisão do árbitro — amarelo por contestação.`,
  ];
  // Amarelos por simulação: o jogador atira-se ao chão a simular uma falta que não existiu — o
  // árbitro não se deixa enganar e pune a tentativa em vez de conceder a falta.
  const SIMULATION_PHRASES = [
    (p) => `${p} atira-se ao chão a simular uma falta que não existiu — o árbitro não se deixa enganar e mostra amarelo!`,
    (p) => `Tentativa de engano de ${p}, mas o árbitro viu tudo — amarelo por simulação!`,
    (p) => `${p} exagera a queda para tentar enganar a arbitragem — amarelo mostrado, sem falta assinalada.`,
  ];
  // Variantes específicas do motivo de um cartão por falta física — inclui o "stick acima dos
  // ombros" (infração distinta no regulamento, quando o gesto coloca em perigo a integridade
  // física do adversário) ao lado do motivo genérico.
  const FOUL_CARD_REASON_PHRASES = [
    () => `entrada dura`,
    () => `stick levantado acima dos ombros, em perigo para o adversário`,
    () => `carga irregular`,
    () => `corte irregular com o stick`,
  ];

  // Lógica partilhada de aplicação de um cartão (azul/vermelho retiram o jogador de pista,
  // com fila de penalização e suplente de urgência se necessário) — usada tanto por faltas
  // físicas normais (resolveCard) como por contestação (maybeIssueDissentCard), para nunca
  // duplicar (e arriscar desalinhar) esta mecânica em dois sítios.
  function applyCardConsequences(ctx, side, player, type){
    ctx.cardsIssued[side] = (ctx.cardsIssued[side]||0) + 1;
    if(player){
      const already = player.__cardsThisMatch||[];
      if(ctx.playedSet && ctx.playedSet[side]) ctx.playedSet[side].add(player.id);
      player.__cardsThisMatch = already.concat([type]);
      bumpRating(player, type==="amarelo"?-1:type==="azul"?-1.8:-3);
      // Conselho de Disciplina (08k-disciplina.js): só a expulsão DIRETA suspende no jogo seguinte e abre processo;
      // o vermelho por acumulação de azuis só vale para o próprio jogo (Art. 22.º/24.º das Regras do Jogo).
      if(type==="vermelho" && disciplinaRegistarVermelho(ctx, side, player)) player.suspensoJogos = (player.suspensoJogos||0)+1;
    }
    ctx.cartoes[side].push(type);
    if((type==="azul" || type==="vermelho") && player){
      const pos = (ctx.lineups[side].gr === player) ? "GR" : "J";
      const duration = type==="azul" ? 120 : 240;
      const wasRed = type==="vermelho";
      const queue = ctx.penaltyQueue[side];
      const currentCount = pos==="J" ? ctx.lineups[side].outfield.length : (ctx.lineups[side].gr?1:0);
      // 2026-10-16: um guarda-redes com cartão é SEMPRE substituído de imediato (suplente GR ou, esgotado
      // o banco, jogador de emergência) — antes ficava a baliza vazia (tratada como GR médio) ou o lugar
      // perdia-se quando outro cartão se sobrepunha. "refilled" regista se o lugar já foi reposto neste
      // momento; só os não repostos são devolvidos à pista quando a fila de penalizações esvazia.
      const wouldDropBelowFloor = pos==="GR" || (pos==="J" && (currentCount - 1) < 3);
      removePlayerFromRink(ctx, side, player);
      if(wouldDropBelowFloor){ callUpImmediateReplacement(ctx, side, pos); }
      if(queue.length > 0){ ctx.inferioridade[side] += duration; }
      else { ctx.penaltyClock[side] = duration; ctx.inferioridade[side] = Math.max(ctx.inferioridade[side], duration); }
      queue.push({ player, duration, wasRed, pos, refilled: wouldDropBelowFloor });
      if(wasRed){ ctx.ejected[side].push(player); }
    }
  }
  function maybeIssueDissentCard(ctx, side, clock, chance){
    if(Math.random() >= (chance!=null?chance:0.05)) return;
    const lineup = ctx.lineups[side];
    const pool = lineup.outfield.length ? lineup.outfield : [lineup.gr].filter(Boolean);
    if(!pool.length) return;
    const player = weightedPick(pool, p => (1 + (p.attrs.agressividade!=null?p.attrs.agressividade:10)) * persCartaoMult(p));
    if(!player) return;
    const type = escalateCardType(player, "amarelo");
    const opponentName = teamName(ctx, side==="home"?"away":"home");
    if(type==="amarelo"){
      addLog(ctx, clock, "amarelo", pickPhrase(DISSENT_YELLOW_PHRASES)(player.name), player.name, side);
    } else if(type==="azul"){
      addLog(ctx, clock, "azul", `Reincidência de amarelo por contestação: CARTÃO AZUL para ${player.name} (${teamName(ctx,side)}) — 2 minutos no banco, equipa fica reduzida em pista. ${opponentName} entra em powerplay!`, player.name, side);
    } else {
      addLog(ctx, clock, "vermelho", `CARTÃO VERMELHO para ${player.name} (${teamName(ctx,side)}) — 3º cartão azul nesta partida, expulsão automática, 4 minutos de inferioridade (${opponentName} em powerplay) — a expulsão por acumulação de azuis só vale para este jogo!`, player.name, side);
    }
    applyCardConsequences(ctx, side, player, type);
  }

  function blendedLiveStrength(ctx, side){
    const current = onRinkStrength(ctx, side);
    const initial = side==="home" ? ctx.homeStr : ctx.awayStr;
    return {
      attack: current.attack*0.72 + initial.attack*0.28,
      defense: current.defense*0.72 + initial.defense*0.28,
    };
  }
  function reboundProbabilities(shooter, goalkeeper, isMidRange, isPowerplay){
    if(!shooter || !goalkeeper) return {looseBallChance:0,conversionChance:0};
    const shooterFitness=fitnessFactor(shooter)*condicaoFactor(shooter);
    const goalkeeperFitness=fitnessFactor(goalkeeper)*condicaoFactor(goalkeeper);
    const positioning=shooter.attrs.posicionamento!=null?shooter.attrs.posicionamento:10;
    const finishing=shooter.attrs.finalizacao!=null?shooter.attrs.finalizacao:10;
    const determination=shooter.attrs.determinacao!=null?shooter.attrs.determinacao:10;
    const reflexes=goalkeeper.attrs.reflexos!=null?goalkeeper.attrs.reflexos:10;
    const concentration=goalkeeper.attrs.concentracao!=null?goalkeeper.attrs.concentracao:10;
    const agility=goalkeeper.attrs.agilidade!=null?goalkeeper.attrs.agilidade:10;
    const goalkeeperControl=concentration*0.45+reflexes*0.30+agility*0.25;
    const looseBallChance=clamp((isMidRange?0.085:0.060)-(goalkeeperControl-14)*0.0045+(1-goalkeeperFitness)*0.06+(isPowerplay?0.012:0),0.015,0.135);
    const attackerSkill=positioning*0.50+finishing*0.35+determination*0.15;
    const goalkeeperRecovery=reflexes*0.45+agility*0.35+concentration*0.20;
    const conversionChance=clamp(0.22+(attackerSkill-goalkeeperRecovery)*0.012+(shooterFitness-0.75)*0.10+(isMidRange?-0.025:0)+(isPowerplay?0.025:0),0.08,0.40);
    return {looseBallChance,conversionChance};
  }
  function resolveShot(ctx, attackerSide, defenderSide, infModAtt, infModDef, isSetPiece){
    recordMatchMetric(ctx,attackerSide,"remate",2);
    const strAtt = ctx.live ? blendedLiveStrength(ctx, attackerSide) : (attackerSide==="home"?ctx.homeStr:ctx.awayStr);
    const strDef = ctx.live ? blendedLiveStrength(ctx, defenderSide) : (defenderSide==="home"?ctx.homeStr:ctx.awayStr);
    const attLineup = ctx.lineups[attackerSide], defLineup = ctx.lineups[defenderSide];
    const isPowerplay = ctx.inferioridade[defenderSide] > 0;
    const isMidRange = !isSetPiece && Math.random() < 0.25;
    let scorer, tacticalBonus;
    if(isMidRange){
      // remate de meia-distância: decidido sobretudo pela capacidade de remate a meia-distância
      // do jogador, contra a capacidade equivalente do guarda-redes
      scorer = weightedPick(attLineup.outfield, p=>p.attrs.meiaDistancia*0.6+p.attrs.habilidade*0.4);
      const gkMeiaDistancia = defLineup.gr ? defLineup.gr.attrs.meiaDistancia : 14;
      tacticalBonus = scorer ? (scorer.attrs.meiaDistancia-14)*0.6 - (gkMeiaDistancia-14)*0.6 : 0;
    } else {
      scorer = weightedPick(attLineup.outfield, p=>p.attrs.habilidade*0.35+p.attrs.finalizacao*0.35+p.attrs.drible*0.2+p.attrs.criatividade*0.1);
      // posicionamento (leitura tática) e finalização (frieza a concluir) convertem mais oportunidades em golo
      tacticalBonus = scorer ? (scorer.attrs.posicionamento-14)*0.35 + (scorer.attrs.finalizacao-14)*0.35 : 0;
    }
    const adjustedAttack = strAtt.attack*infModAtt;
    const adjustedDefense = strDef.defense*infModDef;
    const contextMod = clamp((adjustedAttack-adjustedDefense)/850, -0.025, 0.045);
    const attackTeamObj = state.teams[attackerSide==="home"?ctx.homeId:ctx.awayId];
    const defenseTeamObj = state.teams[defenderSide==="home"?ctx.homeId:ctx.awayId];
    const liveTacticConv = liveConversionTacticMult(attackTeamObj, defenseTeamObj);
    const individualBonus = clamp((tacticalBonus*(scorer?fitnessFactor(scorer):1))/600, -0.018, 0.025);
    const powerplayBonus = isPowerplay ? 0.035 : 0;
    // Correção (mesmo relatório de bug do bónus tático acima, "demasiados golos no início do
    // jogo"): o teto absoluto por remate (0.32 em powerplay / 0.26 em jogo normal) só entrava em
    // jogo em cenários extremos, mas quando entrava não deixava margem nenhuma — todos os bónus já
    // reduzidos acima (tático, contexto, individual, powerplay) ainda podiam somar-se até perto
    // deste teto em simultâneo. Baixado para 0.27/0.22 para conter a cauda sem tocar na conversão
    // média normal (~7-11%, muito abaixo de qualquer um destes tetos).
    const goalProb = clamp(ctx.targetConversion[attackerSide]*liveTacticConv*PACE_CONV_COMP*anaMultRemate(ctx, attackerSide, defenderSide) + contextMod + individualBonus + powerplayBonus, 0.015, isPowerplay?0.27:0.22);
    // enfrentar um remate desgasta um pouco o guarda-redes, independentemente do resultado —
    // reflete a intensidade ofensiva do adversário no desgaste acumulado do GR.
    if(defLineup.gr) defLineup.gr.__fitness = clamp((defLineup.gr.__fitness!=null?defLineup.gr.__fitness:100) - 0.15, 0, 100);
    // Correção: nem todo o remate ia enquadrado à baliza (o número de "remates" e "remates
    // enquadrados" nas estatísticas era sempre igual, o que não fazia sentido — muitos remates,
    // sobretudo de meia-distância, saem ao lado ou por cima, sem sequer testar o guarda-redes).
    // Só entram aqui remates em jogo corrido (bolas paradas continuam tratadas à parte, em
    // resolveSetPiece, tipicamente mais certeiras). Uma fração dos remates de meia-distância
    // desenquadrados é assinalada como "bola alta" — falta técnica por a bola subir demasiado
    // dentro da área, tal como acontece no regulamento real.
    if(!isSetPiece){
      const missBase = isMidRange ? 0.34 : 0.15;
      const shooterAcc = scorer ? clamp((scorer.attrs[isMidRange?"meiaDistancia":"finalizacao"]||14)-14, -8, 8) : 0;
      const missChance = clamp(missBase - shooterAcc*0.012, 0.06, 0.55);
      if(Math.random() < missChance){
        const isHighBall = isMidRange && Math.random()<0.3;
        if(isHighBall){
          addLog(ctx, ctx.clock, "normal", `Remate de meia-distância de ${teamName(ctx,attackerSide)} sobe perigosamente dentro da área — bola alta, falta técnica assinalada pelo árbitro.`);
          turnPossession(ctx, defenderSide);
          return;
        }
        // Remate ao poste/à barra: quase-golo mais dramático do que um simples desenquadrado.
        const isPostMiss = Math.random()<0.22;
        const missTxt = isPostMiss ? pickPhrase(POST_MISS_PHRASES)() : pickPhrase(MISS_PHRASES)();
        addLog(ctx, ctx.clock, "normal", `Remate${isMidRange?' de meia-distância':''} de ${teamName(ctx,attackerSide)}${isPowerplay?' em powerplay':''} — ${missTxt}`);
        // Sem falta assinalada e a bola sai de forma pouco clara (sobretudo ao poste/à barra) —
        // por vezes não é claro quem ficava com a posse, daí o golpe-duplo (Art.13.1.a).
        if(Math.random() < (isPostMiss ? GOLPE_DUPLO_POST_MISS_CHANCE : GOLPE_DUPLO_MISS_CHANCE)){
          resolveGolpeDuplo(ctx, attackerSide, defenderSide, ctx.clock, "sem posse clara após o remate");
        } else {
          turnPossession(ctx, defenderSide);
        }
        return;
      }
    }
    // Baliza vazia: a equipa defensora tirou o guarda-redes (jogada de desespero a perder por
    // pouco) — um remate que passou pelo crivo do desenquadramento acima já testou a pontaria;
    // contra baliza vazia é golo praticamente garantido, sem guarda-redes nenhum para o evitar.
    const bailzaVazia = ctx.semGuardaRedes && ctx.semGuardaRedes[defenderSide];
    const goalRoll = bailzaVazia ? 0.93 : goalProb;
    if(Math.random() < goalRoll){
      let assistPlayer = null;
      if(scorer){ scorer.__matchGoals=(scorer.__matchGoals||0)+1; bumpRating(scorer, 1.4); }
      if(Math.random()<0.55 && attLineup.outfield.length>1){
        const candidates = attLineup.outfield.filter(p=>p!==scorer);
        assistPlayer = weightedPick(candidates, p=>p.attrs.criatividade);
        if(assistPlayer){ assistPlayer.__matchAssists=(assistPlayer.__matchAssists||0)+1; bumpRating(assistPlayer, 0.6); }
      }
      // Golo anulado: raro, mas o regulamento real prevê estas situações — falta anterior, golo
      // marcado com o patim (ou outra parte do corpo que não o stick), ou a bola não ter
      // ultrapassado completamente a linha de golo. Verificado antes de aplicar qualquer efeito
      // do golo (placard, estatísticas, moral), para não ter de desfazer nada.
      const anulaErro = arbitroErroGolo(ctx, attackerSide);
      if(anulaErro || Math.random() < 0.035*(ctx.arbAnula||1)){
        if(scorer){ scorer.__matchGoals=Math.max(0,scorer.__matchGoals-1); bumpRating(scorer,-1.4); }
        if(assistPlayer){ assistPlayer.__matchAssists=Math.max(0,assistPlayer.__matchAssists-1); bumpRating(assistPlayer,-0.6); }
        const scorerName = scorer ? scorer.name : "jogador";
        ctx.disallowedGoals[attackerSide] = (ctx.disallowedGoals[attackerSide]||0)+1;
        addLog(ctx, ctx.clock, "normal", anulaErro ? `O árbitro anula o golo de ${scorerName} por uma alegada falta anterior — decisão muito contestada, os jogadores reclamam!` : pickPhrase(DISALLOWED_GOAL_PHRASES)(scorerName));
        // Golo anulado por questão técnica (não por falta de ninguém) — reinício por golpe-duplo,
        // tal como acontece nos jogos reais (Art.13.1.a).
        resolveGolpeDuplo(ctx, attackerSide, defenderSide, ctx.clock, "golo anulado");
        maybeIssueDissentCard(ctx, attackerSide, ctx.clock, 0.12);
        return;
      }
      bumpRating(defLineup.gr, -0.35);
      if(defLineup.gr){ seasonStatsFor(ctx,defLineup.gr).golosSofridos = (seasonStatsFor(ctx,defLineup.gr).golosSofridos||0)+1; defLineup.gr.__matchGolosSofridos = (defLineup.gr.__matchGolosSofridos||0)+1; }
      ctx.score[attackerSide]+=1;
      ctx.goalsFromShots[attackerSide] = (ctx.goalsFromShots[attackerSide]||0)+1;
      const scorerName = scorer ? scorer.name : "jogador";
      const assistTxt = assistPlayer ? ` (assistência de ${assistPlayer.name})` : "";
      const powerplayTxt = isPowerplay ? " <b>[POWERPLAY]</b>" : "";
      const rangeTxt = isMidRange ? " de meia-distância" : "";
      // Golo de picadinha: variante de comentário para finalizações mais técnicas/subtis —
      // mais provável com jogadores de habilidade/drible elevados, não muda a conversão.
      const isChip = !isMidRange && scorer && ((scorer.attrs.habilidade||14)+(scorer.attrs.drible||14))/2>=16 && Math.random()<0.18;
      const phraseFn = isChip ? pickPhrase(CHIP_GOAL_PHRASES) : pickPhrase(GOAL_PHRASES);
      const rangeTxtFinal = isChip ? "" : rangeTxt;
      // Bis/hat-trick: marca quando o mesmo jogador chega ao 2º/3º golo da partida.
      const golosDoJogador = scorer ? (scorer.__matchGoals||0) : 0;
      const marcoTxt = golosDoJogador===2 ? " <b>(BIS!)</b>" : golosDoJogador>=3 ? " <b>(HAT-TRICK!)</b>" : "";
      // Golo nos instantes finais de uma parte: dramatismo extra perto do fim do período.
      const isLateGoal = ctx.periodLength!=null && (ctx.periodLength - ctx.clock) <= 90 && (ctx.periodLength - ctx.clock) >= 0;
      const lateTxt = isLateGoal ? " <b>nos instantes finais da parte!</b>" : "";
      addLog(ctx, ctx.clock, "golo", `${phraseFn(scorerName)}${rangeTxtFinal}, e ${teamName(ctx,attackerSide)} marca${assistTxt}${powerplayTxt}${marcoTxt}${lateTxt}! (${ctx.score.home}-${ctx.score.away})`, scorerName, attackerSide);
      turnPossession(ctx, defenderSide);
    } else {
      // A defesa inicial conta mesmo quando a bola fica disponível para uma recarga.
      ctx.savesBySide[attackerSide]=(ctx.savesBySide[attackerSide]||0)+1;
      recordMatchMetric(ctx,defenderSide,"defesa",1.5);
      bumpRating(defLineup.gr,0.04);
      const reboundCandidates=attLineup.outfield.filter(p=>p && (p.__fitness!=null?p.__fitness:100)>15);
      const reboundScorer=weightedPick(reboundCandidates,p=>{
        const positioning=p.attrs.posicionamento!=null?p.attrs.posicionamento:10;
        const finishing=p.attrs.finalizacao!=null?p.attrs.finalizacao:10;
        const acceleration=p.attrs.aceleracao!=null?p.attrs.aceleracao:10;
        const determination=p.attrs.determinacao!=null?p.attrs.determinacao:10;
        return (positioning*0.45+finishing*0.25+acceleration*0.20+determination*0.10)*fitnessFactor(p)*condicaoFactor(p);
      });
      const rebound=reboundProbabilities(reboundScorer,defLineup.gr,isMidRange,isPowerplay);
      if(reboundScorer && Math.random()<rebound.looseBallChance){
        ctx.reboundStats[attackerSide].looseBalls++;
        ctx.reboundStats[attackerSide].attempts++;
        if(defLineup.gr) defLineup.gr.__fitness=clamp((defLineup.gr.__fitness!=null?defLineup.gr.__fitness:100)-0.10,0,100);
        if(Math.random()<rebound.conversionChance){
          reboundScorer.__matchGoals=(reboundScorer.__matchGoals||0)+1;
          bumpRating(reboundScorer,1.2); bumpRating(defLineup.gr,-0.22);
          if(defLineup.gr){
            seasonStatsFor(ctx,defLineup.gr).golosSofridos=(seasonStatsFor(ctx,defLineup.gr).golosSofridos||0)+1;
            defLineup.gr.__matchGolosSofridos=(defLineup.gr.__matchGolosSofridos||0)+1;
          }
          ctx.score[attackerSide]++;
          ctx.goalsFromShots[attackerSide]=(ctx.goalsFromShots[attackerSide]||0)+1;
          ctx.reboundStats[attackerSide].goals++;
          addLog(ctx,ctx.clock,"golo",`${pickPhrase(REBOUND_GOAL_PHRASES)(reboundScorer.name, teamName(ctx,attackerSide))}! (${ctx.score.home}-${ctx.score.away})`, reboundScorer.name, attackerSide);
          turnPossession(ctx,defenderSide); return;
        }
        bumpRating(reboundScorer,-0.05); bumpRating(defLineup.gr,0.02);
        addLog(ctx,ctx.clock,"normal",`${defLineup.gr?defLineup.gr.name:"O guarda-redes"} deixa a bola disponível, mas ${reboundScorer.name} não consegue finalizar a recarga.`);
        // Bola solta disputada, sem falta de ninguém — muitas vezes ninguém fica com posse clara.
        if(Math.random() < GOLPE_DUPLO_REBOUND_FAIL_CHANCE){
          resolveGolpeDuplo(ctx, attackerSide, defenderSide, ctx.clock, "recarga disputada");
        } else {
          turnPossession(ctx,defenderSide);
        }
        return;
      }
      const gkName=defLineup.gr?defLineup.gr.name:"guarda-redes";
      addLog(ctx,ctx.clock,"normal",`Remate${isMidRange?' de meia-distância':''} de ${teamName(ctx,attackerSide)}${isPowerplay?' em powerplay':''} — ${pickPhrase(SAVE_PHRASES)(gkName)}`);
      turnPossession(ctx, defenderSide);
    }
  }
  // 1v1 set-piece (penálti ou livre direto): probabilidade dominada pela qualidade do
  // marcador vs guarda-redes, sempre mais alta do que um remate normal em jogo corrido.
  function resolveSetPiece(ctx, attackerSide, defenderSide, clock, kind){
    if(ctx.setPieces&&ctx.setPieces[attackerSide])ctx.setPieces[attackerSide][kind]=(ctx.setPieces[attackerSide][kind]||0)+1; recordMatchMetric(ctx,attackerSide,"bola-parada",3);
    const attLineup = ctx.lineups[attackerSide], defLineup = ctx.lineups[defenderSide];
    // Marcadores designados (08g-marcadores.js): o designado em pista cobra sempre; sem designado
    // (ou fora de pista) o motor escolhe como sempre.
    const spTeam = state.teams[attackerSide==="home"?ctx.homeId:ctx.awayId];
    const designado = marcadorDesignadoEmPista(spTeam, kind, attLineup);
    const shooter = designado || weightedPick(attLineup.outfield, p=>{const b=fitnessFactor(p)*condicaoFactor(p);return p.attrs.bolasParadas*fatigueTierFactor(b,'bolasParadas')*0.7+p.attrs.habilidade*fatigueTierFactor(b,'habilidade')*0.3;}) || attLineup.outfield[0];
    const gk = defLineup.gr;
    // Bolas Paradas é a estatística do marcador para penáltis/livres diretos; 1-para-1 é a do guarda-redes.
    // Determinação (aguentar o momento decisivo) entra como fator secundário dos dois lados.
    const shooterBase = shooter ? fitnessFactor(shooter)*condicaoFactor(shooter) : 1;
    const shooterSkill = shooter ? (shooter.attrs.bolasParadas*fatigueTierFactor(shooterBase,'bolasParadas')*0.75 + shooter.attrs.determinacao*fatigueTierFactor(shooterBase,'determinacao')*0.25) : 13;
    const gkBase = gk ? fitnessFactor(gk)*condicaoFactor(gk) : 1;
    const gkSkill = gk ? (gk.attrs.umParaUm*fatigueTierFactor(gkBase,'umParaUm')*0.75 + gk.attrs.determinacao*fatigueTierFactor(gkBase,'determinacao')*0.25) : 13;
    let skillDifference = shooterSkill + marcadorAjusteSkill(shooter, kind, !!designado) - gkSkill;
    // "Gelar" a bola parada: um desconto de tempo pedido pelo adversário pouco antes deixa uma
    // janela curta em que o próximo batedor perde ligeiramente a frieza (Art.9 — o jogo para por
    // completo, dando tempo ao guarda-redes/defesa para "gelar" quem vai bater). Consome-se numa
    // única tentativa.
    let icedApplied = false;
    if(ctx.icedUntil && ctx.icedUntil[attackerSide] && clock <= ctx.icedUntil[attackerSide]){
      skillDifference -= TIMEOUT_ICING_SKILL_PENALTY;
      ctx.icedUntil[attackerSide] = 0;
      icedApplied = true;
    }
    const prob = (kind==="penalti"
      ? clamp(0.36 + skillDifference/58, 0.20, 0.72)
      : clamp(0.25 + skillDifference/62, 0.13, 0.60)) * anaMultBolaParada(ctx, attackerSide, defenderSide); // contramedida de bolas paradas (08r)
    const label = kind==="penalti" ? "penálti" : "livre direto";
    const scoredKey = kind==="penalti" ? "penaltisMarcados" : "livresDiretosMarcados";
    const missedKey = kind==="penalti" ? "penaltisFalhados" : "livresDiretosFalhados";
    const tentadosKey = kind==="penalti" ? "penaltisTentados" : "livresDiretosTentados";
    const savedKey = kind==="penalti" ? "penaltisDefendidos" : "livresDiretosDefendidos";
    const sofridosKey = kind==="penalti" ? "penaltisSofridos" : "livresDiretosSofridos";
    if(shooter) seasonStatsFor(ctx,shooter)[tentadosKey] = (seasonStatsFor(ctx,shooter)[tentadosKey]||0)+1;
    if(gk){ seasonStatsFor(ctx,gk)[sofridosKey] = (seasonStatsFor(ctx,gk)[sofridosKey]||0)+1; gk.__fitness = clamp((gk.__fitness!=null?gk.__fitness:100) - 0.3, 0, 100); }
    const marcouBP = Math.random() < prob;
    marcadorRegistar(shooter, tipoMarcadorDoKind(kind), marcouBP);
    if(marcouBP){
      ctx.score[attackerSide] += 1;
      if(shooter){
        shooter.__matchGoals = (shooter.__matchGoals||0)+1;
        seasonStatsFor(ctx,shooter)[scoredKey] = (seasonStatsFor(ctx,shooter)[scoredKey]||0)+1;
        bumpRating(shooter, 1.4);
      }
      bumpRating(gk, -0.5);
      if(gk){ seasonStatsFor(ctx,gk).golosSofridos = (seasonStatsFor(ctx,gk).golosSofridos||0)+1; gk.__matchGolosSofridos = (gk.__matchGolosSofridos||0)+1; }
      addLog(ctx, clock, "golo", `⚽ GOLO de ${label}! ${shooter?shooter.name:"jogador"} marca para ${teamName(ctx,attackerSide)}!${icedApplied?" Mesmo gelado pelo desconto de tempo pedido pelo adversário.":""} (${ctx.score.home}-${ctx.score.away})`, shooter?shooter.name:null, attackerSide);
    } else {
      if(shooter) seasonStatsFor(ctx,shooter)[missedKey] = (seasonStatsFor(ctx,shooter)[missedKey]||0)+1;
      if(gk){ seasonStatsFor(ctx,gk)[savedKey] = (seasonStatsFor(ctx,gk)[savedKey]||0)+1; bumpRating(gk, 0.55); }
      addLog(ctx, clock, "normal", `${label.charAt(0).toUpperCase()+label.slice(1)} de ${teamName(ctx,attackerSide)} — defesa de ${gk?gk.name:"guarda-redes"}!${icedApplied?" O batedor saiu visivelmente gelado pelo desconto de tempo pedido pelo adversário momentos antes.":""}`);
    }
    turnPossession(ctx, defenderSide);
  }

  function liveAggroDisciplineMult(team){
    const pressao = team.pressao || "media";
    if(pressao==="alta") return 1.35;
    if(pressao==="baixa") return 0.60;
    return 1;
  }

  function resolveFoul(ctx, foulingSide, benefitSide, clock){
    recordMatchMetric(ctx,benefitSide,"pressao",0.7);
    const defTeam = state.teams[foulingSide==="home"?ctx.homeId:ctx.awayId];
    const defLineup = ctx.lineups[foulingSide];
    const attLineup = ctx.lineups[benefitSide];
    const aggroTactic = defTeam.pressao || "media";
    const aggroMult = aggroTactic==="alta" ? 1.6 : aggroTactic==="baixa" ? 0.5 : 1;
    // escolhe quem entra no lance de pressão, pesado pela Agressividade individual e pela
    // tática de agressividade escolhida.
    const defender = weightedPick(defLineup.outfield, p => 1 + (p.attrs.agressividade!=null?p.attrs.agressividade:10)*aggroMult);
    if(defender){
      const attacker = weightedPick(attLineup.outfield, p => 1 + (p.attrs.habilidade||10) + (p.attrs.drible||10));
      // limpeza do desarme: Desarme + Posicionamento + Força do defensor tempera o resultado,
      // contra a Habilidade + Drible de quem tem bola (resiste à pressão). Um desarme limpo
      // recupera a bola sem qualquer falta assinalada — o "prémio" de pressionar bem.
      const cleanliness = (defender.attrs.desarme!=null?defender.attrs.desarme:10)*0.5 + (defender.attrs.posicionamento||10)*0.25 + (defender.attrs.forca||10)*0.25;
      const resistance = attacker ? ((attacker.attrs.habilidade||10)*0.5 + (attacker.attrs.drible||10)*0.5) : 12;
      const tacticRisk = aggroTactic==="alta" ? 0.16 : aggroTactic==="baixa" ? -0.16 : 0;
      const foulProb = clamp(0.46 + (resistance-cleanliness)/38 + tacticRisk, 0.10, 0.85);
      if(Math.random() >= foulProb){
        addLog(ctx, clock, "normal", `${defender.name} (${teamName(ctx,foulingSide)}) tira a bola com um desarme limpo.`);
        bumpRating(defender, 0.25);
        turnPossession(ctx, foulingSide);
        return;
      }
      bumpRating(defender, -0.3);
      // ~6% das situações que pareciam falta são reveladas como simulação do atacante — o
      // árbitro não se deixa enganar, não concede a falta, e mostra amarelo a quem simulou.
      if(attacker && Math.random() < 0.06){
        bumpRating(defender, 0.3); bumpRating(attacker, -0.4);
        const type = escalateCardType(attacker, "amarelo");
        addLog(ctx, clock, type==="amarelo"?"amarelo":type, type==="amarelo" ? pickPhrase(SIMULATION_PHRASES)(attacker.name) : `CARTÃO ${type==="azul"?"AZUL":"VERMELHO"} para ${attacker.name} (${teamName(ctx,benefitSide)}) — reincidência de simulação, ${type==="azul"?"2 minutos no banco":"expulsão automática por acumulação (só vale para este jogo)"}!`, attacker.name, benefitSide);
        applyCardConsequences(ctx, benefitSide, attacker, type);
        turnPossession(ctx, foulingSide);
        return;
      }
    }
    // Penáltis continuam possíveis, mas a probabilidade depende da pressão e diminui
    // quando já houve outros no mesmo jogo, evitando séries artificiais por repetição de ticks.
    const penaltyBaseChance = aggroTactic==="alta" ? 0.050 : aggroTactic==="baixa" ? 0.018 : 0.030;
    const awarded = ctx.penaltiesAwarded[benefitSide]||0;
    const penaltyChance = penaltyBaseChance*Math.pow(0.60,awarded)*(ctx.arbPen ? ctx.arbPen[benefitSide] : 1);
    if(Math.random() < penaltyChance){
      ctx.penaltiesAwarded[benefitSide]++;
      addLog(ctx, clock, "sistema", `Falta grave dentro da área de ${teamName(ctx,foulingSide)} — PENÁLTI para ${teamName(ctx,benefitSide)}!`);
      arbitroTalvezPenaltiIndevido(ctx, foulingSide, clock);
      resolveSetPiece(ctx, benefitSide, foulingSide, clock, "penalti");
      return;
    }
    arbitroTalvezPenaltiNaoMarcado(ctx, benefitSide, foulingSide, clock);
    if(ctx.faltas[foulingSide] >= ctx.targetFaltas[foulingSide]*liveAggroDisciplineMult(defTeam)){
      // esta equipa já atingiu o número de faltas de equipa previsto para o jogo —
      // falta pontual, sem entrar na acumulação (mantém a média e o desvio-padrão consistentes)
      addLog(ctx, clock, "sistema", `Falta assinalada contra ${teamName(ctx,foulingSide)}. Livre indireto para ${teamName(ctx,benefitSide)}.`);
      turnPossession(ctx, benefitSide);
      return;
    }
    ctx.faltas[foulingSide]+=1;
    const n = ctx.faltas[foulingSide];
    const isDirect = n===10 || (n>10 && (n-10)%5===0);
    if(isDirect){
      addLog(ctx, clock, "sistema", `Falta de equipa nº${n} de ${teamName(ctx,foulingSide)} — acumulação atinge o limite: LIVRE DIRETO para ${teamName(ctx,benefitSide)}!`);
      resolveSetPiece(ctx, benefitSide, foulingSide, clock, "livredireto");
    } else {
      addLog(ctx, clock, "sistema", `Falta de equipa assinalada contra ${teamName(ctx,foulingSide)} (${n}ª). Livre indireto para ${teamName(ctx,benefitSide)}.`);
      turnPossession(ctx, benefitSide);
    }
  }

  function removePlayerFromRink(ctx, side, player){
    const lu = ctx.lineups[side];
    if(lu.gr === player){ lu.gr = null; return; }
    const idx = lu.outfield.indexOf(player);
    if(idx>=0) lu.outfield.splice(idx,1);
  }
  function insertPlayerToRink(ctx, side, player, pos){
    const lu = ctx.lineups[side];
    if(pos==="GR") lu.gr = player;
    else lu.outfield.push(player);
  }

  // Jogar sem guarda-redes: recurso de desespero nos últimos 90 segundos de uma parte, a perder
  // por 1 ou 2 golos — tira o guarda-redes por um jogador de linha extra, arriscando tudo em
  // ataque. Nunca no 1º período (não faz sentido tão cedo no jogo) nem já em inferioridade
  // numérica (seria um risco a mais em cima doutro).
  function podePuxarGuardaRedes(ctx, side){
    if(!ctx.lineups || !ctx.lineups[side]) return false;
    if(ctx.semGuardaRedes && ctx.semGuardaRedes[side]) return false;
    if(ctx.inferioridade[side]>0) return false;
    if(!ctx.lineups[side].gr) return false;
    if(ctx.period===1) return false;
    const bench = (ctx.bench[side]||[]).filter(jogadorDisponivelNestaPartida);
    if(!bench.some(p=>p.pos==="J")) return false;
    const remaining = (ctx.periodLength||0) - ctx.clock;
    if(remaining>90 || remaining<0) return false;
    const oppSide = side==="home"?"away":"home";
    const diff = ctx.score[side]-ctx.score[oppSide];
    return diff===-1 || diff===-2;
  }
  function pullGoalkeeper(ctx, side){
    const lu = ctx.lineups[side], gk = lu.gr, bench = ctx.bench[side]||[];
    const sub = bench.filter(p=>p.pos==="J" && jogadorDisponivelNestaPartida(p)).sort((a,b)=>overall(b)-overall(a))[0];
    if(!gk || !sub) return false;
    removePlayerFromRink(ctx, side, gk);
    const idx = bench.indexOf(sub); if(idx>=0) bench.splice(idx,1);
    bench.push(gk);
    insertPlayerToRink(ctx, side, sub, "J");
    if(!ctx.semGuardaRedes) ctx.semGuardaRedes = {home:false,away:false};
    if(!ctx.semGuardaRedesExtra) ctx.semGuardaRedesExtra = {home:null,away:null};
    if(!ctx.semGuardaRedesGK) ctx.semGuardaRedesGK = {home:null,away:null};
    ctx.semGuardaRedes[side] = true;
    anaRegistarGr(ctx, side);
    ctx.semGuardaRedesExtra[side] = sub;
    // Correção: se houvesse um guarda-redes suplente já no banco (comum, a maioria dos plantéis
    // tem 2), repor ia buscar "o primeiro GR que encontrasse" no banco — podia ser o suplente
    // errado, não o que realmente saiu. Guarda a referência exata para repor sempre o certo.
    ctx.semGuardaRedesGK[side] = gk;
    addLog(ctx, ctx.clock, "sistema", `🥅 ${teamName(ctx,side)} tira o guarda-redes (${gk.name}) e arrisca tudo, jogando com ${sub.name} como atacante extra!`);
    if(ctx.live && !ctx.simulating){ renderPistaBanco(ctx); syncGoalkeeperPullButton(ctx); }
    return true;
  }
  // Repõe o guarda-redes: assim que a IA deixa de estar na "zona de risco" (empatou/virou, ou
  // piorou ainda mais o resultado) — ou a pedido manual do próprio utilizador, a qualquer altura.
  function restoreGoalkeeper(ctx, side){
    if(!ctx.semGuardaRedes || !ctx.semGuardaRedes[side]) return false;
    const bench = ctx.bench[side]||[];
    const gkGuardado = ctx.semGuardaRedesGK ? ctx.semGuardaRedesGK[side] : null;
    const gk = (gkGuardado && bench.includes(gkGuardado)) ? gkGuardado : bench.find(p=>p.pos==="GR");
    if(!gk) return false;
    const lu = ctx.lineups[side];
    const extra = ctx.semGuardaRedesExtra ? ctx.semGuardaRedesExtra[side] : null;
    const alvo = (extra && lu.outfield.includes(extra)) ? extra : lu.outfield[lu.outfield.length-1];
    if(!alvo) return false;
    removePlayerFromRink(ctx, side, alvo);
    const idxGk = bench.indexOf(gk); if(idxGk>=0) bench.splice(idxGk,1);
    bench.push(alvo);
    insertPlayerToRink(ctx, side, gk, "GR");
    ctx.semGuardaRedes[side] = false;
    if(ctx.semGuardaRedesExtra) ctx.semGuardaRedesExtra[side] = null;
    if(ctx.semGuardaRedesGK) ctx.semGuardaRedesGK[side] = null;
    addLog(ctx, ctx.clock, "sistema", `🥅 ${teamName(ctx,side)} repõe o guarda-redes (${gk.name}).`);
    if(ctx.live && !ctx.simulating){ renderPistaBanco(ctx); syncGoalkeeperPullButton(ctx); }
    return true;
  }
  // Decisão automática da IA, verificada a cada tick (janela muito curta — 90 segundos — para
  // não arriscar perder o momento certo com um intervalo de verificação demasiado longo).
  function manageGoalkeeperPull(ctx, side){
    if(ctx.semGuardaRedes && ctx.semGuardaRedes[side]){
      const oppSide = side==="home"?"away":"home";
      const diff = ctx.score[side]-ctx.score[oppSide];
      if(diff!==-1 && diff!==-2) restoreGoalkeeper(ctx, side);
      return;
    }
    if(podePuxarGuardaRedes(ctx, side)) pullGoalkeeper(ctx, side);
  }

  function resolveCard(ctx, side, clock){
    recordMatchMetric(ctx,side==="home"?"away":"home","disciplina",1);
    const defTeamForCard = state.teams[side==="home"?ctx.homeId:ctx.awayId];
    if(ctx.cardsIssued[side] >= ctx.targetCards[side]*liveAggroDisciplineMult(defTeamForCard)){
      // esta equipa já atingiu o número de cartões previsto para o jogo — aviso verbal sem cartão
      addLog(ctx, clock, "sistema", `O árbitro chama a atenção de ${teamName(ctx,side)}, sem necessidade de cartão.`);
      return;
    }
    const lineup = ctx.lineups[side];
    const pool = lineup.outfield.length ? lineup.outfield : [lineup.gr].filter(Boolean);
    // jogadores mais agressivos (e com a tática de agressividade escolhida) arriscam mais
    // cartões; um bom Desarme + Posicionamento reduz esse risco (entradas mais limpas).
    const aggroTacticCard = defTeamForCard.pressao || "media";
    const aggroMultCard = aggroTacticCard==="alta" ? 1.5 : aggroTacticCard==="baixa" ? 0.6 : 1;
    const player = weightedPick(pool, p => {
      const aggroScore = 2 + (p.attrs.agressividade!=null ? p.attrs.agressividade : 10)*aggroMultCard;
      const cleanliness = 1 + ((p.attrs.desarme||10)+(p.attrs.posicionamento||10))/28;
      return aggroScore * persCartaoMult(p) / cleanliness;
    });
    const roll = Math.random();
    let type;
    if(roll<0.84) type="amarelo"; else if(roll<0.98) type="azul"; else type="vermelho";
    const already = player ? (player.__cardsThisMatch||[]) : [];
    const opponentName = teamName(ctx, side==="home"?"away":"home");
    // 2º amarelo ao mesmo jogador no jogo = cartão azul
    const amareloReincidencia = type==="amarelo" && already.includes("amarelo");
    if(amareloReincidencia) type="azul";
    // 3º azul ao mesmo jogador no jogo = cartão vermelho (expulsão automática)
    const azuisAnteriores = already.filter(c=>c==="azul").length;
    const azulEscalouParaVermelho = type==="azul" && azuisAnteriores>=2;
    if(azulEscalouParaVermelho) type="vermelho";

    if(type==="amarelo"){
      addLog(ctx, clock, "amarelo", `Cartão amarelo mostrado a ${player?player.name:"jogador"} (${teamName(ctx,side)}) — ${pickPhrase(FOUL_CARD_REASON_PHRASES)()}.`, player?player.name:null, side);
    } else if(type==="azul"){
      addLog(ctx, clock, "azul", `${amareloReincidencia?"Reincidência de amarelo: ":""}CARTÃO AZUL para ${player?player.name:"jogador"} (${teamName(ctx,side)}) — 2 minutos no banco, equipa fica reduzida em pista (não é expulsão). ${opponentName} entra em powerplay!`, player?player.name:null, side);
    } else {
      const motivo = azulEscalouParaVermelho ? "3º cartão azul ao mesmo jogador nesta partida — expulsão automática" : "expulsão direta";
      addLog(ctx, clock, "vermelho", `CARTÃO VERMELHO para ${player?player.name:"jogador"} (${teamName(ctx,side)}) — ${motivo}, 4 minutos de inferioridade (${opponentName} em powerplay)${azulEscalouParaVermelho?" — a expulsão por acumulação de azuis só vale para este jogo!":" e suspensão no próximo jogo (sujeita a processo disciplinar)!"}`, player?player.name:null, side);
    }
    applyCardConsequences(ctx, side, player, type);
  }

  // Chama de urgência um suplente para repor o mínimo de 3 jogadores de campo em pista.
  // Para o utilizador, é uma escolha do treinador (pausa e pergunta); para a IA, é automático.
  function callUpImmediateReplacement(ctx, side, pos){
    const bench = ctx.bench[side] || [];
    const candidates = bench.filter(p=>p.pos===pos && jogadorDisponivelNestaPartida(p));
    const userControlled = ctx.live && side===ctx.userSide && !ctx.simulating;
    if(userControlled && candidates.length){
      ctx.paused = true;
      ctx.pendingReturnPrompt = { side, pos, candidates, selfOption: null, filling: true };
      return;
    }
    if(!candidates.length){
      // banco desta posição esgotado — em circunstância alguma a equipa pode ficar com menos
      // de 3 em pista, por isso entra um jogador de emergência temporário com a posição certa
      // (tal como o Henrique Dias das suspensões), em vez de pedir emprestado alguém doutra
      // posição (o que criaria confusões mais tarde sobre onde esse jogador está mesmo a jogar).
      const realTeam = state.teams[side==="home"?ctx.homeId:ctx.awayId];
      const emergencyPlayer = makeHenriqueDias(realTeam.id, pos);
      realTeam.players.push(emergencyPlayer);
      if(!ctx.emergencyPlayers) ctx.emergencyPlayers = [];
      ctx.emergencyPlayers.push(emergencyPlayer);
      emergencyPlayer.__fitness = 100;
      emergencyPlayer.__matchGoals = 0; emergencyPlayer.__matchAssists = 0; emergencyPlayer.__matchGolosSofridos = 0; emergencyPlayer.__matchRatingDelta = 0;
      insertPlayerToRink(ctx, side, emergencyPlayer, pos);
      ctx.playedSet[side].add(emergencyPlayer.id);
      addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} esgotou o banco — entra um jogador de emergência (${emergencyPlayer.name}) para nunca ficar abaixo de 3 em pista.`);
      return;
    }
    const chosen = candidates.slice().sort((a,b)=>{
      const fitA = a.__fitness!=null?a.__fitness:100, fitB = b.__fitness!=null?b.__fitness:100;
      return (overall(b)+fitB*0.15) - (overall(a)+fitA*0.15);
    })[0];
    const bIdx = bench.indexOf(chosen);
    if(bIdx>=0) bench.splice(bIdx,1);
    insertPlayerToRink(ctx, side, chosen, pos);
    ctx.playedSet[side].add(chosen.id);
    chosen.__matchGoals = chosen.__matchGoals||0; chosen.__matchAssists = chosen.__matchAssists||0; chosen.__matchGolosSofridos = chosen.__matchGolosSofridos||0;
    addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} chama um suplente de urgência (mínimo de 3 em pista): entra ${chosen.name}.`);
  }

  // Quando o período de inferioridade termina, a equipa tem de escolher quem entra em pista —
  // nunca automaticamente, e o jogador do cartão azul (não o vermelho) continua elegível.
  // Faz decorrer o relógio único de cada equipa. Quando chega a zero: se ainda houver alguém
  // em fila, o seguinte começa a cumprir o seu próprio tempo (equipa continua com 3 em pista,
  // sem necessidade de novo suplente pois o lugar já foi reposto quando o cartão aconteceu);
  // se a fila esvaziar, a equipa recompõe-se para 4 (escolha do treinador, nunca automática).
  function processPendingReturns(ctx){
    if(ctx.paused) return;
    ["home","away"].forEach(side=>{
      if(ctx.paused) return;
      if(ctx.penaltyClock[side] <= 0) return;
      ctx.penaltyClock[side] -= TICK_GAME_SECONDS;
      if(ctx.penaltyClock[side] > 0) return;
      ctx.penaltyClock[side] = 0;
      const queue = ctx.penaltyQueue[side];
      const finished = queue.shift();
      if(!ctx.penaltyServed) ctx.penaltyServed = { home: [], away: [] };
      if(queue.length){
        // o próximo da fila começa agora a cumprir o seu tempo — a equipa mantém-se a 3,
        // o lugar em pista já foi reposto no momento do respetivo cartão.
        ctx.penaltyServed[side].push(finished);   // 2026-10-16: a recomposição só acontece quando a fila esvazia
        ctx.penaltyClock[side] = queue[0].duration;
        addLog(ctx, ctx.clock, "sistema", `${finished.player.name} cumpriu o seu tempo, mas ${teamName(ctx,side)} continua reduzida — outro jogador ainda tem tempo a cumprir.`);
        return;
      }
      // fila vazia: repõe-se o quarto jogador em pista.
      // 2026-10-16: antes só se olhava para o ÚLTIMO da fila (finished.pos) — um cartão a um GR e outro a um
      // jogador de campo perdiam um lugar para o resto do jogo. Agora olha-se para todos os que cumpriram:
      // quem já tinha sido substituído no momento do cartão (refilled) e não foi expulso volta ao banco; o
      // lugar por repor é o da primeira penalização que o deixou vazio.
      const servidos = (ctx.penaltyServed[side] || []).concat([finished]);
      ctx.penaltyServed[side] = [];
      const bench = ctx.bench[side] || [];
      servidos.forEach(e=>{ if(e.refilled && !e.wasRed && e.player && !bench.includes(e.player)) bench.push(e.player); });
      const porRepor = servidos.filter(e=>!e.refilled);
      if(!porRepor.length){
        addLog(ctx, ctx.clock, "sistema", `Fim da inferioridade de ${teamName(ctx,side)}.`);
        return;
      }
      const slotEntry = porRepor[0];
      porRepor.slice(1).forEach(e=>{ if(!e.wasRed && e.player && !bench.includes(e.player)) bench.push(e.player); });   // caso raro: não perder o jogador
      const pos = slotEntry.pos;
      const candidates = bench.filter(p=>p.pos===pos && jogadorDisponivelNestaPartida(p));
      const selfOption = slotEntry.wasRed ? null : slotEntry.player;
      const userControlled = ctx.live && side===ctx.userSide && !ctx.simulating;
      if(userControlled){
        ctx.paused = true;
        ctx.pendingReturnPrompt = { side, pos, candidates, selfOption };
        return;
      }
      const pool = selfOption ? candidates.concat([selfOption]) : candidates;
      if(!pool.length){
        addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} não tem opções disponíveis e continua reduzida.`);
        return;
      }
      const chosen = pool.slice().sort((a,b)=>{
        const fitA = a.__fitness!=null?a.__fitness:100, fitB = b.__fitness!=null?b.__fitness:100;
        return (overall(b)+fitB*0.15) - (overall(a)+fitA*0.15);
      })[0];
      const bIdx = bench.indexOf(chosen);
      if(bIdx>=0) bench.splice(bIdx,1);
      if(selfOption && chosen !== selfOption) bench.push(selfOption);
      insertPlayerToRink(ctx, side, chosen, pos);
      addLog(ctx, ctx.clock, "sistema", `Fim da inferioridade: ${teamName(ctx,side)} recompõe a equipa com ${chosen.name}.`);
    });
  }

  // Probabilidade de golo numa grande penalidade: qualidade do marcador (igual à fórmula
  // original) MENOS a qualidade do guarda-redes que defende — antes, o guarda-redes em pista
  // era irrelevante para o resultado do desempate (nunca entrava na conta), o que tornava sem
  // sentido o pedido do utilizador de poder "escolher o guarda-redes" para a grande penalidade.
  // Usa os mesmos atributos de defesa 1x1 já usados no resto do motor (reflexos/umParaUm/
  // concentração — ver onRinkStrength e reboundProbabilities, mais acima).
  // Correção (item 10, pedido do utilizador): "numa definição de vencedor por grandes
  // penalidades, no hoquei a maior parte sao defendidas, não é como o futebol" — a fórmula
  // original centrava-se em 0.55 (maioria MARCADA, ao estilo futebol). Baixa-se o centro para
  // ~0.38 e aperta-se o intervalo de saturação, mantendo a sensibilidade relativa à qualidade do
  // marcador/guarda-redes, para que a maioria dos remates passe a ser DEFENDIDA (realidade do
  // hóquei em patins), com uma cauda superior ainda alcançável (~60%) para marcadores de elite
  // contra guarda-redes fracos.
  function shootoutGoProb(shooter, gk){
    // Pedido do utilizador (2026-10-05): "no hóquei é mais comum o GR defender" — centro baixado
    // de 0.38 para 0.33 (média simulada ~33% de golos, ~2 em cada 3 grandes penalidades
    // defendidas ou falhadas), com o mesmo peso da qualidade do marcador e do guarda-redes.
    if(!shooter) return 0.33;
    const base = clamp(0.33+(overall(shooter)-14)/45 + ((shooter.attrs.bolasParadas||12)-12)/50 + ((shooter.attrs.determinacao||12)-12)/80, 0.14, 0.58);
    if(!gk) return base;
    const gkSkill = (gk.attrs.umParaUm||12)*0.55 + (gk.attrs.reflexos||12)*0.30 + (gk.attrs.concentracao||12)*0.15;
    return clamp(base - (gkSkill-12)*0.022, 0.12, 0.58);
  }
  // Grupo de marcadores por omissão de uma equipa (jogadores de campo em pista; se não houver
  // nenhum, cai para o guarda-redes, caso-limite de uma equipa muito desfalcada) — usado tanto
  // pela IA (aqui) como valor de partida da escolha interativa do utilizador (abaixo).
  function defaultShootoutShooters(ctx, side){
    const lu = ctx.lineups[side];
    return lu.outfield.length ? lu.outfield : [lu.gr].filter(Boolean);
  }
  // ---- Máquina de estados das grandes penalidades (Art.32 do Regulamento Técnico) ----
  // Partilhada pela simulação instantânea (runShootout, IA/jogos em bloco) e pela versão que o
  // utilizador vê ao vivo (advanceInteractiveShootoutTick), para as duas seguirem as mesmas regras:
  //  - sorteio de quem executa primeiro (32.7), execuções alternadas (32.13);
  //  - 5 penáltis por equipa, com jogadores diferentes e rotação se houver menos de 5 (32.13/14);
  //  - fim antecipado logo que uma equipa já não pode ser alcançada (32.15), avaliado a CADA execução;
  //  - empate -> série adicional, um penálti de cada, até uma marcar e a outra não (32.16/17);
  //  - cada equipa usa um único guarda-redes em todos os penáltis (32.13/17).
  const SHOOTOUT_REGULAR_KICKS = 5, SHOOTOUT_MAX_SUDDEN_ROUNDS = 12;
  const SHOOTOUT_PREP_HOLD_MS = 1600, SHOOTOUT_GOAL_HOLD_MS = 3000, SHOOTOUT_MISS_HOLD_MS = 2600;
  function newShootoutState(orders, gks){
    const first = Math.random()<0.5 ? "home" : "away";
    return { active:true, phase:"regular", first, turn:first, stage:0, order:orders, gk:gks,
      taken:{home:0,away:0}, goals:{home:0,away:0}, kicks:{home:[],away:[]}, current:null, last:null, suddenRounds:0 };
  }
  function shootoutOther(side){ return side==="home"?"away":"home"; }
  function shootoutPickShooter(so, side){
    const list = so.order[side] || [];
    return list.length ? list[so.taken[side] % list.length] : null;
  }
  // Resultado de uma execução: marcou, ou então não — e nesse caso, na maioria das vezes o guarda-redes defende.
  function shootoutKickOutcome(shooter, gk){
    if(Math.random() < shootoutGoProb(shooter, gk)) return "G";
    const r = Math.random();
    return r < 0.80 ? "D" : r < 0.92 ? "P" : "F"; // defesa / poste / ao lado
  }
  // Devolve o vencedor ("home"/"away"), "tie" (limite de rondas esgotado) ou null (continua).
  function shootoutDecision(so){
    if(so.phase==="regular"){
      for(const a of ["home","away"]){
        const b = shootoutOther(a);
        if(so.goals[a] > so.goals[b] + (SHOOTOUT_REGULAR_KICKS - so.taken[b])) return a;
      }
      if(so.taken.home>=SHOOTOUT_REGULAR_KICKS && so.taken.away>=SHOOTOUT_REGULAR_KICKS){
        if(so.goals.home!==so.goals.away) return so.goals.home>so.goals.away?"home":"away";
        so.phase = "suddenDeath";
      }
      return null;
    }
    if(so.taken.home===so.taken.away){ // série adicional: só se decide depois de ambos executarem
      so.suddenRounds++;
      if(so.goals.home!==so.goals.away) return so.goals.home>so.goals.away?"home":"away";
      if(so.suddenRounds>=SHOOTOUT_MAX_SUDDEN_ROUNDS) return "tie";
    }
    return null;
  }
  function shootoutAnnounceKick(ctx, so){
    const side = so.turn, opp = shootoutOther(side);
    const shooter = shootoutPickShooter(so, side), gk = so.gk[opp];
    so.current = { side, shooter, gk };
    so.last = null; so.stage = 1;
    addLog(ctx, "GP", "gp", `🥅 ${teamName(ctx,side)}: ${shooter?shooter.name:"jogador"} prepara-se para marcar — ${gk?gk.name:"baliza sem guarda-redes"} na baliza.`);
  }
  // Executa a marcação em curso (so.current), regista-a e passa a vez. Devolve o vencedor/"tie"/null.
  function shootoutResolveCurrentKick(ctx, so){
    const { side, shooter, gk } = so.current || { side:so.turn, shooter:shootoutPickShooter(so,so.turn), gk:so.gk[shootoutOther(so.turn)] };
    const outcome = shootoutKickOutcome(shooter, gk);
    const nome = shooter?shooter.name:"jogador", gkNome = gk?gk.name:"guarda-redes";
    so.taken[side]++;
    if(outcome==="G") so.goals[side]++;
    so.kicks[side].push({ r:outcome, name:nome });
    so.last = { side, shooter, gk, outcome };
    const score = `(${so.goals.home}-${so.goals.away})`;
    const text = outcome==="G" ? `⚽ GOLO! ${nome} (${teamName(ctx,side)}) bate ${gkNome}. ${score}`
      : outcome==="D" ? `🧤 DEFESA de ${gkNome}! ${nome} (${teamName(ctx,side)}) não marca. ${score}`
      : outcome==="P" ? `${nome} (${teamName(ctx,side)}) acerta no poste e falha! ${score}`
      : `${nome} (${teamName(ctx,side)}) atira ao lado. ${score}`;
    addLog(ctx, "GP", "gp", text);
    ctx.log[ctx.log.length-1].gpResult = outcome;
    so.current = null; so.stage = 0; so.turn = shootoutOther(side);
    return shootoutDecision(so);
  }
  function runShootout(ctx){
    ctx.period="SO";
    addLog(ctx, "GP", "sistema", "Continua o empate: DESEMPATE POR GRANDES PENALIDADES (Art.32).");
    const so = newShootoutState(
      { home:defaultShootoutShooters(ctx,"home"), away:defaultShootoutShooters(ctx,"away") },
      { home:ctx.lineups.home.gr, away:ctx.lineups.away.gr });
    addLog(ctx, "GP", "sistema", `Sorteio: ${teamName(ctx,so.first)} executa primeiro.`);
    let decision = null, guard = 0;
    while(decision===null && guard<200){ shootoutAnnounceKick(ctx, so); decision = shootoutResolveCurrentKick(ctx, so); guard++; }
    ctx.shootout = so; so.active = false; so.phase = "done";
    finishShootout(ctx, decision);
  }

  // ============================= Grandes penalidades jogáveis (utilizador ao vivo) =============================
  // Pedido do utilizador (2026-09-14): "quando chega a pênaltis [o jogo] acaba e aparece só o
  // resultado. Devemos poder escolher os marcadores e o guarda-redes e assistir." Só se aplica
  // quando o utilizador está mesmo a assistir ao vivo (ctx.live && !ctx.simulating) — em
  // qualquer outro caso (adversário de IA, jogo simulado em bloco) o comportamento continua
  // exatamente o mesmo runShootout síncrono de sempre, sem qualquer alteração.
  function shootoutEligiblePlayers(ctx, side){
    const lu = ctx.lineups[side];
    // Correção (Marco K, lesão grave em jogo): quem está em pista neste momento nunca está
    // indisponível por lesão grave (já teria sido substituído); só o banco precisa do filtro.
    const onRinkAndBench = [lu.gr].concat(lu.outfield, (ctx.bench[side]||[]).filter(jogadorDisponivelNestaPartida)).filter(Boolean);
    return {
      gks: onRinkAndBench.filter(p=>p.pos==="GR"),
      outfield: onRinkAndBench.filter(p=>p.pos!=="GR"),
    };
  }
  function beginInteractiveShootoutSetup(ctx){
    ctx.period="SO";
    addLog(ctx, "GP", "sistema", "Continua o empate: DESEMPATE POR GRANDES PENALIDADES (Art.32).");
    ctx.paused = true; ctx.pauseReason = "shootoutSetup";
    ctx.shootoutSetupPending = true;
  }
  const shootoutSetupModal = document.getElementById("shootoutSetupModal");
  function openShootoutSetupModal(ctx){
    const side = ctx.userSide;
    const pool = shootoutEligiblePlayers(ctx, side);
    if(!ctx.shootoutSetupSelection) ctx.shootoutSetupSelection = { gkId:null, order:[] };
    const sel = ctx.shootoutSetupSelection;
    if(!sel.gkId){
      const currentGK = ctx.lineups[side].gr;
      sel.gkId = (currentGK && pool.gks.some(p=>p.id===currentGK.id)) ? currentGK.id : (pool.gks[0] ? pool.gks[0].id : null);
    }
    renderShootoutSetupUI(ctx);
    document.getElementById("shootoutSetupErr").textContent = "";
    shootoutSetupModal.classList.remove("hidden");
  }
  function renderShootoutSetupUI(ctx){
    const side = ctx.userSide;
    const pool = shootoutEligiblePlayers(ctx, side);
    const sel = ctx.shootoutSetupSelection;
    const maxShooters = Math.min(5, pool.outfield.length);
    document.getElementById("shootoutOrderMax").textContent = maxShooters || 1;
    document.getElementById("shootoutGKOptions").innerHTML = pool.gks.length ? pool.gks.map(p=>`
      <div class="esc-row"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
        <input type="radio" name="shootoutGK" value="${p.id}" ${sel.gkId===p.id?'checked':''}>
        ${playerNameHtml(p)} <span class="ovr-mini">OVR ${overall(p)}</span>
      </label></div>`).join("") : '<div style="font-size:12px;color:var(--texto-mute);">Sem guarda-redes disponível — a defesa fica sem efeito.</div>';
    document.querySelectorAll('input[name="shootoutGK"]').forEach(r => r.addEventListener("change", (e)=>{ sel.gkId = e.target.value; }));
    document.getElementById("shootoutOrderChosen").innerHTML = sel.order.length ? sel.order.map((id,idx)=>{
      const p = pool.outfield.find(x=>x.id===id); if(!p) return "";
      return `<span class="shootout-order-chip"><b>${idx+1}.</b> ${escapeHtml(p.name)} <button data-id="${id}" title="Remover">✕</button></span>`;
    }).join("") : '<div style="font-size:12px;color:var(--texto-mute);margin-bottom:6px;">Ainda não escolheste nenhum marcador.</div>';
    document.getElementById("shootoutOrderChosen").querySelectorAll("button[data-id]").forEach(btn=>{
      btn.addEventListener("click", () => { sel.order = sel.order.filter(id=>id!==btn.getAttribute("data-id")); renderShootoutSetupUI(ctx); });
    });
    document.getElementById("shootoutOrderCount").textContent = sel.order.length;
    const remaining = pool.outfield.filter(p=>!sel.order.includes(p.id));
    const full = maxShooters>0 && sel.order.length>=maxShooters;
    document.getElementById("shootoutOrderPool").innerHTML = remaining.length ? remaining.map(p=>`
      <button class="injury-sub-btn ${full?'chosen':''}" data-id="${p.id}" ${full?'disabled':''}><b>${playerNameHtml(p)}</b> · OVR ${overall(p)} · <span class="pos-badge j">${linhaAbbrev(p)}</span></button>`).join("") : "";
    document.getElementById("shootoutOrderPool").querySelectorAll("button[data-id]").forEach(btn=>{
      btn.addEventListener("click", () => {
        if(sel.order.length>=maxShooters) return;
        sel.order.push(btn.getAttribute("data-id"));
        renderShootoutSetupUI(ctx);
      });
    });
  }
  document.getElementById("shootoutSetupConfirmBtn").addEventListener("click", () => {
    const ctx = state.match;
    if(!ctx || !ctx.shootoutSetupPending) return;
    const side = ctx.userSide;
    const pool = shootoutEligiblePlayers(ctx, side);
    const sel = ctx.shootoutSetupSelection;
    const maxShooters = Math.min(5, pool.outfield.length);
    const errEl = document.getElementById("shootoutSetupErr");
    if(pool.gks.length && !sel.gkId){ errEl.textContent = "Escolhe o guarda-redes que vai defender."; return; }
    if(maxShooters>0 && sel.order.length<maxShooters){ errEl.textContent = `Escolhe a ordem de ${maxShooters} marcador${maxShooters>1?'es':''}.`; return; }
    const userOrder = sel.order.map(id=>pool.outfield.find(p=>p.id===id)).filter(Boolean);
    const userGK = pool.gks.find(p=>p.id===sel.gkId) || ctx.lineups[side].gr;
    const oppSide = side==="home"?"away":"home";
    const oppOrder = defaultShootoutShooters(ctx, oppSide);
    const oppGK = ctx.lineups[oppSide].gr;
    ctx.shootout = newShootoutState(
      { [side]: userOrder.length?userOrder:defaultShootoutShooters(ctx,side), [oppSide]: oppOrder },
      { [side]: userGK, [oppSide]: oppGK });
    addLog(ctx, "GP", "sistema", `Sorteio: ${teamName(ctx,ctx.shootout.first)} executa primeiro.`);
    addLog(ctx, "GP", "sistema", `${teamName(ctx,side)} escala para as grandes penalidades: ${userOrder.map(p=>p.name).join(", ")||"—"}${userGK?` · Baliza: ${userGK.name}`:''}.`);
    ctx.shootoutSetupPending = false; ctx.shootoutSetupSelection = null;
    ctx.paused = false; ctx.pauseReason = null;
    shootoutSetupModal.classList.add("hidden");
    renderScoreboard();
  });
  function finishShootout(ctx, decision){
    const so = ctx.shootout;
    so.phase = "done"; so.active = false; so.current = null; so.stage = 0;
    ctx.soHome = so.goals.home; ctx.soAway = so.goals.away;
    if(decision==="home" || decision==="away"){
      ctx.soWinner = decision;
    } else {
      // Válvula de segurança (o regulamento não limita a série adicional): esgotadas as rondas,
      // decide-se por sorteio justo (50/50), deixado claro no relato.
      addLog(ctx,"GP","sistema", "As grandes penalidades continuam empatadas após o limite de rondas — desempate por sorteio.");
      ctx.soWinner = Math.random()<0.5 ? "home" : "away";
    }
    addLog(ctx,"GP","sistema", `Fim das grandes penalidades: ${teamName(ctx,"home")} ${so.goals.home}-${so.goals.away} ${teamName(ctx,"away")}.`);
    addLog(ctx,"FIM","sistema", `Resultado final (após grandes penalidades): ${teamName(ctx,"home")} ${ctx.score.home}-${ctx.score.away} ${teamName(ctx,"away")} — vence ${teamName(ctx, ctx.soWinner)}.`);
    ctx.finished = true;
  }
  // Ao vivo, cada execução demora duas "marcações" do relógio: primeiro anuncia-se quem vai
  // bater e quem está na baliza (pausa curta), depois resolve-se a execução e o resultado fica
  // bem visível (pausa mais longa, sobretudo num golo) — ver shootoutHoldUntil em
  // runLiveMatchTimerTick e o painel #shootoutPanel (renderShootoutPanel).
  function advanceInteractiveShootoutTick(ctx){
    const so = ctx.shootout;
    if(!so || so.phase==="done") return;
    if(so.pendingDecision){ finishShootout(ctx, so.pendingDecision); return; }
    if(so.stage===0){
      shootoutAnnounceKick(ctx, so);
      ctx.shootoutHoldUntil = Date.now() + SHOOTOUT_PREP_HOLD_MS;
      return;
    }
    const decision = shootoutResolveCurrentKick(ctx, so);
    ctx.shootoutHoldUntil = Date.now() + (so.last && so.last.outcome==="G" ? SHOOTOUT_GOAL_HOLD_MS : SHOOTOUT_MISS_HOLD_MS);
    // A decisão só é fechada no tick seguinte, depois de a última execução ficar bem visível —
    // senão o ecrã de fim de jogo tapava logo o resultado do último penálti.
    if(decision!==null){ so.pendingDecision = decision; ctx.shootoutHoldUntil += 1400; }
  }

  function halfTimeRecovery(ctx){
    // ao intervalo, todos os jogadores (em pista e no banco, das duas equipas) recuperam
    // cerca de 15% de condição física — o descanso e o tratamento do intervalo real.
    ["home","away"].forEach(side=>{
      const lu = ctx.lineups[side];
      [lu.gr].concat(lu.outfield).forEach(p=>{
        if(!p) return;
        const cur = p.__fitness!=null ? p.__fitness : 100;
        p.__fitness = clamp(cur + 15, 0, 100);
      });
      (ctx.bench[side]||[]).forEach(p=>{
        const cur = p.__fitness!=null ? p.__fitness : 100;
        p.__fitness = clamp(cur + 15, 0, 100);
      });
    });
  }

  // A pausa automática do separador Táticas (ou uma pausa manual) não impede pedir um desconto —
  // só uma pausa forçada por outro motivo já em curso (lesão, intervalo entre partes, ou já a meio
  // da escolha de mensagem de outro desconto) bloqueia mesmo a ação.
  function timeoutUiBlockedByOtherPause(ctx){
    return !!ctx.injury || ctx.pauseReason==="intervalo" || ctx.pauseReason==="desconto" || ctx.pauseReason==="desconto-adversario";
  }

  // Pode a equipa `side` pedir agora um desconto de tempo? Nunca no prolongamento nem nas
  // grandes penalidades (Art.9.3), só enquanto tiver descontos por gastar nesta parte.
  function canCallTimeout(ctx, side){
    if(!ctx || ctx.finished) return false;
    if(ctx.period!==1 && ctx.period!==2) return false;
    if(!ctx.timeoutsLeft || (ctx.timeoutsLeft[side]||0)<=0) return false;
    return true;
  }

  // Pede um desconto de tempo por `side`, com uma mensagem ao grupo (motivar/serenar/focar).
  // Efeitos (Art.9 + pedido do utilizador): o jogo para por completo, por isso as duas equipas
  // recuperam um pouco de fadiga; a mensagem escolhida dá um pequeno efeito tático/moral temporário
  // à própria equipa; e a próxima bola parada do adversário sai ligeiramente "gelada".
  function callTimeout(ctx, side, messageKey){
    if(!canCallTimeout(ctx, side)) return false;
    const msg = TIMEOUT_MESSAGES[messageKey] || TIMEOUT_MESSAGES.focar;
    ctx.timeoutsLeft[side]--;
    ctx.lastTimeoutTick[side] = ctx.absoluteClock!=null ? ctx.absoluteClock : ctx.clock;
    const oppSide = side==="home"?"away":"home";
    // Recuperação física ligeira dos jogadores EM PISTA das duas equipas — "é só um minuto".
    ["home","away"].forEach(s=>{
      const lu = ctx.lineups[s];
      [lu.gr].concat(lu.outfield).filter(Boolean).forEach(p=>{
        const cur = p.__fitness!=null ? p.__fitness : 100;
        p.__fitness = clamp(cur + TIMEOUT_FITNESS_RECOVERY, 0, 100);
      });
    });
    // Gela a próxima bola parada do adversário durante a janela seguinte.
    ctx.icedUntil = ctx.icedUntil || { home:0, away:0 };
    ctx.icedUntil[oppSide] = ctx.clock + TIMEOUT_ICING_WINDOW_SECONDS;
    // Efeito mental temporário na própria equipa (jogadores em pista), consoante a mensagem.
    ctx.timeoutMentalBuff = ctx.timeoutMentalBuff || { home:null, away:null };
    ctx.timeoutMentalBuff[side] = {
      attackMult: msg.attackMult, defenseMult: msg.defenseMult,
      expiresClock: ctx.clock + TIMEOUT_MENTAL_BUFF_SECONDS,
    };
    const ownLineup = ctx.lineups[side];
    [ownLineup.gr].concat(ownLineup.outfield).filter(Boolean).forEach(p=>{
      p.moral = roundDecimal(clamp(p.moral + msg.moralDelta, 0, 100));
    });
    addLog(ctx, ctx.clock||0, "sistema", `⏱️ ${teamName(ctx,side)} pede desconto de tempo — "${msg.label}" (restam ${ctx.timeoutsLeft[side]} nesta parte).`);
    // Correção (2026-09-16, pedido do utilizador): esta função é partilhada pelo pedido MANUAL do
    // utilizador (que já pausa o jogo antes de abrir o modal de escolha de mensagem, mais acima em
    // tmBtn/openTimeoutModal — nada muda para esse caso) e pelo pedido AUTOMÁTICO da IA
    // (maybeCallAiTimeout), que não tem modal nenhum para o utilizador escolher — não faz sentido
    // pedir-lhe uma mensagem por um desconto que não é dele. Primeiro tentou-se não pausar nada
    // (pedido inicial: "não faças uma caixa de texto"), mas o próprio utilizador esclareceu a
    // seguir que o desconto do adversário também é uma paragem real do jogo — e por isso deve
    // poder aproveitá-la para dar indicações à própria equipa (separador Táticas: sistema,
    // mentalidade, pressão, substituições), tal como aconteceria numa paragem real. O jogo volta a
    // pausar quando é o ADVERSÁRIO a pedir, mas com um motivo próprio ("desconto-adversario", em
    // vez de "desconto") — sem modal nenhum a abrir sozinho — para o utilizador poder mexer na
    // tática à vontade e retomar quando quiser.
    if(ctx.live && !ctx.simulating && ctx.userSide && side!==ctx.userSide){
      ctx.paused = true; ctx.pauseReason = "desconto-adversario"; ctx.timeoutSide = side; ctx.pausedByTacticsTab = false;
      if(typeof updatePauseBtnLabel==="function") updatePauseBtnLabel();
    }
    return true;
  }

  // A IA decide por si quando pedir um desconto de tempo e qual a mensagem — em jogos ao vivo
  // (lado adversário do utilizador) e também em jogos simulados em bloco entre duas equipas de IA,
  // já que ambos passam pelo mesmo runMatchTicks/manageSideTactics. Dois gatilhos simples e
  // pouco frequentes (nunca na fase inicial da parte): a perder ou empatado perto do fim, pede
  // para tentar mudar o jogo ("Motivar"); a ganhar por pouco perto do fim, pede para segurar o
  // resultado ("Serenar"). Sem gatilho claro, raramente pede só para "gastar" o desconto.
  function maybeCallAiTimeout(ctx, side){
    if(!canCallTimeout(ctx, side)) return;
    const matchClock = ctx.absoluteClock!=null ? ctx.absoluteClock : ctx.clock;
    if(ctx.clock < 180) return; // não faz sentido logo nos primeiros 3 minutos da parte
    if(matchClock - (ctx.lastTimeoutTick[side]!=null?ctx.lastTimeoutTick[side]:-999) < 300) return;
    const oppSide = side==="home"?"away":"home";
    const diff = ctx.score[side]-ctx.score[oppSide];
    const lateInPeriod = ctx.clock > ctx.periodLength - 480; // últimos 8 minutos da parte
    if(!lateInPeriod) return;
    if(diff<=0 && Math.random()<0.20){ callTimeout(ctx, side, "motivar"); return; }
    if(diff>0 && diff<=2 && Math.random()<0.16){ callTimeout(ctx, side, "serenar"); return; }
  }

  // 2026-10-16: golos sofridos e estatísticas de bolas paradas eram escritos diretamente em
  // player.season durante o jogo — também nos amigáveis (finalizePlayerStats ignora a época nos
  // amigáveis, mas estes já lá estavam). Num amigável as escritas vão para um objeto descartável.
  function seasonStatsFor(ctx,p){ return (ctx&&(ctx.friendly||ctx.isFriendly)) ? {} : p.season; }
  function checkPeriodEndCtx(ctx){
    if(ctx.clock < ctx.periodLength) return;
    // 2026-10-16: o efeito de um desconto de tempo e o "gelo" do lance seguinte usam ctx.clock, que
    // volta a 0 em cada parte — sem isto, um desconto no fim da 1.ª parte durava quase toda a 2.ª.
    ctx.timeoutMentalBuff = { home:null, away:null }; ctx.icedUntil = { home:0, away:0 };
    if(ctx.period===1){
      ctx.period=2; ctx.clock=0; ctx.posse={team:"home",clock:ATTACK_LIMIT};
      addLog(ctx,"INT","sistema","Fim da 1ª parte. Intervalo de 10 minutos (Art.3.4).");
      halfTimeRecovery(ctx);
      // Novos descontos de tempo para a 2ª parte — não se acumulam de uma parte para a outra (Art.9.1).
      ctx.timeoutsLeft = { home: TIMEOUTS_PER_PERIOD, away: TIMEOUTS_PER_PERIOD };
      if(ctx.live && !ctx.simulating){ ctx.paused=true; ctx.pauseReason="intervalo"; ctx.intervaloNextLabel="Iniciar 2ª Parte"; }
    } else if(ctx.period===2){
      if(ctx.score.home===ctx.score.away && ctx.isPlayoff){
        ctx.period="OT1"; ctx.periodLength=5*60; ctx.clock=0; ctx.posse={team:"away",clock:ATTACK_LIMIT};
        addLog(ctx,"PROL","sistema","Empate no fim do tempo regulamentar. Intervalo de 3 minutos antes do PROLONGAMENTO (Art.32).");
        if(ctx.live && !ctx.simulating){ ctx.paused=true; ctx.pauseReason="intervalo"; ctx.intervaloNextLabel="Iniciar Prolongamento"; }
      } else if(ctx.score.home===ctx.score.away){
        addLog(ctx,"FIM","sistema", `Apito final. Empate na fase regular: ${teamName(ctx,"home")} ${ctx.score.home}-${ctx.score.away} ${teamName(ctx,"away")}.`);
        ctx.finished = true;
      } else {
        addLog(ctx,"FIM","sistema", `Apito final. Resultado: ${teamName(ctx,"home")} ${ctx.score.home}-${ctx.score.away} ${teamName(ctx,"away")}.`);
        ctx.finished = true;
      }
    } else if(ctx.period==="OT1"){
      ctx.period="OT2"; ctx.clock=0; ctx.posse.team = ctx.posse.team==="home"?"away":"home"; ctx.posse.clock=ATTACK_LIMIT;
      addLog(ctx,"PROL","sistema","Fim da 1ª parte do prolongamento. Intervalo de 2 minutos.");
      if(ctx.live && !ctx.simulating){ ctx.paused=true; ctx.pauseReason="intervalo"; ctx.intervaloNextLabel="Iniciar 2ª Parte do Prolong."; }
    } else if(ctx.period==="OT2"){
      if(ctx.score.home===ctx.score.away){
        if(ctx.live && !ctx.simulating) beginInteractiveShootoutSetup(ctx);
        else runShootout(ctx);
      }
      else {
        addLog(ctx,"FIM","sistema", `Apito final (prolongamento). Resultado: ${teamName(ctx,"home")} ${ctx.score.home}-${ctx.score.away} ${teamName(ctx,"away")}.`);
        ctx.finished = true;
      }
    }
  }

  function isAiControlled(ctx, side){ return ctx.simulating || !ctx.live || side !== ctx.userSide; }

  // A IA gere o cansaço da sua equipa: substitui jogadores fatigados por suplentes mais frescos,
  // com um intervalo mínimo entre decisões e sensibilidade ao resultado (mais rotação a ganhar,
  // mais foco em qualidade a perder).
  function manageSideFatigue(ctx, side){
    const bench = (ctx.bench[side]||[]).filter(jogadorDisponivelNestaPartida);
    if(!bench || !bench.length) return;
    const matchClock = ctx.absoluteClock!=null ? ctx.absoluteClock : ctx.clock;
    const lu = ctx.lineups[side];
    const emergencyOnRink = [lu.gr].concat(lu.outfield).filter(Boolean).some(p=>(p.__fitness!=null?p.__fitness:100)<35);
    if(!emergencyOnRink && matchClock - (ctx.lastSubTick[side]!=null?ctx.lastSubTick[side]:-999) < 90) return; // 1:30, exceto emergência física
    const oppSide = side==="home"?"away":"home";
    const diff = ctx.score[side] - ctx.score[oppSide];
    // não convém deixar cair muito abaixo dos 75% — a ganhar pode poupar pernas ainda mais cedo;
    // a perder aguenta um pouco mais com quem está em bom nível, mas nunca deixa cair muito.
    const fatigueThreshold = diff > 0 ? 84 : diff < 0 ? 76 : 80;
    const criticalThreshold = 58;
    const onRinkAll = [lu.gr].concat(lu.outfield).filter(Boolean);
    let bestSwap = null, bestUrgency = -Infinity;
    onRinkAll.forEach(p=>{
      const fit = p.__fitness!=null ? p.__fitness : 100;
      const rating = clamp(6 + (p.__matchRatingDelta||0), 1, 10);
      const tiredEnough = fit < fatigueThreshold;
      const criticallyTired = fit < criticalThreshold;
      // uma exibição muito fraca (nota baixa), já com alguns minutos de jogo para ser justa,
      // também justifica tirar o jogador, mesmo que ainda tenha alguma forma física.
      const poorRating = ctx.clock > 300 && rating <= 4.4;
      if(!tiredEnough && !poorRating && !criticallyTired) return;
      // GR troca apenas por GR. Jogadores de campo podem trocar entre AVÇ e DEF/MED:
      // a função natural serve como preferência, mas nunca bloqueia um suplente muito mais fresco.
      const pool = p.pos==="GR" ? bench.filter(b=>b.pos==="GR") : bench.filter(b=>b.pos==="J");
      if(!pool.length) return;
      const candidate = pool.slice().sort((a,b)=>{
        const fitA = a.__fitness!=null?a.__fitness:100;
        const fitB = b.__fitness!=null?b.__fitness:100;
        // Fase B: prefere um suplente da mesma linha e, sobretudo, do mesmo perfil funcional
        // (construtor/defensivo/móvel em DEF-MED; finalizador/móvel em AVÇ) — não escolhe só
        // pelo maior OVR disponível.
        const sameLinhaA = p.pos==="J" && a.linha===p.linha;
        const sameLinhaB = p.pos==="J" && b.linha===p.linha;
        const roleA = sameLinhaA ? (playerProfile(a)===playerProfile(p) ? 5 : 3) : 0;
        const roleB = sameLinhaB ? (playerProfile(b)===playerProfile(p) ? 5 : 3) : 0;
        const scoreA = fitA + overall(a)*0.35 + roleA;
        const scoreB = fitB + overall(b)*0.35 + roleB;
        return scoreB-scoreA;
      })[0];
      const inFit = candidate.__fitness!=null ? candidate.__fitness : 100;
      if(!criticallyTired && tiredEnough && !poorRating && inFit - fit < 8) return;
      if(criticallyTired && inFit <= fit) return; // abaixo de 58%, qualquer suplente mais fresco é preferível
      const qualityBoost = diff < 0 ? (overall(candidate)-overall(p))*0.4 : 0;
      const urgency = (tiredEnough ? (fatigueThreshold - fit) : 0) + (criticallyTired ? (criticalThreshold-fit)*2+20 : 0) + (poorRating ? (4.4-rating)*10 : 0) + (inFit-fit)*0.45 + qualityBoost;
      if(urgency > bestUrgency){ bestUrgency = urgency; bestSwap = { out:p, in:candidate }; }
    });
    if(bestSwap){
      performSub(ctx, side, bestSwap.out, bestSwap.in, "manual");
      ctx.lastSubTick[side] = matchClock;
    }
  }

  // Fase B (secções 14-15): a IA reavalia mentalidade/pressão/sistema ao longo do jogo consoante
  // o resultado e o tempo restante — mais risco a perder perto do fim, mais cautela a proteger o
  // resultado — com um intervalo mínimo entre ajustes para não mudar de tática constantemente
  // sem motivo. Também cobre o caso de fadiga do documento: em 2-2, se um dos AVÇ está exausto e
  // não há outro AVÇ fresco no banco mas existe um DEF/MED fresco, passa para 3-1 em vez de
  // forçar um DEF/MED a jogar artificialmente como segundo avançado.
  function shouldSwitchToThreeOneForFatigue(ctx, side, teamObj){
    if((teamObj.sistema||"3-1")!=="2-2") return false;
    const lu = ctx.lineups[side], bench = ctx.bench[side]||[];
    if(!lu) return false;
    const isFresh = p => (p.__fitness!=null?p.__fitness:100) > 65;
    const isTired = p => (p.__fitness!=null?p.__fitness:100) < 50;
    const tiredAvc = lu.outfield.some(p=>p.linha==="Avancado" && isTired(p));
    if(!tiredAvc) return false;
    const freshAvcBench = bench.some(p=>p.pos==="J" && p.linha==="Avancado" && isFresh(p));
    if(freshAvcBench) return false; // há substituto adequado — não precisa de mudar de sistema
    return bench.some(p=>p.pos==="J" && p.linha!=="Avancado" && isFresh(p));
  }
  function manageSideTactics(ctx, side){
    const teamObj = state.teams[side==="home"?ctx.homeId:ctx.awayId];
    if(!teamObj) return;
    const matchClock = ctx.absoluteClock!=null ? ctx.absoluteClock : ctx.clock;
    if(matchClock < 240) return; // dá tempo ao jogo assentar antes de reagir
    if(matchClock - (ctx.lastTacticTick[side]!=null?ctx.lastTacticTick[side]:-999) < 240) return;
    const oppSide = side==="home"?"away":"home";
    const diff = ctx.score[side]-ctx.score[oppSide];
    const timeLeftRatio = clamp(1-matchClock/3000, 0, 1); // ~50 minutos de jogo úteis
    let changed=false;
    if(shouldSwitchToThreeOneForFatigue(ctx, side, teamObj)){
      teamObj.sistema = "3-1"; changed=true;
    } else if(diff < 0 && timeLeftRatio < 0.55){
      if(teamObj.mentalidade!=="ofensivo"){ teamObj.mentalidade="ofensivo"; changed=true; }
      if(teamObj.pressao==="baixa"){ teamObj.pressao="media"; changed=true; }
      if(diff<=-2 && teamObj.sistema!=="2-2" && systemFitScore(teamObj,"2-2") >= systemFitScore(teamObj,"3-1")-8){
        teamObj.sistema="2-2"; changed=true;
      }
    } else if(diff > 0 && timeLeftRatio < 0.4){
      if(teamObj.mentalidade!=="defensivo"){ teamObj.mentalidade="defensivo"; changed=true; }
      if(teamObj.pressao==="alta"){ teamObj.pressao="media"; changed=true; }
      if(diff>=2 && teamObj.sistema!=="3-1" && systemFitScore(teamObj,"3-1") >= systemFitScore(teamObj,"2-2")-8){
        teamObj.sistema="3-1"; changed=true;
      }
    }
    if(changed){
      ctx.lastTacticTick[side] = matchClock;
      addLog(ctx, ctx.clock||0, "sistema", `🔄 ${teamName(ctx,side)} ajusta a tática: sistema ${teamObj.sistema} · mentalidade ${teamObj.mentalidade} · pressão ${teamObj.pressao}.`);
      if(ctx.live && !ctx.simulating) syncTaticasUI();
    }
  }

  function runMatchTicks(ctx){
    if(ctx.finished || ctx.paused) return;
    // Grandes penalidades jogáveis: uma vez escolhida a ordem/guarda-redes (openShootoutSetupModal),
    // cada "tick" resolve só uma marcação — nada do resto desta função (fadiga, posse, lesões,
    // relógio de parte) se aplica durante o desempate.
    if(ctx.period==="SO" && ctx.shootout && ctx.shootout.active){
      advanceInteractiveShootoutTick(ctx);
      return;
    }
    ctx.clock += TICK_GAME_SECONDS;
    ctx.absoluteClock = (ctx.absoluteClock||0) + TICK_GAME_SECONDS;
    ["home","away"].forEach(side=>{ if(ctx.inferioridade[side]>0) ctx.inferioridade[side] = Math.max(0, ctx.inferioridade[side]-TICK_GAME_SECONDS); });
    // Fadiga e recuperação aplicam-se sempre — jogo ao vivo e simulação rápida seguem as mesmas
    // regras, para que a condição final seja sempre coerente com o tempo realmente jogado.
    ["home","away"].forEach(side=>{
      const lu = ctx.lineups[side];
      const teamObj = state.teams[side==="home"?ctx.homeId:ctx.awayId];
      // jogar ofensivo (tempo mais alto, mais pressão) cansa mais; defensivo poupa um pouco.
      const tacticFatigueMult = teamObj.mentalidade==="ofensivo" ? 1.3 : teamObj.mentalidade==="defensivo" ? 0.9 : 1;
      if(!ctx.playerMinutes) ctx.playerMinutes = {};
      [lu.gr].concat(lu.outfield).forEach(p=>{
        if(!p) return;
        ctx.playerMinutes[p.id] = (ctx.playerMinutes[p.id]||0) + TICK_GAME_SECONDS/60; // minutos reais em pista (carga, estatísticas)
        const cur = p.__fitness!=null ? p.__fitness : 100;
        const decay = p.pos==="GR" ? fitnessDecayPerTickGK(p, TICK_GAME_SECONDS, ctx.intensity) : fitnessDecayPerTick(p, TICK_GAME_SECONDS, tacticFatigueMult, ctx.intensity);
        p.__fitness = clamp(cur - decay, 0, 100);
      });
      (ctx.bench[side]||[]).forEach(p=>{
        const cur = p.__fitness!=null ? p.__fitness : 100;
        p.__fitness = clamp(cur + 0.4*(TICK_GAME_SECONDS/60), 0, 100);
      });
    });
    checkInjuries(ctx);
    if(ctx.paused) return;
    processPendingReturns(ctx);
    if(ctx.paused) return;
    if(isAiControlled(ctx,"home")) manageSideFatigue(ctx, "home");
    if(isAiControlled(ctx,"away")) manageSideFatigue(ctx, "away");
    if(isAiControlled(ctx,"home")) manageSideTactics(ctx, "home");
    if(isAiControlled(ctx,"away")) manageSideTactics(ctx, "away");
    if(isAiControlled(ctx,"home")) maybeCallAiTimeout(ctx, "home");
    if(isAiControlled(ctx,"away")) maybeCallAiTimeout(ctx, "away");
    if(isAiControlled(ctx,"home")) manageGoalkeeperPull(ctx, "home");
    if(isAiControlled(ctx,"away")) manageGoalkeeperPull(ctx, "away");
    ctx.posse.clock -= TICK_GAME_SECONDS;
    const attacker = ctx.posse.team, defender = attacker==="home"?"away":"home";
    ctx.possessionSeconds[attacker] = (ctx.possessionSeconds[attacker]||0) + TICK_GAME_SECONDS;
    const infModAtt = ctx.inferioridade[attacker]>0?0.78:1;
    const infModDef = ctx.inferioridade[defender]>0?0.80:1;
    if(ctx.posse.clock<=0){
      addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,attacker)} excede os 45 segundos de posse — livre indireto para ${teamName(ctx,defender)}.`);
      turnPossession(ctx, defender);
    } else {
      const strAtt = ctx.live ? onRinkStrength(ctx, attacker) : (attacker==="home"?ctx.homeStr:ctx.awayStr);
      const strDefForShot = ctx.live ? onRinkStrength(ctx, defender) : (defender==="home"?ctx.homeStr:ctx.awayStr);
      const roll = Math.random();
      // uma defesa mais forte (organizada) impede o ataque de sequer concluir o lance, o que
      // faz o relógio de 45s correr mais vezes até ao fim; em powerplay o atacante tende a
      // "perder tempo" contra uma equipa retraída, ainda que em superioridade numérica
      const defQualityFactor = clamp(14/Math.max(8, safeNum(strDefForShot.defense,12)*infModDef), 0.62, 1.25);
      const isPowerplayForAttacker = ctx.inferioridade[defender] > 0;
      // Rede de segurança (bug real, 2026-10-04 — ver nota grande no topo do ficheiro): mesmo que
      // strAtt/strDefForShot viessem corrompidos (NaN) de algures, shotChance nunca pode ficar
      // NaN — senão `roll<shotChance`, `roll<shotChance+foulChance` e
      // `roll<shotChance+foulChance+cardChance` ficam TODOS permanentemente falsos (NaN nunca é
      // maior/menor que nada), e a partida deixa de poder gerar remates, faltas ou cartões,
      // sobrando só o loop do relógio de posse de 45 segundos — exatamente o bug relatado.
      const shotChanceRaw = 0.16*(safeNum(strAtt.attack,12)/14)*infModAtt*defQualityFactor*(isPowerplayForAttacker?1.0:1);
      const shotChance = safeNum(shotChanceRaw, 0.16);
      const defTeamObjForDiscipline = state.teams[defender==="home"?ctx.homeId:ctx.awayId];
      const aggroTacticDef = (defTeamObjForDiscipline && defTeamObjForDiscipline.pressao) || "media";
      const aggroDisciplineMult = aggroTacticDef==="alta" ? 1.5 : aggroTacticDef==="baixa" ? 0.6 : 1;
      const foulChance = 0.20*aggroDisciplineMult*(ctx.arbRate ? ctx.arbRate.foul[defender] : 1);
      const cardChance = 0.028*aggroDisciplineMult*(ctx.arbRate ? ctx.arbRate.card[defender] : 1);
      if(roll<shotChance){
        const attackTeamObj = state.teams[attacker==="home"?ctx.homeId:ctx.awayId];
        const effectiveShotTarget = ctx.targetShots[attacker] * liveShotTacticMult(attackTeamObj);
        // Correção (pedido do utilizador, 2026-09-17: "o jogo às vezes tem muitos golos de
        // rajada e depois muitos minutos sem golos, até ao fim, como se tivesse atingido um
        // limite artificial"): o corte antigo era binário — assim que ctx.shots[attacker]
        // chegava a effectiveShotTarget, essa equipa deixava de poder rematar pelo resto do
        // jogo. Se o "orçamento" de remates fosse esgotado cedo por sorte (rajada inicial), o
        // resto do jogo ficava artificialmente morto para essa equipa. paceCeiling distribui o
        // mesmo orçamento no tempo: no máximo 55% pode ser "gasto" logo no início (em vez de
        // 100%), com o resto a libertar-se linearmente até aos 90% do tempo regulamentar —
        // chegando ao mesmo valor final effectiveShotTarget bem antes do fim, para nunca
        // impedir o desfecho natural do jogo. Uma equipa NUNCA fica com um "muro" total: mesmo
        // no pior caso (rajada a esgotar logo os 55% iniciais permitidos), continua a ter janela
        // real de remate ao longo de todo o resto do jogo, em vez de silêncio até ao apito final.
        // Calibração: 55%/90% (em vez de, por exemplo, 30%/100%) foi escolhida por manter as
        // médias de golos/remates por jogo já calibradas dentro de ~1% do valor antigo — um teto
        // mais permissivo no início evita empurrar remates a mais para tarde no jogo, onde a
        // fadiga acumulada da defesa os tornaria sistematicamente mais fáceis de converter em
        // golo (ver blendedLiveStrength/fitnessFactor), o que inflacionava artificialmente a
        // média de golos com um teto mais agressivo (testado empiricamente).
        const paceProgress = clamp(ctx.absoluteClock / (2*CATEGORY_PERIOD_SECONDS*PACE_END_FRAC), 0, 1);
        // Correção (pedido do utilizador, 2026-10-05: "já joguei vários prolongamentos, nunca vi um
        // golo em nenhuma das partes"): o orçamento de remates cobre só o tempo regulamentar e
        // chega a 100% aos 90% desse tempo — quando o jogo empatava e ia a prolongamento, as duas
        // equipas já tinham gasto TODO o orçamento, pelo que cada remate no prolongamento era
        // convertido em simples perda de posse (0 remates, 0 golos em ~99% dos prolongamentos).
        // No prolongamento o orçamento continua a crescer ao ritmo médio do tempo regulamentar
        // (alvo / 50 min), para que haja remates — e golos — ao mesmo ritmo do resto do jogo.
        const regulationSeconds = 2*CATEGORY_PERIOD_SECONDS;
        const otExtraBudget = ctx.absoluteClock > regulationSeconds
          ? effectiveShotTarget * ((ctx.absoluteClock - regulationSeconds) / regulationSeconds) : 0;
        const paceCeiling = effectiveShotTarget * PACE_BOOST * clamp(PACE_START + paceProgress*(1-PACE_START), 0, 1) + otExtraBudget;
        if((ctx.shots[attacker]||0) >= paceCeiling){
          // esta equipa já atingiu o remates disponíveis para esta fase do jogo — mantém o
          // número de remates consistente com o previsto para o jogo inteiro
          turnPossession(ctx, defender);
        } else {
          ctx.shots[attacker] = (ctx.shots[attacker]||0)+1;
          resolveShot(ctx, attacker, defender, infModAtt, infModDef, false);
        }
      }
      else if(roll<shotChance+foulChance) resolveFoul(ctx, defender, attacker, ctx.clock);
      else if(roll<shotChance+foulChance+cardChance) resolveCard(ctx, defender, ctx.clock);
    }
    checkPeriodEndCtx(ctx);
  }

  // ============================= Fase 2: relatórios do treinador adjunto =============================
  // Histórico tático por clube: um registo por jogo (sistema/mentalidade/pressão usados,
  // resultado, golos, remates, condição final) — base para os relatórios pré-jogo, pós-jogo e
  // mensal. Guardado para todos os clubes (não só o do utilizador), para que os relatórios
  // pré-jogo possam descrever também os adversários.
  function recordTacticalMatchHistory(ctx){
    ["home","away"].forEach(side=>{
      const teamId = side==="home"?ctx.homeId:ctx.awayId;
      const team = state.teams[teamId];
      if(!team) return;
      const oppId = side==="home"?ctx.awayId:ctx.homeId;
      const gf = ctx.score[side], ga = ctx.score[side==="home"?"away":"home"];
      const resultado = gf>ga?"V":gf<ga?"D":"E";
      const outfield = (ctx.lineups[side]&&ctx.lineups[side].outfield)||[];
      const condicaoFinal = outfield.length ? Math.round(avg(outfield.map(p=>p.__fitness!=null?p.__fitness:100))) : 100;
      if(!Array.isArray(team.historicoTatico)) team.historicoTatico=[];
      team.historicoTatico.unshift({
        date: state.currentDate ? isoDate(state.currentDate) : null,
        opponentId: oppId, isHome: side==="home",
        sistema: team.sistema||"3-1", mentalidade: team.mentalidade||"equilibrado", pressao: team.pressao||"media",
        resultado, golosMarcados: gf, golosSofridos: ga,
        remates: ctx.shots?(ctx.shots[side]||0):0, condicaoFinal,
        grPuxado: ctx.grPuxado?(ctx.grPuxado[side]||0):0,
      });
      if(team.historicoTatico.length>60) team.historicoTatico.length=60;
    });
  }
  // Análise pós-jogo (secção 6 do documento) — só para o clube do utilizador, gerada logo a
  // seguir ao apito final (ambos os caminhos, ao vivo e simulação rápida, passam por
  // finalizePlayerStats). Aparece nas notícias, como pedido.
  function generatePostGameReport(ctx, side, mvp){
    const teamId = side==="home"?ctx.homeId:ctx.awayId;
    if(teamId!==state.userTeamId) return;
    const team = state.teams[teamId];
    const oppSide = side==="home"?"away":"home";
    const oppId = side==="home"?ctx.awayId:ctx.homeId;
    const opp = state.teams[oppId]; if(!opp) return;
    const gf = ctx.score[side], ga = ctx.score[oppSide];
    const resultadoTxt = gf>ga?"Vitória":gf<ga?"Derrota":"Empate";
    const friendly = !!(ctx.friendly||ctx.isFriendly);
    const outfield = (ctx.lineups[side]&&ctx.lineups[side].outfield)||[];
    const condicaoFinal = outfield.length ? Math.round(avg(outfield.map(p=>p.__fitness!=null?p.__fitness:100))) : 100;
    const remates = ctx.shots?(ctx.shots[side]||0):0, rematesAdv = ctx.shots?(ctx.shots[oppSide]||0):0;
    const enq = shotsOnTargetFor(ctx, side), enqAdv = shotsOnTargetFor(ctx, oppSide);
    const posseTot = (ctx.possessionSeconds.home||0)+(ctx.possessionSeconds.away||0);
    const posse = posseTot>0 ? Math.round((ctx.possessionSeconds[side]||0)/posseTot*100) : null;
    const cartoes = (ctx.cartoes&&ctx.cartoes[side])||[];
    const nAm = cartoes.filter(c=>c==="amarelo").length, nAz = cartoes.filter(c=>c==="azul").length, nVm = cartoes.filter(c=>c==="vermelho").length;
    const sp = (ctx.setPieces&&ctx.setPieces[side])||{penalti:0,livredireto:0};
    // jogadores que atuaram, com nota, golos, assistências e condição prevista no fim do jogo
    const playedIds = ctx.playedSet ? ctx.playedSet[side] : new Set([ctx.lineups[side].gr?ctx.lineups[side].gr.id:null].concat(outfield.map(p=>p.id)).filter(Boolean));
    const jog = team.players.filter(p=>playedIds.has(p.id)).map(p=>{
      const fit = p.__fitness!=null?p.__fitness:100, prev = p.condicao!=null?p.condicao:100;
      return { p, nota: matchRating(ctx,side,p), g:p.__matchGoals||0, a:p.__matchAssists||0, gs:p.__matchGolosSofridos||0, cards:(p.__cardsThisMatch||[]).slice(), cond: Math.round(prev*0.35+fit*0.65) };
    });
    const nome = j => playerLinkHtml(team.id, j.p);
    const nota = j => j.nota.toFixed(1).replace(".",",");
    const porNota = jog.slice().sort((a,b)=>b.nota-a.nota||b.g-a.g);
    const melhor = (mvp && mvp.side===side && jog.find(j=>j.p.id===mvp.id)) || porNota[0] || null;
    const marcadores = jog.filter(j=>j.g>0).sort((a,b)=>b.g-a.g);
    const assist = jog.filter(j=>j.a>0).sort((a,b)=>b.a-a.a);
    const gr = jog.filter(j=>j.p.pos==="GR");
    const abaixo = porNota.slice().reverse().find(j=>j.nota<5.6 && j!==melhor) || null;
    const lista = (arr, f) => arr.map(f).join(", ");
    // saúde e rotação
    const lesNoJogo = (ctx.injuriesThisMatch||[]).filter(i=>i.side===side).map(i=>{
      const q = team.players.find(x=>x.name===i.name);
      const log = q && q.lesoesLog && q.lesoesLog[0];
      const t = log && lesTipo(log.tipoId);
      return q ? `${playerLinkHtml(team.id,q)} (${t?t.nome.toLowerCase()+(log.zona?", "+escapeHtml(log.zona):""):"lesão"}${log&&log.gravidade==="grave"?", grave":", ligeira"})` : escapeHtml(i.name);
    });
    const cansados = jog.filter(j=>j.cond<65 && (j.p.diasLesao||0)<=0).sort((a,b)=>a.cond-b.cond);
    const readapt = jog.filter(j=>j.p.readapt);
    const suspensos = jog.filter(j=>(ctx.vermelhosDiretos||[]).some(v=>v.playerId===j.p.id));
    const positivos=[], negativos=[];
    if(remates>=15) positivos.push("elevado número de remates");
    if(team.sistema==="2-2") positivos.push("boa exploração das transições"); else positivos.push("boa organização defensiva");
    if(gf>ga) positivos.push("pressão eficaz nos momentos-chave");
    if(condicaoFinal<60) negativos.push("desgaste excessivo");
    if(ga>=3) negativos.push("erros defensivos nos minutos finais");
    if(gf<=1 && gf<ga) negativos.push("pouca produção ofensiva");
    if(remates>=12 && gf<=1) negativos.push("falta de eficácia na finalização");
    const mentLabel = {defensivo:'Defensiva',equilibrado:'Equilibrada',ofensivo:'Ofensiva'}[team.mentalidade]||team.mentalidade;
    const prox = [];
    if(cansados.length>=2 || condicaoFinal<60) prox.push(`rodar o plantel: poupar ${lista(cansados.slice(0,3), nome)||"os titulares mais desgastados"}`);
    else if(cansados.length===1) prox.push(`gerir os minutos de ${nome(cansados[0])}`);
    if(ga>=3) prox.push("reforçar a organização defensiva (mentalidade mais prudente)");
    if(gf<=1 && gf<ga) prox.push("arriscar mais no ataque ou dar mais liberdade criativa");
    if(lesNoJogo.length) prox.push("rever a convocatória: há lesionados");
    if(friendly) prox.push("aproveitar os jogos de preparação para rodar e experimentar");
    if(!prox.length) prox.push("manter a abordagem e a rotação atuais");
    const chips = [repChip(`${resultadoTxt} ${gf}-${ga}`, gf>ga?"ok":gf<ga?"mau":""), repChip(`Sistema ${team.sistema}`), repChip(`Mentalidade ${mentLabel.toLowerCase()}`), repChip(`${remates} remates`)];
    if(posse!=null) chips.push(repChip(`Posse ${posse}%`));
    if(cartoes.length) chips.push(repChip(`${cartoes.length} cartõ${cartoes.length>1?"es":""}`, nVm?"mau":"aviso"));
    if(lesNoJogo.length) chips.push(repChip(`${lesNoJogo.length} lesão${lesNoJogo.length>1?"ões":""}`, "mau"));
    chips.push(repChip(`Condição final ${condicaoFinal}%`, condicaoFinal<60?"aviso":""));
    const resumo = `${gf>ga?`Vitória por ${gf}-${ga} sobre o`:gf<ga?`Derrota por ${gf}-${ga} frente ao`:`Empate a ${gf} com o`} ${teamLinkHtml(opp.id)}${melhor?`; melhor em campo: ${nome(melhor)} (${nota(melhor)})`:""}. ${lesNoJogo.length?`${lesNoJogo.length} lesão${lesNoJogo.length>1?"ões":""} no jogo. `:""}Próximo passo: ${prox[0]}.`;
    const html = repDoc({
      teamId: team.id, org: "Departamento técnico", titulo: "Análise do Treinador Adjunto",
      sub: `${resultadoTxt} ${gf}-${ga} · ${friendly?"jogo de preparação":"análise pós-jogo"} · ${fmtDateLong(state.currentDate)}`,
      vsId: opp.id, vsTexto: gf>ga?"venceste":gf<ga?"perdeste com":"empataste com",
      chips, resumo,
      secoes: [
        { icone:"📊", titulo:"Resumo do jogo", linhas:[
          ["Resultado", `<b>${gf}-${ga}</b>${ctx.soWinner?" (g.p.)":""}`],
          ["Remates", `<b>${remates}</b> (${enq} enquadrados) contra ${rematesAdv} (${enqAdv})`],
          ["Eficácia", `${remates?Math.round(gf/remates*100):0}% ofensiva · ${rematesAdv?Math.round((rematesAdv-ga)/rematesAdv*100):100}% defensiva`],
          ["Posse", posse!=null?`${posse}%`:"—"],
          ["Faltas", `${ctx.faltas?ctx.faltas[side]:0} contra ${ctx.faltas?ctx.faltas[oppSide]:0}`],
          ["Cartões", cartoes.length?`${nAm} amarelo${nAm!==1?"s":""}, ${nAz} azul${nAz!==1?"is":""}, ${nVm} vermelho${nVm!==1?"s":""}`:"nenhum"],
          ["Bolas paradas", `${sp.penalti||0} penálti${(sp.penalti||0)!==1?"s":""} · ${sp.livredireto||0} livre${(sp.livredireto||0)!==1?"s":""} direto${(sp.livredireto||0)!==1?"s":""}`],
        ]},
        { icone:"⭐", titulo:"Destaques individuais", linhas:[
          ["Melhor em campo", melhor?`${nome(melhor)} (nota ${nota(melhor)})`:"—"],
          ["Marcadores", marcadores.length?lista(marcadores, j=>`${nome(j)}${j.g>1?` (${j.g})`:""}`):"sem golos nossos"],
          ["Assistências", assist.length?lista(assist, j=>`${nome(j)}${j.a>1?` (${j.a})`:""}`):"nenhuma"],
          ["Guarda-redes", gr.length?lista(gr, j=>`${nome(j)} (${j.gs} golo${j.gs!==1?"s":""} sofrido${j.gs!==1?"s":""}, nota ${nota(j)})`):"—"],
          ["Abaixo do esperado", abaixo?`${nome(abaixo)} (nota ${nota(abaixo)})`:"ninguém"],
        ]},
        { icone:"🩺", titulo:"Saúde e rotação", linhas:[
          ["Lesões no jogo", lesNoJogo.length?lesNoJogo.join(", "):"nenhuma"],
          ["Condição prevista", cansados.length?lista(cansados.slice(0,4), j=>`${nome(j)} ${j.cond}%`):"todos os que jogaram acima de 65%"],
          ["Em readaptação", readapt.length?lista(readapt, j=>`${nome(j)} (risco ×${lesReadaptMult(j.p).toFixed(1)})`):"ninguém"],
          ["Suspensos", suspensos.length?lista(suspensos, nome)+" (vermelho direto)":"ninguém por expulsão"],
        ]},
        { icone:"🧩", titulo:"Leitura tática", linhas:[
          ["Pontos positivos", positivos.length?positivos.join(", "):"—"],
          ["Pontos negativos", negativos.length?negativos.join(", "):"—"],
          ["Próximo jogo", prox.join("; ")+"."],
        ]},
      ],
      rodape: "Análise pós-jogo · treinador adjunto",
    });
    pushNews(state.currentDate, html, "tatica", `Análise pós-jogo: ${resultadoTxt} ${gf}-${ga} vs ${opp.name}`);
  }

  function finalizePlayerStats(ctx, mvp){
    const friendly=!!ctx.isFriendly;
    if(!friendly) recordTacticalMatchHistory(ctx);
    generatePostGameReport(ctx, "home", mvp);
    generatePostGameReport(ctx, "away", mvp);
    ["home","away"].forEach(side=>{
      const team = state.teams[side==="home"?ctx.homeId:ctx.awayId];
      const playedIds = ctx.playedSet ? ctx.playedSet[side] : new Set([ctx.lineups[side].gr?ctx.lineups[side].gr.id:null].concat(ctx.lineups[side].outfield.map(p=>p.id)).filter(Boolean));
      const startingIds = ctx.startingIds ? ctx.startingIds[side] : playedIds;
      team.players.forEach(p=>{
        if(friendly){
          // Jogo de preparação: não conta para estatísticas da época, suspensões nem satisfação;
          // só o desgaste físico/lesões (abaixo) e um pouco de moral.
          if(playedIds.has(p.id)){
            const fr = matchRating(ctx,side,p);
            if((ctx.vermelhosDiretos||[]).some(v=>v.playerId===p.id)) p.suspensoJogos=Math.max(0,(p.suspensoJogos||0)-1);
            updateMoralAfterMatch(p, true, fr, team);
          }
        } else if(playedIds.has(p.id)){
          const rating = matchRating(ctx,side,p);
          p.season.notas.push(Math.round(rating*10)/10);
          p.season.jogos++;
          // Prémios de fim de época (2026-09-21): antes, ctx.competitionId nunca era preenchido
          // por nenhum chamador, por isso este recurso a state.userCompetitionId era, na
          // prática, sempre usado — TODOS os jogos (taças, Europa, playoffs, outras divisões)
          // ficavam registados como se fossem da competição do próprio utilizador. Agora que
          // cada chamador passa o id real, o recurso a state.userCompetitionId deixa de ser
          // necessário (mantém-se "amistoso" só para jogos de teste/treino sem competição).
          const participationSeason=seasonLabel(state.season), competitionId=ctx.competitionId||"amistoso";
          if(!p.participacaoCompeticoes||typeof p.participacaoCompeticoes!=="object") p.participacaoCompeticoes={};
          if(!p.participacaoCompeticoes[participationSeason]) p.participacaoCompeticoes[participationSeason]={};
          const participationKey=`${competitionId}:${team.id}`;
          const participation=p.participacaoCompeticoes[participationSeason][participationKey]||{clubeId:team.id,competicaoId:competitionId,jogos:0,minutos:0};
          participation.jogos++; participation.minutos+=Math.max(0,Math.round((ctx.playerMinutes&&ctx.playerMinutes[p.id]!=null)?ctx.playerMinutes[p.id]:50));
          p.participacaoCompeticoes[participationSeason][participationKey]=participation;
          if(startingIds.has(p.id)) p.season.jogosTitular = (p.season.jogosTitular||0)+1;
          else p.season.jogosSuplente = (p.season.jogosSuplente||0)+1;
          p.season.golos += (p.__matchGoals||0);
          if(!ctx.isPlayoff) registosCreditarGolos(ctx.competitionId, p, team, p.__matchGoals||0); // Registos das ligas: maior goleador (10b-registos.js)
          p.season.assistencias += (p.__matchAssists||0);
          const matchCards = p.__cardsThisMatch||[];
          p.season.amarelos = (p.season.amarelos||0) + matchCards.filter(c=>c==="amarelo").length;
          p.season.azuis = (p.season.azuis||0) + matchCards.filter(c=>c==="azul").length;
          p.season.vermelhos = (p.season.vermelhos||0) + matchCards.filter(c=>c==="vermelho").length;
          if(mvp && mvp.id===p.id && mvp.side===side) p.season.mvp = (p.season.mvp||0)+1;
          // Prémios de fim de época (2026-09-21): a mesma entrada de participacaoCompeticoes já
          // criada acima (jogos/minutos) passa também a acumular golos, assistências, notas e
          // MVPs por competição — necessário porque player.season.* é agregado de TODAS as
          // competições da época, e um prémio por competição (melhor marcador/jogador/guarda-
          // redes de uma prova específica) precisa de números que não misturem liga com taça.
          participation.golos = (participation.golos||0) + (p.__matchGoals||0);
          participation.assistencias = (participation.assistencias||0) + (p.__matchAssists||0);
          participation.golosSofridos = (participation.golosSofridos||0) + (p.__matchGolosSofridos||0);
          if(!Array.isArray(participation.notas)) participation.notas = [];
          participation.notas.push(Math.round(rating*10)/10);
          participation.mvp = (participation.mvp||0) + ((mvp && mvp.id===p.id && mvp.side===side) ? 1 : 0);
          updateMoralAfterMatch(p, true, rating, team);
          updateSatisfacaoAfterMatch(p, team, true);
        } else if(playerAvailableForMatch(p)){
          // Correção (pedido do utilizador, 2026-09-17: "um jogador lesionado não pode
          // reclamar por falta de oportunidades"): um jogador genuinamente indisponível
          // (lesionado/suspenso) não podia sequer ser convocado — não sofre penalização de
          // moral/satisfação por "não ter jogado" nem entra na sua janela de utilização recente
          // (__recentPlayed), evitando que a lesão em si pareça, mais tarde, "falta de minutos".
          updateMoralAfterMatch(p, false, null, team);
          updateSatisfacaoAfterMatch(p, team, false);
        }
        // Condição física: combina o valor real de fadiga com que a partida terminou para este
        // jogador com a condição que já tinha antes do jogo — nunca um novo cálculo abstrato.
        // Calibração: copiar o valor final da partida sem qualquer suavização (como acontecia
        // antes) fazia a condição entrar em espiral descendente em plantéis de resistência
        // baixa — um jogo muito desgastante deixava a condição tão em baixo que a recuperação
        // diária normal nunca chegava a repor o terreno perdido antes do jogo seguinte. Uma
        // parte da condição anterior ao jogo "protege" o ponto de partida da recuperação, sem
        // deixar de refletir o desgaste real da partida.
        if(p.__fitness != null){
          const prevCondicao = p.condicao != null ? p.condicao : 100;
          p.condicao = roundDecimal(clamp(prevCondicao*0.35 + p.__fitness*0.65, 0, 100));
        }
        p.__matchRatingDelta=0; p.__matchGoals=0; p.__matchAssists=0; p.__matchGolosSofridos=0; p.__cardsThisMatch=[]; p.__fitness=null;
      });
    });
    cargaAposJogo(ctx); // carga de trabalho (08l-carga.js): todos os clubes
    disciplinaAposJogo(ctx); // Conselho de Disciplina (08k-disciplina.js): processos de expulsões diretas e incidentes com o público
    tvAposJogo(ctx); // Televisão (08m-televisao.js): receitas, exposição e humor dos adeptos
    arbitroAposJogo(ctx); // Árbitros (08q-arbitros.js): histórico do árbitro, polémicas e queixas
    anaAposJogo(ctx); // Análise do adversário (08r-analise.js): verificação das contramedidas e do relatório
    if(ctx.emergencyPlayers && ctx.emergencyPlayers.length){
      removeProvisionalPlayers(state.teams[ctx.homeId], ctx.emergencyPlayers);
      removeProvisionalPlayers(state.teams[ctx.awayId], ctx.emergencyPlayers);
    }
  }
  function roundDecimal(v){ return Math.round(v*10)/10; }
  // A forma recente da equipa (últimos 10 jogos) entra também na moral — uma equipa em bom
  // momento anima os jogadores mesmo que a exibição pessoal seja mediana, e vice-versa.
  function teamFormMoralModifier(team){
    const results = team.recentResults || [];
    if(!results.length) return 0;
    const pts = results.reduce((s,r)=>s+(r==="V"?3:r==="E"?1:0),0);
    const avgPts = pts/results.length; // 0 a 3
    return (avgPts-1)*1.4;
  }
  function updateMoralAfterMatch(p, played, rating, team){
    const rates = TEMPERAMENT_RATES[p.temperamento] || TEMPERAMENT_RATES["Profissional"];
    const formMod = team ? (teamFormMoralModifier(team) + balnearioMoralMod(team)) * persMoralMult(p) : 0;
    if(played){
      const perf = (rating!=null?rating:6) - 6;
      p.moral = roundDecimal(clamp(p.moral + rates.gainPlayed + perf*rates.sensitivity + formMod, 0, 100));
    } else {
      p.moral = roundDecimal(clamp(p.moral - rates.decayBenched + formMod, 0, 100));
    }
  }

  // Reputação do jogador (oculta): cresce com o OVR, a experiência de carreira (jogos) e os
  // títulos ganhos — evolui ao longo da carreira, não é um valor fixo.
  function computePlayerReputation(p){
    const ovrComponent = clamp((overall(p)-10)*4, 0, 60);
    const experienceComponent = clamp((p.career.jogos||0)*0.15, 0, 25);
    const titlesComponent = clamp((p.titulos?p.titulos.length:0)*6, 0, 25);
    const capsComponent = clamp((p.internacionalizacoes||0)*1.5 + (p.golosInternacional||0)*0.8, 0, 25);
    return Math.round(clamp(ovrComponent + experienceComponent + titlesComponent + capsComponent, 0, 100));
  }

  // Satisfação (separada da Moral): depende de quanto o jogador tem jogado ultimamente
  // (titularidade/minutos/convocações), temperada pela idade (jovens toleram melhor ficar de
  // fora), pela reputação do clube (num clube grande é normal rodar mais) e pela reputação do
  // próprio jogador (quem já é reconhecido exige mais protagonismo para ficar satisfeito).
  function computeSatisfactionTarget(p, team){
    const recent = p.__recentPlayed && p.__recentPlayed.length ? p.__recentPlayed : null;
    const playRate = recent ? avg(recent.map(v=>v?1:0)) : 0.5;
    const age = p.age||24;
    const ageTolerance = clamp((age-20)*2, 0, 25);
    // Correção (sistema numérico de reputação): tabela categórica (4 valores fixos) substituída
    // por interpolação contínua ancorada nos mesmos 4 valores, nos mesmos pontos de reputação
    // legados (55/70/85/95 — ver REPUTATION_POINTS, 01-nucleo.js).
    const clubRepBonus = reputationLerp(team.reputacao, [[55,0],[70,4],[85,10],[95,18]]);
    const playerRepPenalty = (p.reputacaoJogador||0)*0.3*(1-playRate);
    return clamp(40 + playRate*50 - ageTolerance + clubRepBonus - playerRepPenalty + persSatisfacaoDelta(p, team, playRate), 5, 100);
  }
  function buildDissatisfactionNewsText(p, team){
    const nome = playerLinkHtml(team.id,p);
    const templates = [
      `${nome} está cada vez mais descontente com a falta de minutos no ${teamLinkHtml(team.id)} e já terá manifestado o desagrado junto do balneário.`,
      `Fontes próximas do plantel do ${teamLinkHtml(team.id)} dão conta de crescente insatisfação de ${nome}, que sente estar a ser subaproveitado.`,
      `${nome} não esconde o descontentamento com o papel que tem tido no ${teamLinkHtml(team.id)} esta época.`,
      `A pouca utilização está a pesar no estado de espírito de ${nome}, cada vez mais incomodado no ${teamLinkHtml(team.id)}.`,
      `Há sinais de desgaste na relação entre ${nome} e o ${teamLinkHtml(team.id)} — o jogador espera mais protagonismo em pista.`,
      `${nome} terá pedido explicações à direção do ${teamLinkHtml(team.id)} sobre a falta de oportunidades.`,
    ];
    return templates[Math.floor(Math.random()*templates.length)];
  }
  // Correção (pedido do utilizador, 2026-09-17: "estão demasiados jogadores descontentes, é um
  // exagero"): um limiar fixo de 35 para todos os jogadores fazia com que muitos suplentes em
  // situação parecida (pouco tempo de jogo, mesmo alvo de satisfação) cruzassem o limiar em
  // sincronia, dando a sensação de "toda a gente descontente ao mesmo tempo". Jitter
  // determinístico por jogador (mesmo jogador ⇒ sempre o mesmo limiar, entre 28 e 40) dessincroniza
  // sem alterar o comportamento médio do sistema.
  function playerDissatisfactionThreshold(p){
    return seededRnd(makeSeededRng(`${p.id}|insatisfacao-limiar`), 28, 40);
  }
  function updateSatisfacaoAfterMatch(p, team, played){
    if(!p.__recentPlayed) p.__recentPlayed = [];
    p.__recentPlayed.push(!!played);
    if(p.__recentPlayed.length>10) p.__recentPlayed.shift();
    const target = computeSatisfactionTarget(p, team);
    const cur = p.satisfacao!=null ? p.satisfacao : 70;
    // Correção (mesmo pedido acima): taxa de convergência reduzida de 0.15 para 0.10 — a
    // satisfação muda de forma mais gradual, reduzindo o número de jogadores a cruzar o limiar
    // de descontentamento na mesma janela de jogos.
    const next = roundDecimal(clamp(cur + (target-cur)*persSatisfacaoRate(p), 0, 100));
    p.satisfacao = next;
    // Correção (pedido do utilizador, 2026-09-17: "não me interessam emails de descontentamento
    // de jogadores que não estejam na minha divisão"): mesmo filtro de relevância já usado para
    // notícias de mercado (newsIsFromUserDivision, 01-nucleo.js) — só publica quando o clube do
    // jogador descontente está na divisão atualmente disputada pelo utilizador.
    const threshold = playerDissatisfactionThreshold(p);
    if(cur >= threshold && next < threshold && newsIsFromUserDivision(team.name)){
      pushNews(state.currentDate, buildDissatisfactionNewsText(p, team), "sistema", `Descontentamento no ${team.name}`);
    }
  }
  // Insatisfação reduz o rendimento — usado junto com fitnessFactor/condicaoFactor no cálculo
  // de força da equipa.
  function satisfactionFactor(p){
    const s = p.satisfacao!=null ? p.satisfacao : 70;
    const pers = persRendimentoFactor(p);
    if(s>=70) return pers;
    return clamp(1 - (70-s)*0.006, 0.72, 1) * pers;
  }

  // ---- quick (instant) simulation for non-user matches ----
  function simulateMatchToCompletion(homeId, awayId, isPlayoff, neutralVenue, competitionId){
    const ctx = newMatchState(homeId, awayId, isPlayoff, neutralVenue, false, competitionId);
    let guard = 0;
    while(!ctx.finished && guard < 3000){ runMatchTicks(ctx); guard++; }
    const summary = buildMatchSummary(ctx);
    finalizePlayerStats(ctx, summary.mvp);
    // 2026-10-16: devolve a assistência calculada no início do jogo — finalizePlayerStats/disciplinaAposJogo
    // já descontaram um jogo à porta fechada; sem isto processMatchFinances recalculava a assistência
    // depois e a bilheteira de um jogo à porta fechada saía cheia.
    return { home: ctx.score.home, away: ctx.score.away, soWinner: ctx.soWinner, attendance: ctx.attendance };
  }

  // ---- live match for the user's own fixture (uses manager's convocatória + escalação) ----
  function startLiveMatchWithLineup(homeId, awayId, userGR, userOutfield, userBench, isPlayoff, neutralVenue, competitionId){
    const ctx = newLiveMatchState(homeId, awayId, userGR, userOutfield, userBench, isPlayoff, neutralVenue, !!state.pendingEuropaSlot, competitionId); // 2026-10-16: ver ao vivo um jogo europeu era tratado como não europeu (o Simular já passava isto)
    state.match = ctx;
    document.getElementById("pistaBancoPanel").classList.remove("hidden");
    // o jogo começa sempre em pausa — o utilizador tem de clicar "Iniciar Jogo" para arrancar.
    ctx.paused = true; ctx.pauseReason = "intervalo"; ctx.intervaloNextLabel = "Iniciar Jogo";
    updatePauseBtnLabel();
    syncTaticasUI();
    addLog(ctx, 0, "sistema", isPlayoff
      ? `Início do jogo de playoff: ${state.teams[homeId].name} recebe ${state.teams[awayId].name}.`
      : `Início do jogo (Jornada ${state.currentRound+1}): ${state.teams[homeId].name} recebe ${state.teams[awayId].name}.`);
    renderScoreboard();
    renderPistaBanco(ctx);
    clearInterval(state.timer);
    state.timer = setInterval(()=>runLiveMatchTimerTick(ctx), state.speedMs);
  }

  // Corpo do "tick" periódico do jogo ao vivo (pausa, celebração de golo, avanço do relógio,
  // modais de lesão/regresso, fim de jogo). Extraído para função própria — chamada quer pelo
  // arranque do jogo ao vivo (startLiveMatchWithLineup, acima), quer sempre que o utilizador
  // muda a velocidade a meio de um jogo (ver o listener de #speedSelect em 09-fluxo-epoca.js).
  // Correção: a mudança de velocidade recriava este intervalo com uma cópia própria e
  // incompleta desta lógica, sem a pausa de celebração de golo — assim que o utilizador mudava
  // de velocidade (o caso mais comum sendo logo no início, para "Rápida"), os golos deixavam de
  // pausar/piscar, porque a verificação do goalCelebrationUntil nunca corria nesse intervalo
  // alternativo. Centralizar aqui garante que os dois pontos de entrada nunca voltam a divergir.
  function runLiveMatchTimerTick(ctx){
    if(ctx.paused){ updatePauseBtnLabel(); return; }
    if(ctx.goalCelebrationUntil && Date.now()<ctx.goalCelebrationUntil){
      renderScoreboard();
      updatePauseBtnLabel();
      return;
    }
    // Grandes penalidades ao vivo: cada fase da execução (anúncio, resultado) fica um momento no
    // ecrã antes da seguinte, para se poder acompanhar quem bate, quem defende e o que aconteceu.
    if(ctx.period==="SO" && ctx.shootoutHoldUntil && Date.now()<ctx.shootoutHoldUntil){
      renderScoreboard();
      updatePauseBtnLabel();
      return;
    }
    runMatchTicks(ctx);
    renderScoreboard();
    renderPistaBanco(ctx);
    updatePauseBtnLabel();
    if(ctx.paused && ctx.injury){
      openInjuryModal(ctx);
    }
    if(ctx.paused && ctx.pendingReturnPrompt){
      openReturnPromptModal(ctx);
    }
    if(ctx.paused && ctx.shootoutSetupPending){
      openShootoutSetupModal(ctx);
    }
    if(ctx.finished){
      clearInterval(state.timer);
      onLiveMatchFinished(ctx);
    }
  }


  // ================= Nova interface clássica das partidas =================
  let matchUiActiveTab = "game", matchReportFilter = "all", matchEventCursor = null;
  function contrastText(hex){
    const h=String(hex||"#164fb8").replace("#",""); if(h.length!==6) return "#fff";
    const r=parseInt(h.slice(0,2),16),g=parseInt(h.slice(2,4),16),b=parseInt(h.slice(4,6),16);
    return (r*299+g*587+b*114)/1000>150?"#111":"#fff";
  }
  // Cores de equipamento em confronto: quando as cores principais de casa e fora ficam
  // demasiado parecidas para se distinguirem à vista, a equipa da casa troca para a cor
  // secundária (ou terciária, se a secundária também colidir). "redmean" é uma aproximação
  // leve e conhecida da diferença de cor tal como o olho humano a perceciona — muito melhor do
  // que uma distância RGB simples, sem precisar de converter para espaços de cor mais complexos.
  function hexToRgb(hex){
    const h=String(hex||"#000000").replace("#","");
    const full=h.length===3?h.split("").map(c=>c+c).join(""):h;
    const n=parseInt(full,16)||0;
    return { r:(n>>16)&255, g:(n>>8)&255, b:n&255 };
  }
  function colorDistance(hex1,hex2){
    const c1=hexToRgb(hex1), c2=hexToRgb(hex2);
    const rMean=(c1.r+c2.r)/2, dr=c1.r-c2.r, dg=c1.g-c2.g, db=c1.b-c2.b;
    return Math.sqrt((2+rMean/256)*dr*dr + 4*dg*dg + (2+(255-rMean)/256)*db*db);
  }
  const KIT_CLASH_THRESHOLD = 90; // abaixo disto, duas cores confundem-se com facilidade à vista
  function effectiveHomeColor(homeTeam, awayTeam){
    const homeDef=CLUB_DEFS.find(d=>d.id===homeTeam.id)||{}, awayDef=CLUB_DEFS.find(d=>d.id===awayTeam.id)||{};
    const awayColor=awayDef.primaryColor||awayTeam.color||"#164fb8";
    const primary=homeDef.primaryColor||homeTeam.color||"#164fb8";
    if(colorDistance(primary,awayColor)>=KIT_CLASH_THRESHOLD) return primary;
    const secondary=homeDef.secondaryColor;
    if(secondary && colorDistance(secondary,awayColor)>=KIT_CLASH_THRESHOLD) return secondary;
    const tertiary=homeDef.tertiaryColor;
    if(tertiary && colorDistance(tertiary,awayColor)>=KIT_CLASH_THRESHOLD) return tertiary;
    return secondary||primary; // sem alternativa livre de colisão — fica com a secundária mesmo assim
  }
  function matchEventCategory(l){
    const txt=String(l&&l.text||"").toLowerCase(),type=l&&l.type;
    if(type==="golo" || (type==="gp" && l.gpResult==="G")) return "golo";
    if(type==="gp") return l.gpResult==="D" ? "defesa" : "outro";
    if(type==="amarelo"||type==="azul"||type==="vermelho"||txt.includes("cartão")) return "disciplina";
    if(txt.includes("penálti")||txt.includes("livre direto")) return "bola-parada";
    if(txt.includes("substituição")||txt.includes("entra ")) return "substituicao";
    if(txt.includes("defesa de")||txt.includes("grande defesa")||txt.includes("trava o remate")||txt.includes("impede o golo")) return "defesa";
    if(txt.includes("remate")) return "remate";
    return "outro";
  }
  function switchMatchTab(tab){
    const previousTab = matchUiActiveTab;
    matchUiActiveTab=tab;
    document.querySelectorAll(".match-tab-btn").forEach(b=>b.classList.toggle("active",b.dataset.matchTab===tab));
    document.querySelectorAll(".match-tab-panel").forEach(p=>p.classList.toggle("active",p.dataset.matchPanel===tab));
    if(tab==="report"){ const feed=document.getElementById("feed"); if(feed) feed.scrollTop=feed.scrollHeight; }
    // Separador Táticas: o jogo fica em pausa automaticamente enquanto o utilizador está aqui
    // dentro (sem interferir se já estivesse pausado por outro motivo, como o intervalo), e
    // retoma sozinho ao sair, sem precisar de clicar em "Retomar".
    const ctx = state.match;
    if(ctx && !ctx.finished){
      if(tab==="tactics" && !ctx.paused){
        ctx.paused = true; ctx.pauseReason = "taticas"; ctx.pausedByTacticsTab = true;
        updatePauseBtnLabel();
      } else if(previousTab==="tactics" && tab!=="tactics" && ctx.pausedByTacticsTab){
        ctx.paused = false; ctx.pauseReason = null; ctx.pausedByTacticsTab = false;
        updatePauseBtnLabel();
      }
    }
  }
  function wireMatchDesk(){
    if(document.body.dataset.matchDeskWired) return; document.body.dataset.matchDeskWired="1";
    document.querySelectorAll(".match-tab-btn").forEach(b=>b.addEventListener("click",()=>switchMatchTab(b.dataset.matchTab)));
    const prev=document.getElementById("prevEventBtn"),next=document.getElementById("nextEventBtn");
    if(prev) prev.addEventListener("click",()=>navigateMatchEvent(-1)); if(next) next.addEventListener("click",()=>navigateMatchEvent(1));
    document.querySelectorAll("#reportFilters button").forEach(b=>b.addEventListener("click",()=>{matchReportFilter=b.dataset.filter;document.querySelectorAll("#reportFilters button").forEach(x=>x.classList.toggle("active",x===b));renderFeed();}));
    const gkBtn=document.getElementById("goalkeeperPullBtn");
    if(gkBtn) gkBtn.addEventListener("click", ()=>{
      const ctx=state.match; if(!ctx || !ctx.userSide) return;
      const side=ctx.userSide;
      if(ctx.semGuardaRedes && ctx.semGuardaRedes[side]) restoreGoalkeeper(ctx, side);
      else pullGoalkeeper(ctx, side);
      syncGoalkeeperPullButton(ctx);
    });
    const tmBtn=document.getElementById("timeoutBtn");
    if(tmBtn) tmBtn.addEventListener("click", ()=>{
      const ctx=state.match; if(!ctx || !ctx.userSide || timeoutUiBlockedByOtherPause(ctx)) return;
      const side=ctx.userSide;
      if(!canCallTimeout(ctx, side)) return;
      ctx.paused = true; ctx.pauseReason = "desconto"; ctx.timeoutSide = side; ctx.pausedByTacticsTab = false;
      updatePauseBtnLabel();
      openTimeoutModal(side);
    });
    const tmCancel=document.getElementById("timeoutCancelBtn");
    if(tmCancel) tmCancel.addEventListener("click", ()=>{
      const ctx=state.match;
      const modal=document.getElementById("timeoutModal"); if(modal) modal.classList.add("hidden");
      if(ctx && ctx.pauseReason==="desconto"){
        // Cancelar não gasta o desconto — se ainda estiveres no separador Táticas, volta à
        // pausa normal desse separador; caso contrário, retoma o jogo.
        if(matchUiActiveTab==="tactics"){ ctx.paused=true; ctx.pauseReason="taticas"; ctx.pausedByTacticsTab=true; }
        else { ctx.paused=false; ctx.pauseReason=null; ctx.pausedByTacticsTab=false; }
        ctx.timeoutSide=null;
        updatePauseBtnLabel();
      }
      if(ctx) syncTimeoutButton(ctx);
    });
  }
  // Modal de escolha da mensagem ao pedir um desconto de tempo (separador Táticas → botão manual).
  function openTimeoutModal(side){
    const ctx = state.match; if(!ctx) return;
    const modal = document.getElementById("timeoutModal"); if(!modal) return;
    const text = document.getElementById("timeoutText");
    if(text) text.textContent = `${teamName(ctx,side)} pede desconto de tempo (restam ${ctx.timeoutsLeft[side]} nesta parte). Escolhe a mensagem ao grupo:`;
    const descriptions = {
      motivar: "Empurra o ataque nos minutos seguintes — arriscar mais para tentar mudar o jogo.",
      serenar: "Reforça a solidez defensiva nos minutos seguintes — proteger o resultado.",
      focar:   "Reforço pequeno e equilibrado, em ataque e em defesa.",
    };
    const box = document.getElementById("timeoutMessageOptions"); if(!box) return;
    box.innerHTML = Object.keys(TIMEOUT_MESSAGES).map(key=>{
      const m = TIMEOUT_MESSAGES[key];
      return `<button class="btn timeout-msg-btn" data-key="${key}" style="display:block;width:100%;text-align:left;margin-bottom:8px;padding:10px 14px;">`
        + `<b>${escapeHtml(m.label)}</b><br><span class="helptext">${escapeHtml(descriptions[key]||"")}</span></button>`;
    }).join("");
    box.querySelectorAll(".timeout-msg-btn").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        callTimeout(ctx, side, btn.getAttribute("data-key"));
        modal.classList.add("hidden");
        syncTimeoutButton(ctx);
        renderMatchDesk(ctx);
      });
    });
    modal.classList.remove("hidden");
  }
  // Botão manual do utilizador (separador Táticas): só visível com o jogo a decorrer (não em
  // pausa), enquanto restarem descontos nesta parte e fora do prolongamento (Art.9.3).
  function syncTimeoutButton(ctx){
    const btn = document.getElementById("timeoutBtn"); if(!btn) return;
    if(!ctx || !ctx.live || !ctx.userSide || ctx.simulating){ btn.style.display="none"; return; }
    const side = ctx.userSide;
    if(!timeoutUiBlockedByOtherPause(ctx) && canCallTimeout(ctx, side)){
      btn.style.display = ""; btn.textContent = `⏱️ Pedir Desconto de Tempo (${ctx.timeoutsLeft[side]})`;
    } else {
      btn.style.display = "none";
    }
  }
  // Botão manual do utilizador (separador Táticas): só visível quando faz sentido — ou já está
  // sem guarda-redes (pode repor a qualquer momento), ou reúne agora mesmo as condições para o
  // tirar (últimos 90 segundos da parte, a perder por 1-2, sem estar já em inferioridade).
  function syncGoalkeeperPullButton(ctx){
    const btn = document.getElementById("goalkeeperPullBtn");
    if(!btn) return;
    if(!ctx || !ctx.live || !ctx.userSide || ctx.simulating){ btn.style.display="none"; return; }
    const side = ctx.userSide;
    if(ctx.semGuardaRedes && ctx.semGuardaRedes[side]){
      btn.style.display = ""; btn.textContent = "🥅 Repor guarda-redes";
    } else if(podePuxarGuardaRedes(ctx, side)){
      btn.style.display = ""; btn.textContent = "🥅 Tirar guarda-redes";
    } else {
      btn.style.display = "none";
    }
  }
  function navigateMatchEvent(step){
    const m=state.match;if(!m||!m.log.length)return;
    if(matchEventCursor==null)matchEventCursor=m.log.length-1;
    const target=clamp(matchEventCursor+step,0,m.log.length-1);
    // Correção (pedido do utilizador, 2026-09-26: "quando carrego nestas setas, deixo de
    // conseguir voltar a por em tempo real") — ◀ ▶ congelavam o relato num evento fixo (índice
    // de matchEventCursor), e nada nunca o repunha a null: mesmo navegando de volta até ao
    // último evento, o relato ficava preso nesse número, cada vez mais desatualizado à medida
    // que o jogo continuava a decorrer e novos eventos eram acrescentados ao fim do registo.
    // Ao chegar ao evento mais recente disponível, volta ao acompanhamento em tempo real
    // (matchEventCursor=null), para os golos/cartões seguintes voltarem a aparecer sozinhos.
    if(target>=m.log.length-1){ matchEventCursor=null; renderLatestMatchEvent(m.log[m.log.length-1]); return; }
    matchEventCursor=target; renderLatestMatchEvent(m.log[matchEventCursor]);
  }
  function plainEventText(text){ return String(text||"").replace(/<[^>]+>/g,"").replace(/^[^!]*!\s*/,"").trim(); }
  function eventTeamFromText(ev){
    if(!state.match || !ev) return null;
    const txt=String(ev.text||"").toLowerCase();
    const home=state.teams[state.match.homeId], away=state.teams[state.match.awayId];
    const aliases=t=>[t.name,t.name.replace(/^SL\s+/i,""),t.name.replace(/^AD\s+/i,""),t.name.replace(/^UD\s+/i,"")].map(x=>x.toLowerCase());
    if(aliases(home).some(n=>n&&txt.includes(n))) return home;
    if(aliases(away).some(n=>n&&txt.includes(n))) return away;
    return null;
  }
  // Cor efetiva de uma equipa num evento do relato: para a equipa da casa, a mesma lógica
  // usada no marcador (effectiveHomeColor) — se a cor principal colidir visualmente com a do
  // adversário, recua para a secundária/terciária; para a equipa de fora, mantém sempre a
  // principal (só a casa muda de cor por colisão, tal como já acontecia no marcador).
  function effectiveColorForEventTeam(team){
    if(!state.match || !team) return null;
    const home=state.teams[state.match.homeId], away=state.teams[state.match.awayId];
    if(team.id===state.match.homeId) return effectiveHomeColor(home,away);
    const def=CLUB_DEFS.find(d=>d.id===team.id)||{};
    return def.primaryColor||team.color||"#164fb8";
  }
  function applyEventTeamColours(card,team,isGoal){
    if(!card) return;
    if(!team){
      card.style.removeProperty("--event-primary"); card.style.removeProperty("--event-secondary");
      card.style.removeProperty("background"); card.style.removeProperty("color"); card.style.removeProperty("border-color");
      card.classList.remove("goal-flash");
      return;
    }
    const def=CLUB_DEFS.find(d=>d.id===team.id)||{};
    // Correção: usava sempre a cor principal "crua", mesmo quando a equipa da casa estava a
    // jogar com a cor secundária/terciária por colisão com o adversário — o cartão do relato
    // ficava inconsistente com o que o marcador mostrava. Passa a usar a mesma cor efetiva.
    const primary=effectiveColorForEventTeam(team)||def.primaryColor||team.color||"#164fb8";
    // Correção: o texto usava sempre a cor secundária do clube, mesmo quando essa secundária
    // era exatamente a cor efetiva escolhida para o fundo (ex.: CD Paço de Arcos, cuja cor
    // efetiva recuou para a secundária por colidir com o adversário) — fundo e letra ficavam
    // iguais, texto invisível. Usa sempre contraste automático (preto/branco conforme o fundo),
    // a mesma lógica já usada no marcador, que nunca pode dar fundo=texto.
    const secondary=clubTextColor(team,primary);
    card.style.setProperty("--event-primary",primary);
    card.style.setProperty("--event-secondary",secondary);
    card.style.background=primary;
    card.style.color=secondary;
    card.style.borderColor=secondary;
    card.classList.toggle("goal-flash",!!isGoal);
  }
  function resetGoalFlash(card,key){
    if(!card || card.dataset.goalKey===String(key)) return;
    card.dataset.goalKey=String(key);
    card.classList.remove("goal-flash");
    void card.offsetWidth;
    card.classList.add("goal-flash");
  }
  function renderLatestMatchEvent(ev){
    const card=document.getElementById("latestEventCard"),title=document.getElementById("latestEventTitle"),text=document.getElementById("latestEventText"); if(!card||!title||!text)return;
    if(!ev){title.textContent="PARTIDA POR INICIAR";text.textContent="O relato principal será apresentado aqui.";applyEventTeamColours(card,null,false);return;}
    const isGP = ev.type==="gp", gpGoal = isGP && ev.gpResult==="G";
    const eventTeam=(isGP && !gpGoal) ? null : eventTeamFromText(ev), isGoal=ev.type==="golo" || gpGoal;
    let cls="event-neutral",label="RELATO";
    if(isGP){
      cls = gpGoal ? "event-team" : "event-neutral";
      label = ev.gpResult==="G" ? "GOLO"+(eventTeam?" "+eventTeam.name.toUpperCase():"")
        : ev.gpResult==="D" ? "DEFESA DO GUARDA-REDES!" : ev.gpResult==="P" ? "POSTE!" : ev.gpResult==="F" ? "AO LADO!" : "GRANDE PENALIDADE";
    }
    else if(isGoal){ cls="event-team"; label="GOLO"+(eventTeam?" "+eventTeam.name.toUpperCase():""); }
    else if(ev.type==="azul"){cls="event-azul";label="CARTÃO AZUL";}
    else if(ev.type==="amarelo"){cls="event-amarelo";label="CARTÃO AMARELO";}
    else if(ev.type==="vermelho"){cls="event-opponent-goal";label="CARTÃO VERMELHO";}
    else if(String(ev.text).toLowerCase().includes("penálti")||String(ev.text).toLowerCase().includes("livre direto")){cls="event-setpiece";label="BOLA PARADA";}
    else if(eventTeam){cls="event-team";label=eventTeam.name.toUpperCase();}
    card.className="latest-event "+cls;
    applyEventTeamColours(card,eventTeam,isGoal);
    if(isGoal) resetGoalFlash(card,state.match&&state.match.goalCelebrationKey||state.match&&state.match.log.indexOf(ev)||0);
    title.textContent=label; text.textContent=plainEventText(ev.text);
    const last=document.getElementById("lastCommentaryText");
    const lastLine = last ? last.closest(".last-commentary") : null;
    if(last){
      last.textContent=plainEventText(ev.text);
      // Pedido explícito: a linha de comentários de baixo tem de acompanhar a mesma cor da
      // equipa em causa (já efetiva, ajustada por colisão) — não ficar sempre neutra. Aplica-se
      // à linha inteira (não só ao texto do relato), para ficar consistente com o cartão maior.
      if(eventTeam && lastLine){
        const color = effectiveColorForEventTeam(eventTeam);
        // Mesma correção do cartão maior: contraste automático (ou a cor de texto fixa do
        // clube, quando definida — ver clubTextColor), nunca a secundária "crua" do clube (que
        // podia coincidir com a própria cor de fundo escolhida por colisão).
        const secondary=clubTextColor(eventTeam,color);
        lastLine.style.background = color;
        lastLine.style.color = secondary;
        last.style.color = secondary;
      } else if(lastLine){
        lastLine.style.removeProperty("background"); lastLine.style.removeProperty("color");
        last.style.removeProperty("color");
      }
    }
  }
  function computeRecentDominance(ctx){
    const windowStart=Math.max(0,(ctx.absoluteClock||0)-300),score={home:0,away:0};
    (ctx.eventMetrics||[]).filter(e=>e.t>=windowStart).forEach(e=>{score[e.side]=(score[e.side]||0)+e.weight;});
    const total=score.home+score.away;if(!total)return{home:50,away:50};const home=Math.round(score.home/total*100);return{home,away:100-home};
  }
  function recordMatchMetric(ctx,side,kind,weight){ if(!ctx.eventMetrics)ctx.eventMetrics=[];ctx.eventMetrics.push({t:ctx.absoluteClock||0,side,kind,weight});if(ctx.eventMetrics.length>300)ctx.eventMetrics.shift(); }
  function shotsOnTargetFor(ctx,side){ return (ctx.goalsFromShots[side]||0)+(ctx.savesBySide?ctx.savesBySide[side]||0:0)+(ctx.disallowedGoals?ctx.disallowedGoals[side]||0:0); }
  function renderMatchTeamStats(ctx){
    const box=document.getElementById("matchTeamStats");if(!box||!ctx)return;
    const cards=s=>(ctx.cartoes[s]||[]).length, setp=s=>(ctx.setPieces&&ctx.setPieces[s])||{penalti:0,livredireto:0};
    const rows=[
      ["Remates",ctx.shots.home||0,ctx.shots.away||0],["Remates enquadrados",shotsOnTargetFor(ctx,"home"),shotsOnTargetFor(ctx,"away")],
      ["Livres diretos",setp("home").livredireto||0,setp("away").livredireto||0],["Penáltis",setp("home").penalti||0,setp("away").penalti||0],
      ["Golos",ctx.score.home,ctx.score.away],["Recargas",`${ctx.reboundStats?.home?.goals||0}/${ctx.reboundStats?.home?.attempts||0}`,`${ctx.reboundStats?.away?.goals||0}/${ctx.reboundStats?.away?.attempts||0}`],["Faltas",ctx.faltas.home,ctx.faltas.away],["Cartões",cards("home"),cards("away")],
      ["Eficácia ofensiva",(ctx.shots.home?Math.round(ctx.score.home/ctx.shots.home*100):0)+"%",(ctx.shots.away?Math.round(ctx.score.away/ctx.shots.away*100):0)+"%"],
      ["Eficácia defensiva",(ctx.shots.away?Math.round((ctx.shots.away-ctx.score.away)/ctx.shots.away*100):100)+"%",(ctx.shots.home?Math.round((ctx.shots.home-ctx.score.home)/ctx.shots.home*100):100)+"%"]];
    box.innerHTML=`<table class="classic-match-stats"><thead><tr><th>Indicador</th><th>${escapeHtml(state.teams[ctx.homeId].name)}</th><th>${escapeHtml(state.teams[ctx.awayId].name)}</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join("")}</tbody></table>`;
  }
  // Painel das grandes penalidades: uma linha por equipa com uma bolinha por execução (verde =
  // golo, vermelha = defesa/poste/fora, cinzenta = por executar, a piscar = em curso), mais o
  // duelo marcador vs guarda-redes da execução atual e o resultado da última.
  function renderShootoutPanel(ctx){
    const panel = document.getElementById("shootoutPanel");
    const stage = document.querySelector(".match-photo-stage");
    const active = !!(ctx && ctx.period==="SO" && ctx.shootout && ctx.shootout.kicks);
    if(stage) stage.classList.toggle("so-mode", active);
    if(!panel) return;
    panel.classList.toggle("hidden", !active);
    if(!active) return;
    const so = ctx.shootout;
    const cols = Math.max(SHOOTOUT_REGULAR_KICKS, so.taken.home+1, so.taken.away+1);
    const row = side => {
      const team = state.teams[side==="home"?ctx.homeId:ctx.awayId];
      let pips = "";
      for(let i=0;i<cols;i++){
        const k = so.kicks[side][i];
        const inCourse = !k && so.current && so.current.side===side && i===so.taken[side];
        const cls = k ? (k.r==="G" ? "so-goal" : "so-miss") : inCourse ? "so-live" : "so-pending";
        const sym = k ? (k.r==="G" ? "●" : k.r==="D" ? "🧤" : "✕") : "○";
        pips += `<span class="so-pip ${cls}${i>=SHOOTOUT_REGULAR_KICKS?' so-sudden':''}" title="${k?escapeHtml(k.name):''}">${sym}</span>`;
      }
      const turnCls = so.turn===side && !so.pendingDecision ? " so-turn" : "";
      return `<div class="so-row${turnCls}"><span class="so-team">${escapeHtml(team.name.toUpperCase())}</span><span class="so-pips">${pips}</span><b class="so-total">${so.goals[side]}</b></div>`;
    };
    document.getElementById("soRows").innerHTML = row("home") + row("away");
    document.getElementById("soRoundLabel").textContent = so.phase==="suddenDeath" ? "· SÉRIE ADICIONAL (morte súbita)" : `· penálti ${Math.min(SHOOTOUT_REGULAR_KICKS, so.taken[so.turn] + 1)}/${SHOOTOUT_REGULAR_KICKS}`;
    const duel = document.getElementById("soDuel");
    let html = "";
    const cur = so.current, last = so.last;
    if(cur){
      html = `<div class="so-duel-line">A bater: <b>${escapeHtml(cur.shooter?cur.shooter.name:"—")}</b> <small>(${escapeHtml(teamName(ctx,cur.side))}${cur.shooter?` · OVR ${overall(cur.shooter)}`:''})</small></div>
              <div class="so-duel-line">Na baliza: <b>${escapeHtml(cur.gk?cur.gk.name:"—")}</b> <small>(${escapeHtml(teamName(ctx,shootoutOther(cur.side)))})</small></div>`;
    } else if(last){
      const txt = last.outcome==="G" ? `GOLO de ${escapeHtml(last.shooter?last.shooter.name:"jogador")}!`
        : last.outcome==="D" ? `DEFESA de ${escapeHtml(last.gk?last.gk.name:"guarda-redes")}!`
        : last.outcome==="P" ? "POSTE!" : "AO LADO!";
      html = `<div class="so-result ${last.outcome==="G"?"so-result-goal":"so-result-miss"}">${txt}</div>`;
    }
    duel.innerHTML = html;
  }
  function renderMatchDesk(ctx){
    wireMatchDesk(); if(!ctx)return;
    renderShootoutPanel(ctx);
    syncGoalkeeperPullButton(ctx);
    syncTimeoutButton(ctx);
    const home=state.teams[ctx.homeId],away=state.teams[ctx.awayId],hp=document.getElementById("homeTeamPanel"),ap=document.getElementById("awayTeamPanel");
    const awayColor=(CLUB_DEFS.find(d=>d.id===away.id)||{}).primaryColor||away.color||"#154bba";
    const homeColor=effectiveHomeColor(home,away);
    if(hp){hp.style.background=homeColor;hp.style.color=clubTextColor(home,homeColor);}if(ap){ap.style.background=awayColor;ap.style.color=clubTextColor(away,awayColor);}
    const elapsed=(ctx.period===2?ctx.periodLength:0)+(ctx.clock||0),minute=document.getElementById("matchMinuteBox");if(minute)minute.textContent=String(Math.floor(elapsed/60)).padStart(2,"0");
    const remaining=Math.max(0,Math.ceil(ctx.posse.clock)),bar=document.getElementById("posseBar"),warning=document.getElementById("possessionWarning");
    if(bar){
      bar.classList.toggle("warning",remaining>=6&&remaining<=14);
      bar.classList.toggle("danger",remaining<=5);
      // Pedido explícito: a barra de posse tinha sempre a mesma cor fixa (azul), nunca a da
      // equipa com a posse — passa a usar a mesma cor efetiva já usada no marcador (respeita a
      // troca por colisão de cores com equipamento secundário/terciário). Os estados de aviso
      // (posse a terminar) continuam a sobrepor-se via classe CSS, por isso só aplica a cor da
      // equipa fora desses estados, para não escurecer o aviso.
      if(remaining>14){
        bar.style.backgroundColor = ctx.posse.team==="home" ? homeColor : awayColor;
      } else {
        bar.style.removeProperty("background-color");
      }
    }
    if(warning)warning.textContent=remaining<=5?"⚠ POSSE A TERMINAR":"";
    const dom=computeRecentDominance(ctx),hb=document.getElementById("domHomeBar"),ab=document.getElementById("domAwayBar");if(hb)hb.style.width=dom.home+"%";if(ab)ab.style.width=dom.away+"%";
    const hl=document.getElementById("domHomeLabel"),al=document.getElementById("domAwayLabel");if(hl)hl.textContent=home.name.toUpperCase()+" "+dom.home+"%";if(al)al.textContent=away.name.toUpperCase()+" "+dom.away+"%";
    const latest=matchEventCursor==null?ctx.log[ctx.log.length-1]:ctx.log[matchEventCursor];renderLatestMatchEvent(latest);renderMatchTeamStats(ctx);renderKeyEvents(ctx);
    const comp=document.getElementById("matchCompetition"),round=document.getElementById("matchRound"),venue=document.getElementById("matchVenue"),city=document.getElementById("matchCity"),att=document.getElementById("matchAttendance");
    if(comp)comp.textContent=competitionLabel(state.userCompetitionId);if(round)round.textContent="Jornada "+(state.currentRound+1);if(venue)venue.textContent="Pavilhão do "+home.name;if(city)city.textContent="Portugal";
    // Correção (pedido do utilizador, 2026-09-17: assistência fixa, não a mudar tick a tick):
    // ctx.attendance é calculado uma única vez em newMatchState, ao início do jogo, e reutilizado
    // aqui e no fecho de contas (processMatchFinances). O recálculo fica só como rede de
    // segurança para um jogo carregado de um save anterior a esta correção, sem ctx.attendance.
    if(att){initClubFinance(home);const estimate=ctx.attendance!=null?ctx.attendance:matchAttendance(home,away,{playoff:ctx.isPlayoff,europa:ctx.isEuropa});att.textContent="Assistência: "+estimate.toLocaleString("pt-PT")+(ctx.viagem&&ctx.viagem.tier>0?" · "+viagemTexto(ctx.viagem):"")+(ctx.tv?" · 📺 "+ctx.tv.label:"");}
  }

  // ---- Injury modal ----
  const injuryModal = document.getElementById("injuryModal");
  const returnPromptModal = document.getElementById("returnPromptModal");
  function openInjuryModal(ctx){
    const { side, player } = ctx.injury;
    document.getElementById("injuryText").textContent =
      `${player.name} (${teamName(ctx,side)}) sofreu uma lesão e tem de sair de imediato. Escolhe quem entra.`;
    const bench = (ctx.bench[side]||[]).filter(jogadorDisponivelNestaPartida);
    const samePos = bench.filter(p=>p.pos===player.pos);
    const options = samePos.length ? samePos : bench;
    const box = document.getElementById("injurySubOptions");
    if(options.length===0){
      box.innerHTML = `<p style="color:var(--texto-mute);font-size:13px;">Não há suplentes disponíveis. A equipa vai continuar em inferioridade.</p>
        <div class="modal-actions"><button class="btn btn-primary" id="injuryContinueBtn">Continuar</button></div>`;
      document.getElementById("injuryContinueBtn").addEventListener("click", () => {
        removeInjuredWithoutSub(ctx, side, player);
        addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} continua em inferioridade — sem suplentes disponíveis para substituir ${player.name}, que sai lesionado.`);
        ctx.paused = false; ctx.injury = null;
        injuryModal.classList.add("hidden");
        renderScoreboard(); renderPistaBanco(ctx);
      });
    } else {
      box.innerHTML = options.map(p=>`<button class="injury-sub-btn" data-id="${p.id}"><b>${playerNameHtml(p)}</b> · OVR ${overall(p)} · <span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${p.pos}</span></button>`).join("");
      box.querySelectorAll(".injury-sub-btn").forEach(btn => {
        btn.addEventListener("click", () => {
          const inPlayer = options.find(p=>p.id===btn.getAttribute("data-id"));
          performSub(ctx, side, player, inPlayer, "lesao");
          ctx.paused = false; ctx.injury = null;
          injuryModal.classList.add("hidden");
          renderScoreboard(); renderPistaBanco(ctx);
        });
      });
    }
    injuryModal.classList.remove("hidden");
  }

  function openReturnPromptModal(ctx){
    const { side, pos, candidates, selfOption, filling } = ctx.pendingReturnPrompt;
    const options = selfOption ? candidates.concat([selfOption]) : candidates;
    document.getElementById("returnPromptText").textContent = filling
      ? (pos==="GR"
          ? `O guarda-redes de ${teamName(ctx,side)} foi penalizado e tem de sair já. Escolhe o guarda-redes que entra.`
          : `Outro cartão azul obriga ${teamName(ctx,side)} a chamar já um suplente para manter o mínimo de 3 jogadores de campo em pista. Escolhe quem entra.`)
      : `Fim da inferioridade numérica de ${teamName(ctx,side)}.${selfOption ? ` ${selfOption.name} já pode voltar a jogar, mas não é escolhido automaticamente.` : ''} Escolhe quem entra em pista.`;
    const box = document.getElementById("returnPromptOptions");
    if(options.length===0){
      box.innerHTML = `<p style="color:var(--texto-mute);font-size:13px;">Não há opções disponíveis. A equipa continua reduzida.</p>
        <div class="modal-actions"><button class="btn btn-primary" id="returnPromptContinueBtn">Continuar</button></div>`;
      document.getElementById("returnPromptContinueBtn").addEventListener("click", () => {
        addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} continua reduzida — sem opções disponíveis para entrar em pista.`);
        ctx.paused = false; ctx.pendingReturnPrompt = null;
        returnPromptModal.classList.add("hidden");
      });
    } else {
      box.innerHTML = options.map(p=>`<button class="injury-sub-btn" data-id="${p.id}"><b>${playerNameHtml(p)}</b> · OVR ${overall(p)} · ${p.__fitness!=null?Math.round(p.__fitness):100}% forma</button>`).join("");
      box.querySelectorAll(".injury-sub-btn").forEach(btn => {
        btn.addEventListener("click", () => {
          const chosen = options.find(p=>p.id===btn.getAttribute("data-id"));
          const bench = ctx.bench[side];
          if(chosen !== selfOption){
            const bIdx = bench.indexOf(chosen);
            if(bIdx>=0) bench.splice(bIdx,1);
            // o jogador do cartão azul que não foi escolhido agora não fica perdido — passa a
            // suplente normal, disponível para entrar mais tarde.
            if(selfOption) bench.push(selfOption);
          }
          insertPlayerToRink(ctx, side, chosen, pos);
          ctx.playedSet[side].add(chosen.id);
          chosen.__matchGoals = chosen.__matchGoals||0; chosen.__matchAssists = chosen.__matchAssists||0; chosen.__matchGolosSofridos = chosen.__matchGolosSofridos||0;
          addLog(ctx, ctx.clock, "sistema", `${teamName(ctx,side)} recompõe a equipa: entra ${chosen.name}.`);
          ctx.paused = false; ctx.pendingReturnPrompt = null;
          returnPromptModal.classList.add("hidden");
          renderScoreboard(); renderPistaBanco(ctx);
        });
      });
    }
    returnPromptModal.classList.remove("hidden");
  }

  // ---- Manual in-game substitution: bench player enters, lowest-fitness same-position starter rests ----
  // ---- Manual in-game substitution: manager chooses who comes in AND who goes out ----
  const subChoiceModal = document.getElementById("subChoiceModal");
  function openSubChoiceModal(ctx, side, inPlayer){
    const lu = ctx.lineups[side];
    const candidates = inPlayer.pos==="GR" ? [lu.gr].filter(Boolean) : lu.outfield.slice();
    if(candidates.length===0) return;
    document.getElementById("subChoiceText").textContent = `${inPlayer.name} vai entrar. Escolhe quem sai de pista.`;
    document.getElementById("subChoiceOptions").innerHTML = candidates.map(p => {
      const fit = p.__fitness!=null ? Math.round(p.__fitness) : 100;
      return `<button class="injury-sub-btn" data-id="${p.id}"><b>${playerNameHtml(p)}</b> · ${fit}% forma · OVR ${overall(p)}</button>`;
    }).join("");
    document.getElementById("subChoiceOptions").querySelectorAll(".injury-sub-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const outPlayer = candidates.find(p=>p.id===btn.getAttribute("data-id"));
        performSub(ctx, side, outPlayer, inPlayer, "manual");
        subChoiceModal.classList.add("hidden");
        renderScoreboard(); renderPistaBanco(ctx);
      });
    });
    subChoiceModal.classList.remove("hidden");
  }
  document.getElementById("subChoiceCancelBtn").addEventListener("click", () => subChoiceModal.classList.add("hidden"));

  // ---- Pause / resume ----
  function updatePauseBtnLabel(){
    const ctx = state.match;
    const btn = document.getElementById("pauseBtn");
    if(!ctx){ btn.textContent = "⏸ Pausar"; btn.classList.remove("btn-primary"); return; }
    // Fim do jogo ao vivo: o ecrã da partida fica com o resultado final e este botão passa a "Continuar"
    // (sai da partida; o botão principal da barra lateral não aparece neste ecrã).
    if(ctx.finished){
      if(state.pendingPostMatchCtx === ctx){ btn.textContent = "▶ Continuar"; btn.classList.add("btn-primary"); }
      else { btn.textContent = "⏸ Pausar"; btn.classList.remove("btn-primary"); }
      return;
    }
    if(ctx.paused && ctx.pauseReason==="intervalo"){
      btn.textContent = "▶ " + (ctx.intervaloNextLabel || "Recomeçar");
      btn.classList.add("btn-primary");
    } else if(ctx.paused && ctx.pauseReason==="desconto"){
      btn.textContent = "▶ Retomar (Desconto de Tempo)";
      btn.classList.add("btn-primary");
    } else if(ctx.paused && ctx.pauseReason==="desconto-adversario"){
      // Pedido do utilizador (2026-09-16): o desconto de tempo pedido pelo ADVERSÁRIO também para
      // o jogo — o rótulo convida a aproveitar a paragem para mexer na tática (separador Táticas)
      // antes de retomar, tal como aconteceria numa paragem real.
      btn.textContent = "▶ Retomar (aproveita para ajustar a equipa)";
      btn.classList.add("btn-primary");
    } else {
      btn.textContent = ctx.paused ? "▶ Retomar" : "⏸ Pausar";
      btn.classList.remove("btn-primary");
    }
  }
  document.getElementById("pauseBtn").addEventListener("click", () => {
    const ctx = state.match;
    if(ctx && ctx.finished && state.pendingPostMatchCtx === ctx){ concluirPartidaTerminada(); return; }   // "▶ Continuar" no fim do jogo
    if(!ctx || ctx.finished || ctx.injury || ctx.shootoutSetupPending) return; // can't manually toggle during a forced pause (lesão ou escolha de grandes penalidades)
    const timeoutModalEl = document.getElementById("timeoutModal");
    if(timeoutModalEl && !timeoutModalEl.classList.contains("hidden")) return; // escolhe primeiro a mensagem
    ctx.paused = !ctx.paused;
    if(!ctx.paused){ ctx.pauseReason = null; ctx.pausedByTacticsTab = false; ctx.timeoutSide = null; }
    else if(!ctx.pauseReason) ctx.pauseReason = "manual";
    updatePauseBtnLabel();
  });

  function goalDots(n){ return Array.from({length:n||0}).map(()=>'<span class="live-dot live-dot-goal" title="Golo marcado"></span>').join(""); }
  function concededDots(n){ return Array.from({length:n||0}).map(()=>'<span class="live-dot live-dot-conceded" title="Golo sofrido"></span>').join(""); }
  function assistTags(n){ return Array.from({length:n||0}).map(()=>'<span class="live-tag-assist">Ass.</span>').join(""); }
  function cardIcons(cardsArr){ return (cardsArr||[]).map(c=>c==="amarelo"?"🟨":c==="azul"?"🟦":"🟥").join(""); }
  function liveRatingOf(p, ctx, side){ return (ctx && side ? matchRating(ctx,side,p) : clamp(5.8+(p.__matchRatingDelta||0),1,10)).toFixed(1); }
  function livePlayerRow(ctx, side, p, isBench){
    const fit = p.__fitness!=null ? Math.round(p.__fitness) : 100;
    const marks = [];
    if(p.__matchGoals) marks.push(goalDots(p.__matchGoals));
    if(p.__matchAssists) marks.push(assistTags(p.__matchAssists));
    if(p.pos==="GR" && p.__matchGolosSofridos) marks.push(concededDots(p.__matchGolosSofridos));
    const cardsTxt = cardIcons(p.__cardsThisMatch);
    // Correção (Marco K, pedido do utilizador: "quando há lesões durante a partida, se forem
    // graves, o jogador não pode voltar à pista"): um jogador com lesão grave nesta partida
    // continua fisicamente "no banco" (para as estatísticas/UI), mas nunca é candidato a entrar —
    // o botão "▲ Entra" é substituído por uma etiqueta, mesmo padrão visual do "PROV." acima.
    const lesionado = !!p.__lesaoGraveNestaPartida;
    const canSub = isBench && side===ctx.userSide && !ctx.finished && !lesionado;
    return `<div class="live-player-row">
      <span class="pos-badge ${p.pos==='GR'?'gr':'j'}">${linhaAbbrev(p)}</span>
      <span class="live-player-name">#${p.num||0} ${playerNameHtml(p)}${p.__provisional?' <span class="provisional-tag">PROV.</span>':''}</span>
      <span class="ovr-mini" title="Overall">OVR ${overall(p)}</span>
      <span class="live-marks">${marks.join("")}</span>
      ${cardsTxt ? `<span class="live-cards">${cardsTxt}</span>` : ''}
      <span class="fit-label">${fit}%</span>
      <span class="live-rating">${liveRatingOf(p,ctx,side)}</span>
      ${canSub ? `<button class="sub-btn" data-id="${p.id}">▲ Entra</button>` : (isBench && lesionado ? `<span class="provisional-tag" title="Lesão grave nesta partida — não pode voltar a jogar">🚑 Fora do jogo</span>` : '')}
    </div>`;
  }
  function renderTeamLivePanel(ctx, side, pistaElId, bancoElId){
    const lu = ctx.lineups[side];
    const onRink = [lu.gr].concat(lu.outfield).filter(Boolean);
    document.getElementById(pistaElId).innerHTML = onRink.map(p=>livePlayerRow(ctx, side, p, false)).join("") || '<div class="feed-empty">—</div>';
    const bench = ctx.bench[side] || [];
    document.getElementById(bancoElId).innerHTML = bench.length
      ? bench.map(p=>livePlayerRow(ctx, side, p, true)).join("")
      : '<div style="font-size:12px;color:var(--texto-mute);">Sem suplentes no banco.</div>';
    if(side===ctx.userSide){
      document.getElementById(bancoElId).querySelectorAll(".sub-btn").forEach(btn=>{
        btn.addEventListener("click", () => {
          const inPlayer = bench.find(p=>p.id===btn.getAttribute("data-id"));
          if(inPlayer) openSubChoiceModal(ctx, side, inPlayer);
        });
      });
    }
  }
  function renderPistaBanco(ctx){
    if(!ctx || !ctx.live) return;
    const side = ctx.userSide;
    if(!side) return;
    // A lista da esquerda mostra sempre a equipa da CASA e a da direita a de FORA — não "a
    // minha equipa" vs. "o adversário" — para o lado corresponder sempre ao que se vê num
    // marcador/pista reais, quer jogues em casa quer jogues fora. renderTeamLivePanel já sabe
    // internamente qual dos dois lados é o do utilizador (compara com ctx.userSide), por isso
    // os botões de substituição continuam a aparecer no sítio certo, seja ele qual for.
    document.getElementById("liveMyTeamTitle").textContent = teamName(ctx, "home");
    document.getElementById("liveOppTeamTitle").textContent = teamName(ctx, "away");
    renderTeamLivePanel(ctx, "home", "pistaListMine", "bancoListMine");
    renderTeamLivePanel(ctx, "away", "pistaListOpp", "bancoListOpp");
    // Separador Táticas: pedido explícito — só a equipa do próprio utilizador (não o
    // adversário), ao contrário do painel de "Jogadores" acima, que mostra sempre casa/fora.
    const t2 = document.getElementById("liveMyTeamTitle2");
    if(t2){
      t2.textContent = teamName(ctx, side);
      renderTeamLivePanel(ctx, side, "pistaListMine2", "bancoListMine2");
    }
    renderMatchDesk(ctx);
  }

  function cleanupPendingProvisional(){
    if(!state.pendingProvisional) return;
    removeProvisionalPlayers(myTeam(), state.pendingProvisional.mine);
    const oppId = state.pendingFixture ? (state.pendingFixture.home===state.userTeamId?state.pendingFixture.away:state.pendingFixture.home) : null;
    if(oppId) removeProvisionalPlayers(state.teams[oppId], state.pendingProvisional.opp);
    state.pendingProvisional = null;
  }

  function buildMatchSummary(ctx){
    const allPlayers = [];
    ["home","away"].forEach(side=>{
      const team = state.teams[side==="home"?ctx.homeId:ctx.awayId];
      const playedIds = ctx.playedSet[side];
      team.players.forEach(p=>{
        if(playedIds.has(p.id)){
          allPlayers.push({
            id:p.id, side, name:p.name, pos:p.pos, num:p.num,
            goals:p.__matchGoals||0, assists:p.__matchAssists||0,
            golosSofridos:p.__matchGolosSofridos||0,
            cards:(p.__cardsThisMatch||[]).slice(),
            rating: matchRating(ctx,side,p),
            finalFitness: p.__fitness!=null?p.__fitness:100,
            provisional: !!p.__provisional,
          });
        }
      });
    });
    const margin = Math.abs(ctx.score.home-ctx.score.away);
    const winnerSide = ctx.score.home>ctx.score.away ? "home" : ctx.score.away>ctx.score.home ? "away" : null;
    const mvpPool = winnerSide && margin>=2 ? allPlayers.filter(p=>p.side===winnerSide) : allPlayers;
    const mvp = mvpPool.slice().sort((a,b)=>
      b.rating-a.rating || b.goals-a.goals || b.assists-a.assists || b.finalFitness-a.finalFitness || a.name.localeCompare(b.name,'pt')
    )[0] || null;
    const gks = allPlayers.filter(p=>p.pos==="GR");
    return {
      homeId: ctx.homeId, awayId: ctx.awayId,
      homeScore: ctx.score.home, awayScore: ctx.score.away, soWinner: ctx.soWinner,
      isPlayoff: ctx.isPlayoff,
      faltas: { home:ctx.faltas.home, away:ctx.faltas.away },
      cartoes: { home:ctx.cartoes.home.slice(), away:ctx.cartoes.away.slice() },
      shots: { home:ctx.shots.home||0, away:ctx.shots.away||0 },
      possession: { home:ctx.possessionSeconds.home||0, away:ctx.possessionSeconds.away||0 },
      injuries: ctx.injuriesThisMatch.slice(),
      suspensions: allPlayers.filter(p=>p.cards.includes("vermelho") && (ctx.vermelhosDiretos||[]).some(v=>v.playerId===p.id)),
      players: allPlayers,
      gks,
      mvp,
      logHighlights: ctx.log.filter(l=>["golo","azul","vermelho"].includes(l.type)),
    };
  }

  function onLiveMatchFinished(ctx){
    const summary = buildMatchSummary(ctx);
    finalizePlayerStats(ctx, summary.mvp);
    state.pendingPostMatchCtx = ctx;
    // 2026-10-12 (pedido do utilizador): sem o resumo do jogo no fim — o resumo lê-se no relatório
    // pós-jogo do treinador adjunto (generatePostGameReport). Simulado: fecha logo e volta ao menu.
    // Ao vivo: o ecrã do jogo fica com o resultado final e é o botão "▶ Continuar" que sai da
    // partida e volta ao menu (ver concluirPartidaTerminada).
    // 2026-10-15 (pedido do utilizador): ao SIMULAR, aparece o ecrã com o resultado e as principais
    // ocorrências; só ao carregar em "Continuar" sai dele (concluirPartidaTerminada → E-mail).
    if(ctx.simulating){ showPostMatchModal(summary); return; }
    const st = document.getElementById("matchStatus"); if(st) st.textContent = "Fim de jogo";
    const cb = document.getElementById("continuarBtn");
    if(cb){ cb.disabled = false; }
    if(typeof updateContinuarBtnLabel === "function") updateContinuarBtnLabel();
    updatePauseBtnLabel();
  }
  function concluirPartidaTerminada(){
    const pm = document.getElementById("postMatchModal"); if(pm) pm.classList.add("hidden");
    const ctx = state.pendingPostMatchCtx;
    state.pendingPostMatchCtx = null;
    if(ctx) finalizeMatchBookkeeping(ctx);
    // Sai sempre para o E-mail (view "noticias"), onde aparece o resumo dos resultados da jornada
    // e o relatório do adjunto — tanto no jogo ao vivo como no simulado (depois do ecrã de resultado).
    if(ctx) setView("noticias");
    updatePauseBtnLabel();
  }

  function fmtClockMMSS(sec){ const m=Math.floor(sec/60), s=Math.round(sec%60); return `${m}:${String(s).padStart(2,"0")}`; }

  function showPostMatchModal(summary){
    const homeT = state.teams[summary.homeId], awayT = state.teams[summary.awayId];
    const totalPosse = (summary.possession.home||0) + (summary.possession.away||0);
    const possHomePct = totalPosse>0 ? Math.round(summary.possession.home/totalPosse*100) : 50;
    const cardCount = (arr, type) => arr.filter(c=>c===type).length;
    const scorers = summary.players.filter(p=>p.goals>0).map(p=>`${playerNameHtml(p)} (${state.teams[p.side==="home"?summary.homeId:summary.awayId].name}) ${'●'.repeat(p.goals)}`).join("<br>") || "—";
    const assisters = summary.players.filter(p=>p.assists>0).map(p=>`${playerNameHtml(p)} (${state.teams[p.side==="home"?summary.homeId:summary.awayId].name}) x${p.assists}`).join("<br>") || "—";
    const cardsTxt = summary.players.filter(p=>p.cards.length).map(p=>`${playerNameHtml(p)}: ${p.cards.map(c=>c==="amarelo"?"🟨":c==="azul"?"🟦":"🟥").join("")}`).join("<br>") || "—";
    const gksTxt = summary.gks.map(gk=>{
      const teamName = state.teams[gk.side==="home"?summary.homeId:summary.awayId].name;
      return `${escapeHtml(gk.name)} (${teamName}) — ${gk.golosSofridos} sofridos · condição final ${Math.round(gk.finalFitness)}%`;
    }).join("<br>") || "—";
    const injuriesTxt = summary.injuries.length ? summary.injuries.map(i=>`${escapeHtml(i.name)} (${state.teams[i.side==="home"?summary.homeId:summary.awayId].name})`).join("<br>") : "Sem lesões.";
    const suspensionsTxt = summary.suspensions.length ? summary.suspensions.map(p=>`${playerNameHtml(p)} (${state.teams[p.side==="home"?summary.homeId:summary.awayId].name})`).join("<br>") : "Sem expulsões.";
    const ratingsTxt = summary.players.slice().sort((a,b)=>b.rating-a.rating).map(p=>{
      const teamName = state.teams[p.side==="home"?summary.homeId:summary.awayId].name;
      return `<tr><td>${playerNameHtml(p)}${p.provisional?' <span class="provisional-tag">PROV.</span>':''}</td><td>${teamName}</td><td class="num">${p.rating.toFixed(1)}</td><td class="num">${Math.round(p.finalFitness)}%</td></tr>`;
    }).join("");
    const relatoTxt = summary.logHighlights.map(l=>`${l.label} ${l.text.replace(/<[^>]+>/g,"")}`).join("<br>") || "Sem eventos de destaque.";
    const resultTxt = summary.soWinner ? `(decidido nas grandes penalidades a favor de ${state.teams[summary.soWinner==="home"?summary.homeId:summary.awayId].name})` : "";

    document.getElementById("postMatchBody").innerHTML = `
      <div class="pm-postmatch-score">
        <div class="pm-postmatch-team"><span class="dot" id="pmHomeCrestDot"></span>${homeT.name}</div>
        <div class="pm-postmatch-scoreval">${summary.homeScore} - ${summary.awayScore}</div>
        <div class="pm-postmatch-team"><span class="dot" id="pmAwayCrestDot"></span>${awayT.name}</div>
      </div>
      ${resultTxt ? `<div style="text-align:center;font-size:11px;color:var(--texto-mute);margin-bottom:10px;">${resultTxt}</div>` : ''}
      ${summary.mvp ? `<div style="text-align:center;background:rgba(255,106,26,0.1);border-radius:8px;padding:8px;margin-bottom:14px;font-size:13px;"><b>⭐ MVP:</b> ${escapeHtml(summary.mvp.name)} (${state.teams[summary.mvp.side==="home"?summary.homeId:summary.awayId].name}) — nota ${summary.mvp.rating.toFixed(1)}</div>` : ''}

      <div class="pm-postmatch-grid">
        <div><b>Posse de bola</b><br>${possHomePct}% - ${100-possHomePct}%</div>
        <div><b>Remates</b><br>${summary.shots.home} - ${summary.shots.away}</div>
        <div><b>Faltas</b><br>${summary.faltas.home} - ${summary.faltas.away}</div>
        <div><b>Cartões azuis</b><br>${cardCount(summary.cartoes.home,"azul")} - ${cardCount(summary.cartoes.away,"azul")}</div>
        <div><b>Cartões vermelhos</b><br>${cardCount(summary.cartoes.home,"vermelho")} - ${cardCount(summary.cartoes.away,"vermelho")}</div>
      </div>

      <div class="eyebrow" style="margin:14px 0 6px;">Eventos principais</div>
      <div class="pm-postmatch-block" style="max-height:160px;overflow-y:auto;">${relatoTxt}</div>

      <div class="eyebrow" style="margin:14px 0 6px;">Marcadores</div><div class="pm-postmatch-block">${scorers}</div>
      <div class="eyebrow" style="margin:14px 0 6px;">Assistências</div><div class="pm-postmatch-block">${assisters}</div>
      <div class="eyebrow" style="margin:14px 0 6px;">Cartões</div><div class="pm-postmatch-block">${cardsTxt}</div>
      <div class="eyebrow" style="margin:14px 0 6px;">Lesões</div><div class="pm-postmatch-block">${injuriesTxt}</div>
      <div class="eyebrow" style="margin:14px 0 6px;">Suspensões geradas</div><div class="pm-postmatch-block">${suspensionsTxt}</div>

    `;
    setTeamCrestDot(document.getElementById("pmHomeCrestDot"), homeT);
    setTeamCrestDot(document.getElementById("pmAwayCrestDot"), awayT);
    document.getElementById("postMatchModal").classList.remove("hidden");
  }

  document.getElementById("postMatchContinueBtn").addEventListener("click", () => concluirPartidaTerminada());

  function finalizeMatchBookkeeping(ctx){
    document.getElementById("matchStatus").textContent = "Fim de jogo";
    document.getElementById("pistaBancoPanel").classList.add("hidden");

    if(state.pendingAmigavel){
      state.pendingAmigavel=false;
      recordFriendlyResult(state.pendingFixture, ctx.score.home, ctx.score.away);
      state.pendingSuspensionServing=null;
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingPromotionTieGameIndex!=null){
      const gameIndex=state.pendingPromotionTieGameIndex; state.pendingPromotionTieGameIndex=null;
      recordPromotionTieResult(gameIndex,ctx.score.home,ctx.score.away);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingSecondDivisionFinalGameIndex!=null){
      const gameIndex=state.pendingSecondDivisionFinalGameIndex; state.pendingSecondDivisionFinalGameIndex=null;
      recordSecondDivisionFinalResult(gameIndex,ctx.score.home,ctx.score.away);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingSupertaca){
      state.pendingSupertaca=false;
      recordSupertacaResult(ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingEliteCupFase!=null){
      const fase=state.pendingEliteCupFase, idx=state.pendingEliteCupIndex;
      state.pendingEliteCupFase=null; state.pendingEliteCupIndex=null;
      eliteCupRecordTieResult(fase, idx, ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      // Continua de imediato a resolver o resto da prova (as restantes eliminatórias IA-IA da
      // mesma fase, e fases seguintes). Correção (bug real, não só um "e se"): ao contrário da
      // Taça de Portugal — onde rondas sucessivas do próprio utilizador caem tipicamente em dias
      // diferentes, por isso nunca há um 2.º jogo pendente na mesma passagem —, na Elite Cup é o
      // caso NORMAL e mais comum: assim que a fase atual fica completa, a fase seguinte já fica
      // com o jogo do utilizador pronto de imediato (mesmo "instante" comprimido). O código
      // anterior só chamava setView("clube") quando não havia mais nenhum jogo pendente — nesse
      // caso comum ficava-se preso no ecrã do jogo (viewJogo) já terminado, com o botão
      // "Continuar" ativo mas sem qualquer indicação visual de como avançar. Volta sempre à
      // central, tal como acontece antes do primeiro jogo da prova.
      processEliteCupForCurrentDate();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingTacaPortugalFase!=null){
      const fase=state.pendingTacaPortugalFase, idx=state.pendingTacaPortugalIndex;
      state.pendingTacaPortugalFase=null; state.pendingTacaPortugalIndex=null;
      tacaRecordTieResult(fase, idx, ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      // Correção: várias eliminatórias da Taça partilham a mesma data — depois de resolver o
      // jogo do próprio utilizador, é preciso continuar logo a resolver os restantes jogos
      // dessa mesma jornada da Taça, ou ficariam perdidos para sempre assim que o dia avançasse
      // (a data já não voltaria a coincidir). Só volta a abrir a convocatória se, por acaso,
      // houver outro jogo do utilizador agendado para o mesmo dia (não deveria acontecer, mas
      // fica coberto de qualquer forma — nesse caso o próprio fluxo interativo já geriu o botão).
      processTacaPortugalForCurrentDate();
      if(state.pendingTacaPortugalFase!=null){ document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); return; }
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingCopaDelReyFase!=null){
      const fase=state.pendingCopaDelReyFase, idx=state.pendingCopaDelReyIndex;
      state.pendingCopaDelReyFase=null; state.pendingCopaDelReyIndex=null;
      nationalCupRecordTieResult("copa-del-rey", fase, idx, ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      processNationalCupForCurrentDate("copa-del-rey");
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingCoppaItaliaFase!=null){
      const fase=state.pendingCoppaItaliaFase, idx=state.pendingCoppaItaliaIndex;
      state.pendingCoppaItaliaFase=null; state.pendingCoppaItaliaIndex=null;
      nationalCupRecordTieResult("coppa-italia", fase, idx, ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      processNationalCupForCurrentDate("coppa-italia");
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingSupercopaEspanaFase!=null){
      const fase=state.pendingSupercopaEspanaFase, idx=state.pendingSupercopaEspanaIndex;
      state.pendingSupercopaEspanaFase=null; state.pendingSupercopaEspanaIndex=null;
      supercopaEspanaRecordTieResult(fase, idx, ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      processSupercopaEspanaForCurrentDate();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingSupercoppaItalianaLeg){
      const legKey=state.pendingSupercoppaItalianaLeg;
      state.pendingSupercoppaItalianaLeg=null;
      recordSupercoppaItalianaLeg(legKey, ctx.score.home, ctx.score.away, ctx.soWinner);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingEuropaSlot){
      const slot = state.pendingEuropaSlot;
      state.pendingEuropaSlot = null;
      if(slot.tipo==="grupo") europaRecordGroupResult(slot.grupoId, slot.roundIdx, ctx.score.home, ctx.score.away, ctx.soWinner, ctx.attendance);
      else europaRecordTieLegResult(slot.bracketId, slot.fase, slot.tieIdx, slot.legIdx, ctx.score.home, ctx.score.away, ctx.soWinner, ctx.attendance);
      if(state.pendingSuspensionServing){ finalizeSuspensions(ctx.homeId,state.pendingSuspensionServing.home); finalizeSuspensions(ctx.awayId,state.pendingSuspensionServing.away); state.pendingSuspensionServing=null; }
      cleanupPendingProvisional(); state.pendingFixture=null; renderTeams(); renderStats(); renderRoster();
      // Continua de imediato a resolver o resto da(s) prova(s) europeia(s) do dia — mesmo padrão
      // da Elite Cup/Taça de Portugal: pode haver outro jogo do próprio utilizador pendente
      // (ex.: qualificação e Cup na mesma data, em provas diferentes).
      processEuropaForCurrentDate();
      document.getElementById("continuarBtn").disabled=false; updateContinuarBtnLabel(); setView("clube"); return;
    }
    if(state.pendingPlayoffSeries){
      const series = state.pendingPlayoffSeries;
      state.pendingPlayoffSeries = null;
      finishPlayoffGame(series, ctx.homeId, ctx.awayId, ctx.score.home, ctx.score.away, ctx.soWinner, ctx.attendance);
      if(state.pendingSuspensionServing){
        finalizeSuspensions(ctx.homeId, state.pendingSuspensionServing.home);
        finalizeSuspensions(ctx.awayId, state.pendingSuspensionServing.away);
        state.pendingSuspensionServing = null;
      }
      cleanupPendingProvisional(); state.pendingFixture=null;
      renderTeams(); renderStats(); renderRoster();
      checkPlayoffPhaseCompletion();
      updateContinuarBtnLabel();
      setView("clube");
      return;
    }

    recordFixtureResult(state.currentRound, ctx.homeId, ctx.awayId, ctx.score.home, ctx.score.away, ctx.soWinner, ctx.attendance);
    // Barómetro contínuo de confiança da direção (pedido do utilizador, 2026-09-14): generalizado
    // (2026-09-23, mercado de treinadores) a todos os clubes, não só ao do utilizador — a
    // atualização já não vive aqui, corre dentro de applyStandings (via
    // registerTreinadorMatchResult, 08c-staff-treinadores.js), o ponto único que já regista o
    // mandato do treinador de ambos os lados de qualquer jogo.
    applyStandings(ctx.homeId, ctx.awayId, ctx.score.home, ctx.score.away, ctx.soWinner);
    if(state.pendingSuspensionServing){
      finalizeSuspensions(ctx.homeId, state.pendingSuspensionServing.home);
      finalizeSuspensions(ctx.awayId, state.pendingSuspensionServing.away);
      state.pendingSuspensionServing = null;
    }
    cleanupPendingProvisional(); state.pendingFixture=null;
    renderStandings(); renderFixtures(); renderTeams(); renderStats(); renderRoster();
    maybeAdvanceRound();
    updateContinuarBtnLabel();
    setView("clube");
  }

  function recordFixtureResult(roundIdx, homeId, awayId, hs, as, soWinner, attendance){
    const round = state.fixtures[roundIdx];
    const fx = round.find(f=>f.home===homeId && f.away===awayId);
    if(fx && !fx.played){
      // attendance (opcional): quando o jogo foi ao vivo, o chamador passa ctx.attendance (o
      // valor único já mostrado ao utilizador durante a partida) — ver processMatchFinances.
      processMatchFinances(homeId,awayId,round.date||state.currentDate, attendance!=null?{attendance}:undefined);
      fx.played=true; fx.homeScore=hs; fx.awayScore=as; fx.soWinner = soWinner||null;
      registosRegistarJogoLiga(state.userCompetitionId, homeId, awayId, hs, as, soWinner||null); // Registos das ligas (10b-registos.js)
    }
  }
  // Fase 2 da 2ª Divisão: versão genérica, para competições que não são a do utilizador
  // (Zona Norte/Sul, 100% IA por agora) — sem processamento financeiro ainda (isso fica para
  // a fase do mercado/finanças), só regista o resultado no calendário certo.
  function recordFixtureResultFor(competition, roundIdx, homeId, awayId, hs, as, soWinner){
    const round = competition.fixtures[roundIdx];
    const fx = round.find(f=>f.home===homeId && f.away===awayId);
    if(fx && !fx.played){
      fx.played=true; fx.homeScore=hs; fx.awayScore=as; fx.soWinner = soWinner||null;
      registosRegistarJogoLiga(competition.id, homeId, awayId, hs, as, soWinner||null); // Registos das ligas (10b-registos.js)
    }
  }
  // Processa integralmente (sem pausa nenhuma) todos os jogos da próxima jornada por marcar de
  // uma competição — usado para Zona Norte/Sul, que ainda não têm nenhum envolvimento do
  // utilizador (Fase 2). Não avança se a competição já tiver terminado a fase regular.
  function processCompetitionRoundFullyAI(competition){
    if(!competition || competition.currentRound >= competition.fixtures.length) return;
    const round = competition.fixtures[competition.currentRound];
    round.forEach(fx => {
      if(fx.played) return;
      const servingHome = getSuspendedIds(fx.home);
      const servingAway = getSuspendedIds(fx.away);
      const addedHome = ensureMinimumSquad(state.teams[fx.home]);
      const addedAway = ensureMinimumSquad(state.teams[fx.away]);
      const res = simulateMatchToCompletion(fx.home, fx.away, false, false, competition.id);
      recordFixtureResultFor(competition, competition.currentRound, fx.home, fx.away, res.home, res.away, res.soWinner);
      applyStandings(fx.home, fx.away, res.home, res.away, res.soWinner);
      finalizeSuspensions(fx.home, servingHome); finalizeSuspensions(fx.away, servingAway);
      removeProvisionalPlayers(state.teams[fx.home], addedHome);
      removeProvisionalPlayers(state.teams[fx.away], addedAway);
    });
    // Correção: gerava notícia de resultados para TODAS as 6 outras competições, mesmo sem
    // nenhuma ligação ao clube do utilizador — a jogar com um clube do Placard, por exemplo,
    // apareciam notícias de zonas da 3ª Divisão completamente irrelevantes, a inundar o feed.
    // Só gera notícia se a competição tiver alguma ligação direta: ou é a equipa B do próprio
    // utilizador que lá joga, ou (por omissão, se não houver equipa B) fica mesmo sem notícia.
    const minhaEquipaB = myTeam() && myTeam().equipaBId;
    if(minhaEquipaB && competition.teamIds.includes(minhaEquipaB)){
      buildJornadaResultsNewsFor(competition, competition.currentRound);
    }
    competition.currentRound++;
  }
  // Mesmo formato e estilo (linhas com posição · equipa · marcador · equipa · posição, mais a
  // data) já usado para a competição do utilizador (buildJornadaResultsNews) — aplicado aqui às
  // restantes 6 competições, simuladas inteiramente pela IA.
  function buildJornadaResultsNewsFor(competition, roundIdx){
    const round = competition.fixtures[roundIdx];
    const standings = standingsForCompetition(competition.id);
    const posOf = {};
    standings.forEach((t, idx) => { posOf[t.id] = idx+1; });
    const rows = round.map(fx => {
      const homeT = state.teams[fx.home], awayT = state.teams[fx.away];
      const score = fx.played ? `${fx.homeScore} - ${fx.awayScore}${fx.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—";
      return `<div class="jr-row">
        <span class="jr-pos">${posOf[fx.home]!=null?posOf[fx.home]+'º':'–'}</span>
        <button class="jr-team-link jr-home" data-team="${fx.home}">${homeT.name}</button>
        <span class="jr-score">${score}</span>
        <button class="jr-team-link jr-away" data-team="${fx.away}">${awayT.name}</button>
        <span class="jr-pos">${posOf[fx.away]!=null?posOf[fx.away]+'º':'–'}</span>
      </div>`;
    }).join("");
    pushNews(state.currentDate, rows, "jogo", `Resultados — Jornada ${roundIdx+1} de ${competitionLabel(competition.id)} (${fmtDateShort(round.date||state.currentDate)})`);
  }
  // Fase 3: uma passagem processa todos os eventos pendentes do dia.
  function processGlobalAgendaForCurrentDate(){
    const events=agendaEventsForDate(state.currentDate);
    if(!events.length) return false;
    const userEvents=[];
    events.forEach(event=>{
      const comp=state.competitions[event.competitionId];
      if(!comp||event.status!=="pendente") return;
      if(event.competitionId===state.userCompetitionId){ userEvents.push(event); return; }
      if(comp.currentRound!==event.roundIndex) comp.currentRound=event.roundIndex;
      processCompetitionRoundFullyAI(comp);
      markAgendaEventProcessed(event.id); syncCompetitionStatus(comp);
    });
    if(userEvents.length){
      const event=userEvents[0], comp=state.competitions[event.competitionId];
      if(comp.currentRound!==event.roundIndex) comp.currentRound=event.roundIndex;
      state.pendingAgendaEventId=event.id;
      processRound(comp.fixtures[event.roundIndex]);
    }
    processPhaseFiveFinalsForCurrentDate();
    return true;
  }
  function applyStandings(homeId, awayId, hs, as, soWinner){
    const home = state.teams[homeId], away = state.teams[awayId];
    home.stats.J++; away.stats.J++;
    home.stats.GM += hs; home.stats.GS += as;
    away.stats.GM += as; away.stats.GS += hs;
    let homeResult, awayResult;
    if(soWinner){
      if(soWinner==="home"){ home.stats.V++; home.stats.Pts+=3; away.stats.D++; homeResult="V"; awayResult="D"; }
      else { away.stats.V++; away.stats.Pts+=3; home.stats.D++; homeResult="D"; awayResult="V"; }
    } else if(hs>as){ home.stats.V++; home.stats.Pts+=3; away.stats.D++; homeResult="V"; awayResult="D"; }
    else if(as>hs){ away.stats.V++; away.stats.Pts+=3; home.stats.D++; homeResult="D"; awayResult="V"; }
    else { home.stats.E++; away.stats.E++; home.stats.Pts+=1; away.stats.Pts+=1; homeResult="E"; awayResult="E"; }
    if(!home.recentResults) home.recentResults = [];
    if(!away.recentResults) away.recentResults = [];
    home.recentResults.push(homeResult); if(home.recentResults.length>10) home.recentResults.shift();
    away.recentResults.push(awayResult); if(away.recentResults.length>10) away.recentResults.shift();
    // Staff — Treinadores (2026-09-22): único ponto universal onde qualquer resultado (liga,
    // taça, playoff) fica registado — ponto de gancho para o mandato do treinador de cada clube
    // (e, quando é o clube do utilizador, para o mandato do próprio gestor).
    registerTreinadorMatchResult(home, homeResult);
    registerTreinadorMatchResult(away, awayResult);
    // Balneário: cada resultado mexe um pouco na coesão do grupo (08d-balneario.js).
    registerBalnearioResult(home, homeResult, hs-as);
    registerBalnearioResult(away, awayResult, as-hs);
    // Adeptos (08f-adeptos.js): o humor da massa adepta reage a cada resultado, sobretudo em casa.
    registerAdeptosResult(home, "home", homeResult, hs-as, awayId);
    registerAdeptosResult(away, "away", awayResult, as-hs, homeId);
    // Reação da direção (04-financas.js): email + ajuste ligeiro à confiança, só para jogos do utilizador.
    directionReactToUserMatch(homeId, awayId, hs, as, soWinner);
  }

  // A suspensão por expulsão dura 1 jogo. Modelo: capturamos quem está a cumprir suspensão
  // ANTES do jogo da equipa (esses ficam de fora da escolha de onze); só a esses decrementamos
  // no fim, para não anular no mesmo jogo uma expulsão que acabou de acontecer.
  function getSuspendedIds(teamId){
    return state.teams[teamId].players.filter(p=>(p.suspensoJogos||0)>0).map(p=>p.id);
  }
  function finalizeSuspensions(teamId, servingIds){
    state.teams[teamId].players.forEach(p=>{
      if(servingIds.includes(p.id) && (p.suspensoJogos||0)>0) p.suspensoJogos -= 1;
    });
  }

  // Notícia de véspera: mesma estrutura da notícia de resultados, mas sem resultados (o jogo
  // ainda não aconteceu) — mostra os confrontos da próxima jornada com a posição atual de cada equipa.
  function buildJornadaPreviewNews(roundIdx){
    const round = state.fixtures[roundIdx];
    // Posições SEMPRE da liga do utilizador (sortedStandings() dá prioridade à competição que está
    // a ser VISTA — 2026-10-15: com outra competição aberta, apareciam "undefinedº").
    const standings = standingsForCompetition(state.userCompetitionId);
    const posOf = {};
    standings.forEach((t, idx) => { posOf[t.id] = idx+1; });
    const rows = round.map(fx => {
      const homeT = state.teams[fx.home], awayT = state.teams[fx.away];
      const isMe = fx.home===state.userTeamId || fx.away===state.userTeamId;
      return `<div class="jr-row ${isMe?'jr-me':''}">
        <span class="jr-pos">${posOf[fx.home]!=null?posOf[fx.home]+'º':'–'}</span>
        <button class="jr-team-link jr-home" data-team="${fx.home}">${homeT.name}</button>
        <span class="jr-score">vs</span>
        <button class="jr-team-link jr-away" data-team="${fx.away}">${awayT.name}</button>
        <span class="jr-pos">${posOf[fx.away]!=null?posOf[fx.away]+'º':'–'}</span>
      </div>`;
    }).join("");
    const myFx = round.find(f=>f.home===state.userTeamId || f.away===state.userTeamId);
    let titleHint = `Antevisão — Jornada ${roundIdx+1} (${fmtDateShort(state.currentDate)})`;
    if(myFx){
      const oppId = myFx.home===state.userTeamId ? myFx.away : myFx.home;
      const isHome = myFx.home===state.userTeamId;
      titleHint = `Jornada ${roundIdx+1} (${fmtDateShort(round.date||state.currentDate)}): ${myTeam().name} ${isHome?'recebe':'visita'} ${state.teams[oppId].name} amanhã`;
    }
    pushNews(state.currentDate, rows, "jogo", titleHint);
  }

  function buildJornadaResultsNews(roundIdx){
    const round = state.fixtures[roundIdx];
    // Posições SEMPRE da liga do utilizador (sortedStandings() dá prioridade à competição que está
    // a ser VISTA — 2026-10-15: com outra competição aberta, apareciam "undefinedº").
    const standings = standingsForCompetition(state.userCompetitionId);
    const posOf = {};
    standings.forEach((t, idx) => { posOf[t.id] = idx+1; });
    const rows = round.map(fx => {
      const homeT = state.teams[fx.home], awayT = state.teams[fx.away];
      const isMe = fx.home===state.userTeamId || fx.away===state.userTeamId;
      const score = fx.played ? `${fx.homeScore} - ${fx.awayScore}${fx.soWinner?' <span style="font-size:9px;">(g.p.)</span>':''}` : "—";
      return `<div class="jr-row ${isMe?'jr-me':''}">
        <span class="jr-pos">${posOf[fx.home]!=null?posOf[fx.home]+'º':'–'}</span>
        <button class="jr-team-link jr-home" data-team="${fx.home}">${homeT.name}</button>
        <span class="jr-score">${score}</span>
        <button class="jr-team-link jr-away" data-team="${fx.away}">${awayT.name}</button>
        <span class="jr-pos">${posOf[fx.away]!=null?posOf[fx.away]+'º':'–'}</span>
      </div>`;
    }).join("");
    const myFx = round.find(f=>f.home===state.userTeamId || f.away===state.userTeamId);
    let titleHint = `Resultados — Jornada ${roundIdx+1} (${fmtDateShort(round.date||state.currentDate)})`;
    if(myFx){
      const oppId = myFx.home===state.userTeamId ? myFx.away : myFx.home;
      titleHint = `Jornada ${roundIdx+1} (${fmtDateShort(round.date||state.currentDate)}): ${myTeam().name} ${myFx.home===state.userTeamId?myFx.homeScore:myFx.awayScore}-${myFx.home===state.userTeamId?myFx.awayScore:myFx.homeScore} ${state.teams[oppId].name}`;
    }
    pushNews(state.currentDate, rows, "jogo", titleHint);
  }

  function checkPlayoffClinch(){
    const comp = currentCompetition();
    if(!comp || !PLAYOFF_DIVISION_CONFIG[comp.divisionId]) return;
    if(state.playoffClinchedAnnounced || state.playoffActive || state.seasonOver) return;
    const totalRounds = state.fixtures.length;
    const remainingGames = totalRounds - state.currentRound - 1;
    const club = myTeam();
    const userPoints = club.stats.Pts;
    const rivalsThatCouldPass = (comp.teamIds||[]).map(id=>state.teams[id]).filter(t=>t&&t.id!==state.userTeamId).filter(t=>{ // 2026-10-16: só os clubes da competição do utilizador
      return (t.stats.Pts + remainingGames*3) > userPoints;
    }).length;
    if(rivalsThatCouldPass < 8){
      state.playoffClinchedAnnounced = true;
      const label = comp.divisionId==="placard" ? "Campeonato Placard" : PLAYOFF_DIVISION_CONFIG[comp.divisionId].championLabel;
      pushNews(state.currentDate, `🎉 O ${teamLinkHtml(club.id)} está matematicamente apurado para o playoff do ${label} ${seasonLabel(state.season)}!`, "sistema");
    }
  }

  function maybeAdvanceRound(){
    buildJornadaResultsNews(state.currentRound);
    checkPlayoffClinch();
    if(state.pendingAgendaEventId){ markAgendaEventProcessed(state.pendingAgendaEventId); state.pendingAgendaEventId=null; }
    state.currentRound++;
    state.match = null;
    if(state.currentRound >= state.fixtures.length){
      const comp=currentCompetition();
      if(comp) comp.status="concluida";
      state.seasonOver = true;
      state.seasonOverSinceDate = new Date(state.currentDate); state.seasonCloseStuckWarned = false;
      if(comp && PLAYOFF_DIVISION_CONFIG[comp.divisionId]){
        pushNews(state.currentDate, comp.divisionId==="placard"
          ? `Fim da fase regular da Época ${seasonLabel(state.season)}! Começa o playoff.`
          : `Fim da fase regular da ${competitionLinkHtml(state.userCompetitionId)} ${seasonLabel(state.season)}! Começa o playoff.`, "sistema");
        startPlayoffs(comp);
      } else {
        pushNews(state.currentDate, `Fim da fase regular da ${competitionLinkHtml(state.userCompetitionId)} ${seasonLabel(state.season)}.`, "sistema");
      }
    }
    document.getElementById("continuarBtn").disabled = false;
    renderHubDate();
    if(state.activeView==="clube") renderClubeView();
  }

  // =================================================================
