// Relatórios mensais da equipa B (2026-10-12, pedido do utilizador: "Relatórios mensais sobre a equipa B").
//
// Só existem para o clube do utilizador quando este tem equipa B. Chegam no 1.º dia de cada mês e são dois:
//   1) "Relatório mensal da equipa B" — treinador da B (folha repDoc): resultados do mês anterior,
//      classificação, minutos e utilização, evolução dos jogadores desde o último relatório e a
//      ligação à equipa A (candidatos a subir e jogadores da A que precisam de ritmo).
//   2) "Relatório mensal do plantel da equipa B" — departamento médico (o mesmo da equipa A, ver
//      lesMensal em 08w-lesoes.js): lesionados, readaptação, jogadores em risco e balanço da época.
//
// Estado: state.relB = { v, mes, snap } — snap guarda, por jogador (A e B), o OVR, os minutos oficiais pela
// equipa B e os jogos da época no último relatório, para calcular as variações do mês. Dados simples (save).

const RELB_MIN_JOGOS_NOTA = 1;

function relBEnsure() {
  if (!state.relB || typeof state.relB !== "object") state.relB = { v: 1, mes: null, snap: {} };
  if (!state.relB.snap || typeof state.relB.snap !== "object") state.relB.snap = {};
  return state.relB;
}
// Minutos oficiais (liga, taças, playoffs) feitos pela equipa indicada na época em curso.
function relBMinutos(p, team) {
  const per = p && p.participacaoCompeticoes && p.participacaoCompeticoes[seasonLabel(state.season)];
  if (!per) return 0;
  return Object.values(per).filter(x => x && x.clubeId === team.id).reduce((a, x) => a + (x.minutos || 0), 0);
}
function relBDisponivel(p) { return !((p.diasLesao || 0) > 0) && !((p.suspensoJogos || 0) > 0); }
function relBSnapshot(a, b) {
  const c = relBEnsure(), snap = {};
  (b.players || []).forEach(p => { snap[p.id] = { o: overall(p), m: relBMinutos(p, b), j: (p.season && p.season.jogos) || 0 }; });
  (a.players || []).forEach(p => { snap[p.id] = { o: overall(p), m: 0, j: (p.season && p.season.jogos) || 0 }; });
  c.snap = snap;
}
function relBOrd(n) { return `${n}.º`; }
function relBPlural(n, s, pl) { return `${n} ${n === 1 ? s : pl}`; }

// Candidatos da B a subir à A e jogadores da A que ganhavam com ritmo na B.
function relBLigacaoA(a, b, snap) {
  const jA = a.players.filter(p => p.pos === "J").map(p => overall(p)).sort((x, y) => y - x);
  const grA = a.players.filter(p => p.pos === "GR").map(p => overall(p)).sort((x, y) => y - x);
  const ref5 = jA.length >= 5 ? jA[4] : (jA.length ? jA[jA.length - 1] : 0), ref8 = jA.length >= 8 ? jA[7] : ref5;
  const refGR = grA.length >= 2 ? grA[1] : (grA.length ? grA[0] : 0);
  const sobem = [];
  b.players.filter(relBDisponivel).forEach(p => {
    const o = overall(p), nota = p.season && p.season.notas && p.season.notas.length >= RELB_MIN_JOGOS_NOTA ? avg(p.season.notas) : null;
    let nivel = null;
    if (p.pos === "GR") { if (o >= refGR - 1) nivel = "suplente"; }
    else if (o >= ref5 - 1) nivel = "5 inicial";
    else if (o >= ref8) nivel = "rotação";
    if (nivel) sobem.push({ p, o, nivel, nota });
  });
  sobem.sort((x, y) => y.o - x.o);
  const top8 = new Set(a.players.filter(p => p.pos === "J").sort((x, y) => overall(y) - overall(x)).slice(0, 8).map(p => p.id));
  const ritmo = a.players.filter(p => relBDisponivel(p) && p.age <= 24 && !top8.has(p.id) && p.pos !== "GR"
    && Math.max(0, ((p.season && p.season.jogos) || 0) - ((snap[p.id] && snap[p.id].j) || 0)) === 0)
    .sort((x, y) => (y.potential - overall(y)) - (x.potential - overall(x))).slice(0, 3);
  return { sobem: sobem.slice(0, 4), ritmo, ref5, ref8, refGR };
}

function relBMensal() {
  const a = myTeam(); if (!a || !state.currentDate || !a.equipaBId) return;
  const b = state.teams[a.equipaBId]; if (!b || !Array.isArray(b.players) || !b.players.length) return;
  const c = relBEnsure();
  const d = state.currentDate;
  const mes = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  if (c.mes === mes) return;
  c.mes = mes;
  // Saúde: relatório do departamento médico para o plantel B (chave mensal própria).
  if (typeof lesMensal === "function") lesMensal(b);
  // Mês analisado: o anterior.
  const ant = new Date(d.getFullYear(), d.getMonth() - 1, 1);
  const antKey = `${ant.getFullYear()}-${String(ant.getMonth() + 1).padStart(2, "0")}`;
  const hist = (b.historicoTatico || []).filter(h => h.date && h.date.slice(0, 7) === antKey);
  const snap = c.snap || {}, tinhaSnap = Object.keys(snap).length > 0;
  c.meses = (c.meses || 0) + 1;
  if (!hist.length) { relBSnapshot(a, b); return; }

  const V = hist.filter(h => h.resultado === "V").length, E = hist.filter(h => h.resultado === "E").length, D = hist.filter(h => h.resultado === "D").length;
  const gm = hist.reduce((s, h) => s + (h.golosMarcados || 0), 0), gs = hist.reduce((s, h) => s + (h.golosSofridos || 0), 0);
  const pts = V * 3 + E, ppj = roundDecimal(pts / hist.length);
  const sis = { "3-1": 0, "2-2": 0 }; hist.forEach(h => { if (sis[h.sistema] != null) sis[h.sistema]++; });
  const sistemaMais = sis["3-1"] >= sis["2-2"] ? "3-1" : "2-2";
  const ult = hist.slice().sort((x, y) => String(x.date).localeCompare(String(y.date))).slice(-5)
    .map(h => { const adv = state.teams[h.opponentId]; return [adv ? escapeHtml(adv.name) : "—", `<b>${h.golosMarcados}-${h.golosSofridos}</b> ${repFormaHtml([h.resultado])} · ${h.isHome ? "em casa" : "fora"}`]; });

  // Classificação na competição da equipa B.
  let classif = null;
  try {
    const comp = competitionOfTeam(b);
    if (comp && comp.teamIds.length >= 3) {
      const tab = standingsForCompetition(comp.id), idx = tab.findIndex(t => t.id === b.id);
      if (idx >= 0) classif = { comp, pos: idx + 1, total: tab.length, lider: tab[0], st: b.stats };
    }
  } catch (e) { classif = null; }

  // Minutos e evolução desde o último relatório.
  const minMes = p => Math.max(0, relBMinutos(p, b) - ((snap[p.id] && snap[p.id].m) || 0));
  const jogMes = p => Math.max(0, ((p.season && p.season.jogos) || 0) - ((snap[p.id] && snap[p.id].j) || 0));
  const nome = p => playerLinkHtml(b.id, p);
  const usados = b.players.filter(p => minMes(p) > 0).sort((x, y) => minMes(y) - minMes(x));
  const semJogarTodos = b.players.filter(p => relBDisponivel(p) && minMes(p) === 0).sort((x, y) => (y.potential - overall(y)) - (x.potential - overall(x)));
  const semJogar = semJogarTodos.slice(0, 4);
  const evol = tinhaSnap ? b.players.map(p => ({ p, dlt: snap[p.id] ? overall(p) - snap[p.id].o : 0 })).filter(x => x.dlt !== 0).sort((x, y) => Math.abs(y.dlt) - Math.abs(x.dlt)).slice(0, 5) : [];
  const promessas = b.players.filter(p => p.age <= 21).sort((x, y) => (y.potential - overall(y)) - (x.potential - overall(x))).slice(0, 2);
  const lig = relBLigacaoA(a, b, snap);

  const resumoPartes = [`${V}V ${E}E ${D}D em ${MONTHS[ant.getMonth()].toLowerCase()}${classif ? `, ${relBOrd(classif.pos)} lugar` : ""}.`];
  if (lig.sobem.length) resumoPartes.push(`${relBPlural(lig.sobem.length, "jogador pronto", "jogadores prontos")} para subir à equipa A.`);
  if (semJogarTodos.length) resumoPartes.push(`${relBPlural(semJogarTodos.length, "disponível sem jogar", "disponíveis sem jogar")}.`);
  const linhaEvo = x => [nome(x.p), `<span class="${x.dlt > 0 ? "evo-up" : "evo-down"}">${x.dlt > 0 ? "▲ +" : "▼ "}${x.dlt}</span> · OVR ${overall(x.p)}${x.p.age <= 21 ? ` · perspetiva ${visiblePotentialLabel(x.p, b).toLowerCase()}` : ""}`];
  const secoes = [
    { icone: "📈", titulo: "Resultados do mês", cheia: true, linhas: [
      ["Jogos", `<b>${hist.length}</b> · ${V}V ${E}E ${D}D · ${ppj} pontos por jogo`],
      ["Golos", `${gm} marcados · ${gs} sofridos (${gm - gs >= 0 ? "+" : ""}${gm - gs})`],
      ["Sistema mais usado", `${sistemaMais} (${sis[sistemaMais]} de ${hist.length} jogos)`],
    ].concat(ult.map((l, i) => i === 0 ? [`Últimos jogos`, `${l[0]} — ${l[1]}`] : ["", `${l[0]} — ${l[1]}`])) },
    { icone: "🏆", titulo: "Classificação", linhas: classif ? [
      ["Competição", escapeHtml(competitionLabel(classif.comp.id))],
      ["Posição", `<b>${relBOrd(classif.pos)}</b> de ${classif.total} · ${classif.st.Pts} pontos em ${classif.st.J} jogos`],
      ["Líder", classif.pos === 1 ? "a equipa B lidera" : `${escapeHtml(classif.lider.name)} (${classif.lider.stats.Pts} pontos, a ${classif.lider.stats.Pts - classif.st.Pts} de distância)`],
    ] : [["", "classificação indisponível"]] },
    { icone: "⏱️", titulo: "Minutos e utilização", linhas: (usados.length ? usados.slice(0, 5).map(p => [nome(p), `${minMes(p)} min · ${relBPlural(jogMes(p), "jogo", "jogos")}`]) : [["", "sem minutos registados"]])
      .concat(semJogar.length ? [["Sem jogar", semJogar.map(p => nome(p)).join(", ")]] : []) },
    { icone: "🌱", titulo: "Evolução desde o último relatório", linhas: (evol.length ? evol.map(linhaEvo) : [["", tinhaSnap ? "sem variações de OVR" : "primeiro relatório — a partir do próximo mostra as variações"]])
      .concat(promessas.length ? [["Maior margem", promessas.map(p => `${nome(p)} (OVR ${overall(p)} · perspetiva ${visiblePotentialLabel(p, b).toLowerCase()})`).join(" · ")]] : []) },
    { icone: "⬆️", titulo: "Candidatos a subir à equipa A", linhas: lig.sobem.length
      ? lig.sobem.map(x => [nome(x.p), `OVR <b>${x.o}</b> · ${x.p.age} anos · ${x.nivel === "5 inicial" ? "ao nível do 5 inicial da A" : x.nivel === "rotação" ? "opção de rotação na A" : "pode ser 2.º guarda-redes da A"}${x.nota != null ? ` · nota média ${x.nota.toFixed(1)}` : ""}`])
      : [["", "nenhum jogador da B está, para já, ao nível da equipa A"]] },
    { icone: "⬇️", titulo: "Jogadores da A que ganham com ritmo na B", linhas: lig.ritmo.length
      ? lig.ritmo.map(p => [playerLinkHtml(a.id, p), `${p.age} anos · OVR ${overall(p)} · sem jogos no mês`])
      : [["", "ninguém na equipa A precisa de ganhar ritmo"]] },
  ];
  pushNews(d, repDoc({
    teamId: b.id, org: "Treinador da equipa B", titulo: "Relatório mensal da equipa B",
    sub: `${MONTHS[ant.getMonth()]} de ${ant.getFullYear()} · ${relBPlural(hist.length, "jogo analisado", "jogos analisados")}`,
    chips: [repChip(`${V}V ${E}E ${D}D`, V > D ? "ok" : D > V ? "mau" : ""), classif ? repChip(`${relBOrd(classif.pos)} de ${classif.total}`) : null,
      repChip(relBPlural(lig.sobem.length, "candidato à A", "candidatos à A"), lig.sobem.length ? "ok" : ""),
      semJogarTodos.length ? repChip(`${semJogarTodos.length} sem jogar`, "aviso") : null].filter(Boolean),
    resumo: resumoPartes.join(" "),
    secoes,
    rodape: "Relatório mensal · treinador da equipa B",
  }), "tatica", "Relatório mensal da equipa B");
  c.emitidos = (c.emitidos || 0) + 1;
  relBSnapshot(a, b);
}
