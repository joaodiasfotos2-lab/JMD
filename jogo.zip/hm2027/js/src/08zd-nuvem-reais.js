// ============================= 08zd-nuvem-reais.js =============================
// Carreira simulada dos jogadores REAIS da "nuvem" (clubes não simulados em França/Argentina —
// ver ensureNuvemReais, 07g-europa.js). Pedido do utilizador (2026-10-15): "tens de simular a
// carreira deles também durante o jogo". Estes jogadores já envelhecem, evoluem (developPlayer),
// reformam-se e arquivam histórico como qualquer outro (closeCompletedSeasonPlayerStats e
// processRetirements percorrem todas as equipas, nuvem incluída), e jogam as provas europeias
// pelo clube (motor normal → finalizePlayerStats). O que faltava: os clubes da nuvem não jogam
// liga doméstica, por isso a época deles ficava vazia (0 jogos) — o que travava a evolução e
// aumentava a probabilidade de reforma. nuvemReaisSeedSeason() acrescenta, uma vez por época,
// uma época doméstica sintética (jogos, golos/golos sofridos, notas) por cima do que jogaram na
// Europa. Corre no início de beginDefeso, ANTES da convocatória (a seleção usa jogos/notas).
function nuvemReaisList(){
  const out = [];
  Object.values(state.teams).forEach(t=>{
    if(!t || !t.nuvemEuropeia) return;
    (t.players||[]).forEach(p=>{ if(p && p.nuvemReal) out.push({p, t}); });
  });
  return out;
}
function nuvemReaisSyntheticNota(p){
  return clamp(6 + (overall(p)-13)*0.12, 5.8, 7.6);
}
function nuvemReaisSeedSeason(){
  const rounds = Math.max(1, Math.round((state.fixtures&&state.fixtures.length) || state.currentRound || 26));
  nuvemReaisList().forEach(({p})=>{
    if(p.__nuvemSeedSeason===state.season) return;
    p.__nuvemSeedSeason = state.season;
    if(!p.season) p.season = createEmptyStats("season");
    const s = p.season;
    const extra = Math.round(rounds * rndFloat(0.78, 0.95));
    const jogos0 = s.jogos||0;
    s.jogos = jogos0 + extra;
    s.jogosTitular = Math.min(s.jogos, (s.jogosTitular||0) + Math.round(extra*0.85));
    s.jogosSuplente = Math.max(0, s.jogos - s.jogosTitular);
    if(s.minutos!=null) s.minutos = (s.minutos||0) + extra*(p.pos==="GR"?38:24);
    if(p.pos==="GR"){
      s.golosSofridos = (s.golosSofridos||0) + Math.round(extra*rndFloat(2.6,4.2));
    } else {
      const f = (p.attrs&&p.attrs.finalizacao)||12;
      s.golos = (s.golos||0) + Math.round(extra*clamp((f-9)*0.11,0.08,1.2)*rndFloat(0.7,1.2));
      s.assistencias = (s.assistencias||0) + Math.round(extra*clamp(((p.attrs&&p.attrs.criatividade)||12)-9,1,10)*0.07*rndFloat(0.7,1.2));
    }
    if(!Array.isArray(s.notas)) s.notas = [];
    const nota = nuvemReaisSyntheticNota(p);
    for(let i=0;i<12;i++) s.notas.push(Math.round((nota+rndFloat(-0.4,0.4))*10)/10);
  });
}
